---
title: Medik
emoji: 🩺
colorFrom: blue
colorTo: indigo
sdk: docker
app_file: app.py
pinned: false
---

# Medik - Your Personal AI Doctor

This AI-powered medical assistant helps assess symptoms and provides evidence-based health information. Select a medical category, enter your symptoms, and receive a personalized assessment.

## Features

- Dark theme UI with high contrast for readability
- Symptom assessment for multiple medical specialties
- Personalized analysis based on your medical profile
- Evidence-based medical information

## Medical Disclaimer

This application provides information for educational purposes only and is not a substitute for professional medical advice. 