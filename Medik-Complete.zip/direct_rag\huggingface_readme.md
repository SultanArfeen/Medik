# Medik - Your Personal AI Doctor 🏥

A sophisticated AI medical assistant powered by Retrieval-Augmented Generation (RAG). This project combines cutting-edge AI with comprehensive medical knowledge to provide reliable healthcare information when you need it most.

## 💡 The Inspiration

Medik was born out of a real need. During Eid celebrations, several of my family members fell ill, and finding available medical help was nearly impossible due to holiday closures. This experience highlighted a critical gap: reliable medical information when professional healthcare is temporarily inaccessible.

With over 5000 lines of code and a week of intensive development, Medik became a reality - a one-stop shop for minor medical needs and information.

## 🚀 Getting Started

This demo will automatically initialize when you launch it! It may take a few minutes to load on the first run as it processes the medical data, but subsequent runs will be faster thanks to caching.

### How to Use Medik

1. **General Queries**: Simply type a medical question in the main input field
2. **Symptom Assessment**: Use the "Detailed Medical Analysis" tab for comprehensive analysis
3. **Explore by Category**: Select from different health categories in the sidebar

## 🌟 Features

- **Intelligent Query Understanding**: Analyzes symptoms and medical questions with deep contextual understanding
- **Evidence-Based Responses**: Retrieves information from verified medical knowledge sources
- **Structured Assessment**: Provides detailed analysis for various health conditions
- **User-Friendly Interface**: Clear explanations and accessible medical information

## 📊 Example Queries

Try asking questions like:

- "What are the symptoms of diabetes?"
- "How can I tell if my chest pain is serious?"
- "What treatments are available for migraine headaches?"
- "What are the warning signs of a heart attack?"
- "What causes acid reflux and how can it be treated?"
- "How do I know if I have a food intolerance?"

## 🔍 Health Categories

Medik provides specific information in several health domains:

- Cardiovascular
- Respiratory
- Digestive
- Neurological
- Skin Conditions
- Mental Health
- Joints & Muscles
- Metabolic Disorders

## ⚙️ Under the Hood

Medik utilizes a sophisticated Retrieval-Augmented Generation (RAG) architecture:

1. **Data Processing**: Medical knowledge is processed into searchable documents
2. **Retrieval**: Multiple methods (BM25, semantic, hybrid) find relevant medical information
3. **Generation**: Advanced language models synthesize retrieved information into helpful responses

## ⚠️ Medical Disclaimer

Medik is for informational purposes only and does not provide medical advice, diagnosis, or treatment. Always consult with a qualified healthcare provider for medical concerns.

## 📧 Contact

Feel free to reach out:
- GitHub: [@SultanArfeen](https://github.com/SultanArfeen)
- LinkedIn: [Sultan Ul Arfeen](https://www.linkedin.com/in/sultan-arfeen-560a24353/)
- Medium: [@sultanularfeen](https://medium.com/@sultanularfeen)
- Hugging Face: [@ArfeenSKD](https://huggingface.co/ArfeenSKD) 