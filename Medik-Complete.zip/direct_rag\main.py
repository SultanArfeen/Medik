"""
Command-line interface for the DiReCT RAG System.

This script provides a command-line interface for the DiReCT RAG system,
allowing users to initialize the system, process data, and run queries
without using the Streamlit interface.
"""

import os
import sys
import argparse
import logging
import json
from pathlib import Path
from dotenv import load_dotenv

from src.rag_pipeline import RAGPipeline

# Load environment variables
load_dotenv()

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("main")

def parse_args():
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(description="DiReCT RAG System - Command Line Interface")
    
    # General arguments
    parser.add_argument("--data-dir", type=str, default="data",
                       help="Directory containing the dataset (default: data)")
    parser.add_argument("--index-dir", type=str, default="indexes",
                       help="Directory for storing indexes (default: indexes)")
    parser.add_argument("--results-dir", type=str, default="results",
                       help="Directory for storing results (default: results)")
    
    # Retriever arguments
    parser.add_argument("--retriever", type=str, choices=["bm25", "embedding", "hybrid"],
                       default="hybrid", help="Type of retriever to use (default: hybrid)")
    parser.add_argument("--embedding-model", type=str, 
                       default="sentence-transformers/all-mpnet-base-v2",
                       help="Embedding model for retrieval (default: sentence-transformers/all-mpnet-base-v2)")
    parser.add_argument("--top-k", type=int, default=5,
                       help="Number of documents to retrieve (default: 5)")
    
    # Generator arguments
    parser.add_argument("--generator", type=str, choices=["direct", "openai"],
                       default="direct", help="Type of generator to use (default: direct)")
    parser.add_argument("--generator-model", type=str, 
                       default="mistralai/Mistral-7B-Instruct-v0.2",
                       help="Generator model name (default: mistralai/Mistral-7B-Instruct-v0.2)")
    parser.add_argument("--device", type=str, default=None,
                       help="Device to run the model on (default: auto-detect)")
    
    # Action arguments
    parser.add_argument("--prepare", action="store_true",
                       help="Prepare data and build indexes")
    parser.add_argument("--query", type=str,
                       help="Process a single query and exit")
    parser.add_argument("--interactive", action="store_true",
                       help="Run in interactive mode")
    parser.add_argument("--demo", action="store_true",
                       help="Run demo queries")
    
    return parser.parse_args()

def save_result(result, results_dir):
    """Save query result to disk."""
    # Create results directory if it doesn't exist
    os.makedirs(results_dir, exist_ok=True)
    
    # Create a filename based on the query
    query_id = hash(result["query"]) % 10000
    filename = Path(results_dir) / f"query_{query_id}.json"
    
    # Remove non-serializable fields
    result_copy = result.copy()
    result_copy.pop("response_streamer", None)
    
    # Save to file
    with open(filename, "w") as f:
        json.dump(result_copy, f, indent=2)
        
    logger.info(f"Result saved to {filename}")

def print_result(result):
    """Print query result to console."""
    print("\n" + "=" * 80)
    print(f"QUERY: {result['query']}")
    print("=" * 80)
    
    print("\nRETRIEVED DOCUMENTS:")
    print("-" * 80)
    for i, doc in enumerate(result['retrieved_docs']):
        doc_type = doc.get("metadata", {}).get("type", "clinical_note")
        disease_category = doc.get("metadata", {}).get("disease_category", "Unknown")
        
        if doc_type == "knowledge_graph":
            print(f"Document {i+1}: Knowledge Graph - {disease_category}")
        else:
            diagnosis = doc.get("metadata", {}).get("diagnosis", "Unknown")
            print(f"Document {i+1}: Clinical Note - {disease_category} ({diagnosis})")
        
        # Print scores if available
        if "bm25_score" in doc and "embedding_score" in doc:
            print(f"Scores: BM25: {doc['bm25_score']:.4f}, Embedding: {doc['embedding_score']:.4f}, "
                  f"Combined: {doc['combined_score']:.4f}")
        elif "score" in doc:
            print(f"Score: {doc['score']:.4f}")
        
        print()
    
    print("\nRESPONSE:")
    print("-" * 80)
    print(result['response'])
    print("\n" + "=" * 80)

def run_demo_queries(pipeline, args):
    """Run a set of demo queries."""
    demo_queries = pipeline.get_demo_queries()
    
    for i, query in enumerate(demo_queries):
        print(f"\nRunning demo query {i+1}/{len(demo_queries)}...")
        result = pipeline.process_query(query, top_k=args.top_k)
        print_result(result)
        save_result(result, args.results_dir)

def run_interactive_mode(pipeline, args):
    """Run in interactive mode, processing queries from user input."""
    print("\nDiReCT RAG System - Interactive Mode")
    print("Type 'exit' or 'quit' to exit.\n")
    
    while True:
        query = input("\nEnter your query: ")
        
        if query.lower() in ["exit", "quit"]:
            print("Exiting...")
            break
        
        if not query.strip():
            continue
        
        print("Processing query...")
        result = pipeline.process_query(query, top_k=args.top_k)
        print_result(result)
        save_result(result, args.results_dir)

def main():
    """Main function."""
    args = parse_args()
    
    # Initialize pipeline
    logger.info("Initializing RAG pipeline...")
    pipeline = RAGPipeline(
        data_dir=args.data_dir,
        index_dir=args.index_dir,
        retriever_type=args.retriever,
        embedding_model_name=args.embedding_model,
        generator_type=args.generator,
        generator_model_name=args.generator_model,
        device=args.device,
        save_results=True,
        results_dir=args.results_dir
    )
    
    # Prepare data if requested
    if args.prepare:
        logger.info("Preparing data...")
        pipeline.prepare_data()
    
    # Process a single query if provided
    if args.query:
        logger.info(f"Processing query: {args.query}")
        result = pipeline.process_query(args.query, top_k=args.top_k)
        print_result(result)
    
    # Run demo queries if requested
    elif args.demo:
        logger.info("Running demo queries...")
        run_demo_queries(pipeline, args)
    
    # Run in interactive mode if requested
    elif args.interactive:
        logger.info("Running in interactive mode...")
        run_interactive_mode(pipeline, args)
    
    # If no action specified, print help
    elif not (args.prepare or args.query or args.demo or args.interactive):
        print("No action specified. Use --prepare, --query, --demo, or --interactive.")
        print("For help, use --help.")

if __name__ == "__main__":
    main() 