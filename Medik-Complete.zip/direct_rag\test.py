"""
Simple test script for the DiReCT RAG system.

This script runs a basic test to verify that the system is working correctly.
"""

import os
import logging
from pathlib import Path
from dotenv import load_dotenv
import nltk

from src.rag_pipeline import RAGPipeline

# Load environment variables
load_dotenv()

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("test")

# Download NLTK resources
def download_nltk_resources():
    """Download required NLTK resources."""
    try:
        logger.info("Downloading NLTK resources...")
        nltk.download('punkt')
        nltk.download('stopwords')
        logger.info("NLTK resources downloaded successfully")
        return True
    except Exception as e:
        logger.error(f"Error downloading NLTK resources: {str(e)}")
        return False

def test_pipeline():
    """Test the RAG pipeline with a simple query."""
    # Create necessary directories
    os.makedirs("data", exist_ok=True)
    os.makedirs("indexes", exist_ok=True)
    os.makedirs("results", exist_ok=True)
    
    # Download NLTK resources
    if not download_nltk_resources():
        logger.error("Failed to download required NLTK resources. Aborting test.")
        return False
    
    # Initialize pipeline
    logger.info("Initializing pipeline...")
    try:
        pipeline = RAGPipeline(
            data_dir="data",
            index_dir="indexes",
            retriever_type="bm25",  # Use BM25 for faster testing
            generator_type="direct",
            generator_model_name="mistralai/Mistral-7B-Instruct-v0.2"
        )
    except Exception as e:
        logger.error(f"Pipeline initialization failed: {str(e)}")
        return False
    
    # Prepare data
    logger.info("Preparing data...")
    try:
        pipeline.prepare_data()
        logger.info("Data preparation completed successfully")
    except Exception as e:
        logger.error(f"Data preparation failed: {str(e)}")
        return False
    
    # Run a test query
    logger.info("Processing test query...")
    test_query = "What are the diagnostic criteria for heart failure?"
    
    try:
        result = pipeline.process_query(test_query, top_k=3)
        if result and "response" in result:
            logger.info("Test query processed successfully")
            logger.info(f"Retrieved {len(result['retrieved_docs'])} documents")
            logger.info(f"Response length: {len(result['response'])} characters")
            return True
        else:
            logger.error("Test query failed: No response generated")
            return False
    except Exception as e:
        logger.error(f"Test query failed: {str(e)}")
        return False

def main():
    """Main function to run the test."""
    logger.info("Starting DiReCT RAG system test...")
    
    success = test_pipeline()
    
    if success:
        logger.info("Test completed successfully! ✅")
    else:
        logger.error("Test failed! ❌")
        
    return success

if __name__ == "__main__":
    main() 