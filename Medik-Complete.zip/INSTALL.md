# Installing Medik AI Doctor

This guide provides step-by-step instructions for setting up the Medik application on your local machine.

## Prerequisites

- **Python**: Version 3.9 or higher
- **Git**: For cloning the repository (optional)
- **Pip**: Python package manager (usually comes with Python)
- **At least 4GB RAM**: For model loading and processing

## Installation Steps

### 1. Get the Code

Either clone the repository using Git:

```bash
git clone https://github.com/[your-username]/medik.git
cd medik
```

Or download and extract the ZIP file from GitHub.

### 2. Set Up a Virtual Environment

#### On Windows:

```bash
python -m venv venv
venv\Scripts\activate
```

#### On macOS/Linux:

```bash
python3 -m venv venv
source venv/bin/activate
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

This may take a few minutes as it will download several machine learning models and libraries.

### 4. Environment Variables (Optional)

Create a `.env` file in the project root with the following settings:

```
DEBUG=false
AUTO_INITIALIZE=true
AUTO_PREPARE_DATA=true
```

### 5. Run the Application

```bash
cd direct_rag
streamlit run frontend/app.py
```

The application should start and open in your default web browser at `http://localhost:8501`.

## Troubleshooting

### Common Issues

1. **"Module not found" errors**:
   - Ensure you've activated the virtual environment
   - Try reinstalling the requirements: `pip install -r requirements.txt`

2. **Memory errors when loading models**:
   - Your system might not have enough RAM
   - Try closing other applications to free up memory

3. **Application is slow to start**:
   - The first start downloads and initializes models
   - Subsequent starts should be faster

4. **CUDA/GPU errors**:
   - If you have NVIDIA GPU, ensure you have installed CUDA
   - If you don't have a supported GPU, models will run on CPU (slower)

## Additional Configuration

### Using a Different Port

```bash
streamlit run frontend/app.py --server.port=8502
```

### Running in Production Mode

```bash
streamlit run frontend/app.py --server.headless=true
```

### Advanced Configuration

For advanced settings, you can create a `.streamlit/config.toml` file with customized configuration:

```toml
[server]
port = 8501
enableCORS = false
enableXsrfProtection = true

[browser]
serverAddress = "localhost"
gatherUsageStats = false
```

## Upgrading

To upgrade to a newer version:

1. Pull the latest changes:
   ```bash
   git pull origin main
   ```

2. Update dependencies:
   ```bash
   pip install -r requirements.txt --upgrade
   ```

3. Restart the application.

## Uninstalling

To uninstall:

1. Deactivate the virtual environment:
   ```bash
   deactivate
   ```

2. Delete the project directory and virtual environment:
   ```bash
   # On Windows
   rmdir /s /q medik

   # On macOS/Linux
   rm -rf medik
   ``` 