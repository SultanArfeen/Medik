"""
Streamlit Web Interface for Medik - Personal AI Doctor.

This module provides a web interface for the medical diagnostic assistant
using Streamlit.
"""

import os
import sys
import time
import json
import logging
import streamlit as st
from dotenv import load_dotenv
import nltk
from pathlib import Path
import threading
import re
import random

# Add parent directory to path for imports
parent_dir = Path(__file__).parent.parent.absolute()
sys.path.append(str(parent_dir))

# Load environment variables
load_dotenv()

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("app")

# Pre-download NLTK resources
try:
    nltk.download('punkt', quiet=True)
    nltk.download('stopwords', quiet=True)
except Exception as e:
    logger.warning(f"Failed to download NLTK resources: {e}")

# Initialize session state variables
if "initialized" not in st.session_state:
    st.session_state.initialized = False
if "data_prepared" not in st.session_state:
    st.session_state.data_prepared = False
if "query_history" not in st.session_state:
    st.session_state.query_history = []
if "current_question_type" not in st.session_state:
    st.session_state.current_question_type = "general"
if "structured_answers" not in st.session_state:
    st.session_state.structured_answers = {}
if "patient_info" not in st.session_state:
    st.session_state.patient_info = {
        "age": None,
        "gender": None,
        "main_symptom": None,
        "symptom_duration": None,
        "pain_level": None,
        "current_medications": None,
        "family_history": None,
        "previous_treatment": None
    }
if "assessment_stage" not in st.session_state:
    st.session_state.assessment_stage = "main_symptom"
if "processing" not in st.session_state:
    st.session_state.processing = False
if "pipeline_loading" not in st.session_state:
    st.session_state.pipeline_loading = False
if "suggestions_visible" not in st.session_state:
    st.session_state.suggestions_visible = False
if "query_input" not in st.session_state:
    st.session_state.query_input = ""
if "system_initialized" not in st.session_state:
    st.session_state.system_initialized = False
if "data_prepared" not in st.session_state:
    st.session_state.data_prepared = False
if "demo_mode" not in st.session_state:
    st.session_state.demo_mode = False

# Configure Streamlit page
st.set_page_config(
    page_title="Medik - Personal AI Doctor",
    page_icon="➕",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS styling
st.markdown("""
<style>
    /* Dark theme with black, blue, green, white */
    :root {
        --primary-green: #4CAF50;
        --secondary-green: #2E7D32;
        --light-green: #A5D6A7;
        --primary-blue: #1565C0;
        --dark-blue: #0D47A1;
        --light-blue: #90CAF9;
        --dark-bg: #121212;
        --dark-card: #1E1E1E;
        --dark-panel: #242526;
        --medium-gray: #424242;
        --light-gray: #757575;
        --white-text: #FFFFFF;
        --off-white: #E0E0E0;
        --highlight: #64FFDA;
    }
    
    /* Main app background - dark */
    .stApp {
        background-color: var(--dark-bg);
        color: var(--white-text);
        background-image: linear-gradient(135deg, #121212 0%, #0D47A1 100%);
    }
    
    /* Improved scrolling behavior */
    html {
        scroll-behavior: smooth !important;
    }
    
    /* Sidebar styling - darker blue */
    [data-testid="stSidebar"] {
        background-color: var(--dark-panel);
        padding: 1rem 0;
        border-right: 1px solid var(--primary-blue);
    }
    
    /* Container backgrounds */
    .css-1d391kg, .css-18e3th9 {
        background-color: transparent !important;
    }
    
    /* Widget backgrounds */
    div.stTextInput > div > div, div.stSelectbox > div > div {
        background-color: var(--dark-card);
        border: 1px solid var(--primary-green);
        color: var(--white-text);
    }
    
    /* Text and inputs */
    input, textarea, .stTextInput>div>div>input, .stTextArea>div>div>textarea {
        color: var(--white-text) !important;
        background-color: var(--dark-panel) !important;
    }
    
    /* Select dropdowns */
    .stSelectbox > div > div > div {
        background-color: var(--dark-panel);
        color: var(--white-text);
    }
    
    /* All text in white */
    .stMarkdown, p, span, label, .stText {
        color: var(--white-text) !important;
    }
    
    /* Headers in green */
    h1, h2, h3, h4, h5, h6 {
        color: var(--primary-green) !important;
    }
    
    /* Header styling */
    .main-header {
        font-size: 2.5rem;
        color: var(--primary-green) !important;
        text-align: center; 
        margin-bottom: 1rem;
        font-weight: bold;
        text-shadow: 0 2px 4px rgba(0,0,0,0.3);
    }
    
    .sub-header {
        font-size: 1.5rem;
        color: var(--light-green) !important;
        margin-bottom: 1rem;
        font-weight: 500;
    }
    
    /* Container styling */
    .result-container {
        background-color: var(--dark-card);
        padding: 1.5rem;
        border-radius: 10px;
        border-left: 5px solid var(--primary-green);
        margin: 1rem 0;
        box-shadow: 0 4px 8px rgba(0,0,0,0.3);
    }
    
    .info-box {
        background-color: rgba(76, 175, 80, 0.15);
        padding: 1.2rem;
        border-radius: 10px;
        border-left: 5px solid var(--primary-green);
        margin: 1rem 0;
        color: var(--white-text);
    }
    
    .success-box {
        background-color: rgba(76, 175, 80, 0.15);
        padding: 1.2rem;
        border-radius: 10px;
        border-left: 5px solid var(--primary-green);
        margin: 1rem 0;
        color: var(--white-text);
    }
    
    .warning-box {
        background-color: rgba(255, 193, 7, 0.15);
        padding: 1.2rem;
        border-radius: 10px;
        border-left: 5px solid #FFC107;
        margin: 1rem 0;
        color: var(--white-text);
    }
    
    .error-box {
        background-color: rgba(244, 67, 54, 0.15);
        padding: 1.2rem;
        border-radius: 10px;
        border-left: 5px solid #F44336;
        margin: 1rem 0;
        color: var(--white-text);
    }
    
    /* Sidebar content styling */
    .sidebar-content {
        padding: 1.2rem;
        background-color: var(--dark-panel);
        border-radius: 10px;
        margin: 0.5rem;
        box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        border: 1px solid var(--primary-blue);
    }
    
    /* Button styling */
    .suggestion-btn {
        width: 100%;
        margin: 0.2rem 0;
        background-color: var(--dark-panel);
        border: 1px solid var(--primary-green);
        color: var(--white-text);
        border-radius: 5px;
        padding: 0.5rem;
        text-align: center;
        cursor: pointer;
        transition: background-color 0.3s;
    }
    
    .suggestion-btn:hover {
        background-color: var(--primary-green);
        color: var(--dark-bg);
    }
    
    .stButton>button {
        background-color: var(--primary-green);
        color: var(--dark-bg);
        font-weight: 500;
        border-radius: 6px;
        border: none;
        padding: 0.5rem 1rem;
        transition: all 0.3s ease;
    }
    
    .stButton>button:hover {
        background-color: var(--secondary-green);
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.3);
    }
    
    /* Processing button style - make it more visible when clicked */
    button[data-testid="baseButton-secondary"]:active,
    button[data-testid="baseButton-primary"]:active {
        transform: scale(0.95);
        box-shadow: 0 2px 4px rgba(0,0,0,0.3) inset;
    }
    
    /* Tab styling */
    .stTabs [data-baseweb="tab-list"] {
        gap: 2px;
        background-color: var(--dark-panel);
    }

    .stTabs [data-baseweb="tab"] {
        background-color: var(--dark-blue);
        border-radius: 4px 4px 0 0;
        padding: 0.75rem 1rem;
        color: var(--white-text);
    }

    .stTabs [aria-selected="true"] {
        background-color: var(--primary-green) !important;
        color: var(--dark-bg) !important;
    }
    
    .tab-content {
        padding: 1rem 0;
    }
    
    /* Assessment boxes */
    .symptom-box {
        background-color: rgba(33, 150, 243, 0.15);
        padding: 1.2rem;
        border-radius: 10px;
        margin: 1rem 0;
        border-left: 4px solid var(--primary-blue);
        box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    }
    
    .patient-info-box {
        background-color: rgba(156, 39, 176, 0.15);
        padding: 1.2rem;
        border-radius: 10px;
        margin: 1rem 0;
        border-left: 4px solid #9C27B0;
        box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    }
    
    .assessment-box {
        background-color: rgba(0, 188, 212, 0.15);
        padding: 1.2rem;
        border-radius: 10px;
        margin: 1rem 0;
        border-left: 4px solid #00BCD4;
        box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    }
    
    .doctor-advice {
        background-color: rgba(76, 175, 80, 0.15);
        padding: 1.5rem;
        border-radius: 10px;
        margin: 1rem 0;
        border-left: 5px solid var(--primary-green);
        box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        scroll-margin-top: 20px; /* Space at the top when auto-scrolling */
    }
    
    /* Card styling */
    .disease-card {
        background-color: var(--dark-card);
        border-radius: 8px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        padding: 15px;
        margin-bottom: 15px;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        border: 1px solid var(--primary-blue);
    }
    
    .disease-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.3);
        border-color: var(--primary-green);
    }
    
    /* TOP BAR STYLING - Green accent on dark */
    header {
        display: none;
    }
    
    header[data-testid="stHeader"] {
        display: none;
    }
    
    .main > div:first-child {
        padding-top: 0 !important;
        margin-top: 0 !important;
    }
    
    div.block-container {
        padding-top: 0 !important;
        margin-top: 0 !important;
    }
    
    /* Green top bar */
    .stApp::before {
        content: "";
        display: block;
        background: linear-gradient(90deg, var(--primary-green) 0%, var(--primary-blue) 100%);
        height: 6px;
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        z-index: 9999;
    }
    
    /* Streamlit element fixes */
    section.main > div {
        padding-top: 0 !important;
        margin-top: 0 !important;
    }
    
    section.sidebar > div {
        padding-top: 0;
    }
    
    /* Logo styling */
    .logo-container {
        display: flex;
        align-items: center;
        justify-content: center;
        margin-bottom: 0.5rem;
        padding-top: 0 !important;
    }
    
    .logo-emoji {
        font-size: 1.8rem;
        color: var(--primary-green);
        margin-right: 0.5rem;
    }
    
    /* Dropdown suggestions */
    .dropdown-suggestions {
        background-color: var(--dark-card);
        border-radius: 6px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        max-height: 200px;
        overflow-y: auto;
        position: relative;
        z-index: 1000;
        margin-top: 0.3rem;
        border: 1px solid var(--primary-green);
    }
    
    .suggestion-item {
        padding: 0.6rem 1rem;
        cursor: pointer;
        border-bottom: 1px solid var(--medium-gray);
        transition: background-color 0.2s;
        color: var(--white-text);
    }
    
    .suggestion-item:hover {
        background-color: var(--primary-blue);
    }
    
    /* Hide Streamlit's default footer */
    footer {display: none !important;}
    
    .stApp {
        margin-top: 0 !important;
    }
    
    /* Additional fixes for white space */
    .css-18e3th9 {
        padding-top: 0 !important;
    }
    
    .css-1d391kg {
        padding-top: 0 !important;
    }
    
    div[data-testid="stVerticalBlock"] {
        padding-top: 0 !important;
    }
    
    div[data-testid="stToolbar"] {
        display: none !important;
    }
    
    .appview-container .main .block-container {
        padding-top: 0 !important;
        margin-top: 0 !important;
    }
    
    /* Replace white top bar with green accent */
    .stApp > div:first-child {
        border-top: 5px solid var(--primary-green) !important;
    }
    
    /* Fix for any white borders at the top */
    .withScreencast, .withScreencast div {
        border-top: none !important;
    }
    
    /* Fix for first container in sidebar */
    [data-testid="stSidebar"] [data-testid="stBlock"] {
        padding-top: 0 !important;
    }
    
    /* Fix for white header */
    [data-testid="stHeader"] {
        background-color: var(--dark-bg) !important;
        height: 0 !important;
        padding: 0 !important;
        margin: 0 !important;
        min-height: 0 !important;
        visibility: hidden !important;
    }
    
    /* Text input styling */
    textarea, input[type="text"], div[data-baseweb="select"] {
        border-radius: 6px !important;
        border: 1px solid var(--primary-green) !important;
        background-color: var(--dark-panel) !important;
        color: var(--white-text) !important;
        transition: all 0.3s ease;
    }
    
    textarea:focus, input[type="text"]:focus {
        border-color: var(--highlight) !important;
        box-shadow: 0 0 0 1px var(--highlight) !important;
    }
    
    /* Enhance widget containers */
    div.stSelectbox, div.stTextInput, div.stTextArea, div.stNumberInput {
        background-color: transparent;
        border-radius: 8px;
        padding: 0.5rem 0;
        margin-bottom: 0.5rem;
    }
    
    /* Slider widget styling */
    div.stSlider {
        padding: 1rem 0;
        margin-bottom: 0.5rem;
    }
    
    /* Slider track and thumb colors */
    div.stSlider > div > div > div {
        background-color: var(--primary-green) !important;
    }
    
    div.stSlider > div > div > div > div {
        background-color: var(--dark-panel) !important;
        border: 2px solid var(--primary-green) !important;
    }
    
    /* Output area styling */
    div[data-testid="stExpander"] {
        border-radius: 8px;
        border: 1px solid var(--primary-blue);
        background-color: var(--dark-card);
        margin-bottom: 1rem;
    }
    
    div[data-testid="stExpander"] > div[role="button"] {
        color: var(--light-green);
    }
    
    /* Custom scrollbar */
    ::-webkit-scrollbar {
        width: 10px;
        height: 10px;
    }
    
    ::-webkit-scrollbar-track {
        background: var(--dark-panel);
    }
    
    ::-webkit-scrollbar-thumb {
        background: var(--primary-green);
        border-radius: 5px;
    }
    
    ::-webkit-scrollbar-thumb:hover {
        background: var(--secondary-green);
    }
    
    /* Syntax highlighting for code blocks */
    pre {
        background-color: var(--dark-panel) !important;
        color: var(--light-green) !important;
        border: 1px solid var(--primary-blue) !important;
    }
    
    code {
        color: var(--light-green) !important;
        background-color: rgba(76, 175, 80, 0.1) !important;
        padding: 0.2em 0.4em !important;
        border-radius: 3px !important;
    }
    
    /* Radio button styling */
    .stRadio > div {
        background-color: var(--dark-card) !important;
        padding: 0.5rem;
        border-radius: 5px;
    }
    
    /* Links styling */
    a, a:visited {
        color: var(--light-green) !important;
        text-decoration: none;
    }
    
    a:hover {
        text-decoration: underline;
        color: var(--highlight) !important;
    }
    
    /* Checkbox styling */
    .stCheckbox > div > label > div {
        background-color: var(--dark-panel) !important;
        border-color: var(--primary-green) !important;
    }
    
    .stCheckbox > div > label > div[data-checked="true"] {
        background-color: var(--primary-green) !important;
    }
    
    /* Sidebar brand styling */
    .sidebar-brand {
        background-color: rgba(76, 175, 80, 0.2);
        border-radius: 10px;
        padding: 1rem;
        margin-bottom: 1rem;
        border: 1px solid var(--primary-green);
    }
    
    /* Processing indicators */
    .stSpinner {
        margin-top: 10px !important;
        margin-bottom: 10px !important;
    }
    
    .stWarning, .stInfo, .stSuccess, .stError {
        font-weight: 500 !important;
        padding: 0.8rem 1rem !important;
        border-radius: 8px !important;
        margin: 1rem 0 !important;
    }
    
    /* Fix any contrast issues with info messages */
    div.stAlert {
        background-color: var(--dark-panel) !important;
        color: var(--white-text) !important;
    }
    
    div.stAlert a {
        color: var(--highlight) !important;
    }
    
    /* Progress bar styling */
    div.stProgress > div > div {
        background-color: var(--primary-green) !important;
    }
    
    div.stProgress {
        background-color: var(--dark-panel) !important;
    }
    
    /* Fix for any remaining whitespace */
    .block-container {
        padding-top: 0 !important;
        padding-bottom: 0 !important;
        margin-top: 0 !important;
    }
    
    /* Fix select dropdown options */
    li[role="option"] {
        background-color: var(--dark-card) !important;
        color: var(--white-text) !important;
    }
    
    li[role="option"]:hover, li[role="option"][data-highlighted="true"] {
        background-color: var(--primary-blue) !important;
        color: var(--white-text) !important;
    }
    
    ul[role="listbox"] {
        background-color: var(--dark-card) !important;
        border: 1px solid var(--primary-green) !important;
    }
    
    /* Auto-scroll script */
    @media screen {
        .auto-scroll-result:empty + script {
            display: block;
        }
    }
    
    /* Improved spacing for readability */
    .st-emotion-cache-1kyxreq {
        padding-top: 2rem !important;
        padding-bottom: 2rem !important;
    }
</style>

<script>
    // Function to handle auto-scrolling
    function autoScrollToResults() {
        const resultElement = document.querySelector('.doctor-advice');
        if (resultElement) {
            resultElement.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    }
    
    // Set up a mutation observer to watch for results
    const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            if (mutation.addedNodes.length) {
                const doctorAdvice = document.querySelector('.doctor-advice');
                if (doctorAdvice) {
                    autoScrollToResults();
                }
            }
        });
    });
    
    // Start observing the document
    observer.observe(document.body, { childList: true, subtree: true });
    
    // Also scroll on load if results are present
    window.addEventListener('load', function() {
        setTimeout(autoScrollToResults, 500);
    });
</script>
""", unsafe_allow_html=True)

# Dictionary of structured questions and their suggested answers
STRUCTURED_QUESTIONS = {
    "heart_failure": {
        "title": "Heart Condition Assessment",
        "questions": [
            {"id": "shortness_of_breath", "text": "Are you experiencing shortness of breath?", 
             "suggestions": ["Yes, at rest", "Yes, with minimal exertion", "Only with strenuous activity", "No"]},
            {"id": "swelling", "text": "Do you have swelling in your feet, ankles, or legs?", 
             "suggestions": ["Yes, severe", "Yes, moderate", "Yes, mild", "No"]},
            {"id": "fatigue", "text": "Are you experiencing unusual fatigue or weakness?", 
             "suggestions": ["Yes, extreme", "Yes, moderate", "Yes, mild", "No"]},
            {"id": "chest_pain", "text": "Do you experience chest pain or discomfort?", 
             "suggestions": ["Yes, severe", "Yes, moderate", "Yes, mild", "No"]},
            {"id": "family_history", "text": "Do you have a family history of heart disease?", 
             "suggestions": ["Yes, immediate family", "Yes, extended family", "No", "Unsure"]}
        ]
    },
    "diabetes": {
        "title": "Diabetes Assessment",
        "questions": [
            {"id": "frequent_urination", "text": "Are you experiencing frequent urination?", 
             "suggestions": ["Yes, constantly", "Yes, often", "Occasionally", "No"]},
            {"id": "thirst", "text": "Do you have increased thirst or hunger?", 
             "suggestions": ["Yes, extreme", "Yes, moderate", "Occasionally", "No"]},
            {"id": "weight_changes", "text": "Have you noticed unexplained weight loss?", 
             "suggestions": ["Yes, significant", "Yes, moderate", "Yes, slight", "No"]},
            {"id": "blurry_vision", "text": "Have you experienced blurry vision?", 
             "suggestions": ["Yes, frequently", "Yes, occasionally", "Rarely", "No"]},
            {"id": "family_history", "text": "Do you have a family history of diabetes?", 
             "suggestions": ["Yes, immediate family", "Yes, extended family", "No", "Unsure"]}
        ]
    },
    "respiratory": {
        "title": "Respiratory Assessment",
        "questions": [
            {"id": "cough", "text": "Do you have a cough?", 
             "suggestions": ["Yes, with phlegm", "Yes, dry", "Occasionally", "No"]},
            {"id": "fever", "text": "Do you have a fever?", 
             "suggestions": ["Yes, high (>101°F)", "Yes, low grade", "No", "Unsure"]},
            {"id": "chest_pain", "text": "Are you experiencing chest pain?", 
             "suggestions": ["Yes, severe", "Yes, when breathing deeply", "Occasionally", "No"]},
            {"id": "breathing", "text": "Are you having difficulty breathing?", 
             "suggestions": ["Yes, severe", "Yes, moderate", "Only with exertion", "No"]},
            {"id": "duration", "text": "How long have you had these symptoms?", 
             "suggestions": ["Less than 3 days", "3-7 days", "1-2 weeks", "More than 2 weeks"]}
        ]
    },
    "gastrointestinal": {
        "title": "Digestive System Assessment",
        "questions": [
            {"id": "abdominal_pain", "text": "Are you experiencing abdominal pain?", 
             "suggestions": ["Yes, severe", "Yes, moderate", "Yes, mild", "No"]},
            {"id": "nausea", "text": "Do you have nausea or vomiting?", 
             "suggestions": ["Yes, severe", "Yes, moderate", "Occasionally", "No"]},
            {"id": "bowel_changes", "text": "Have you noticed changes in bowel movements?", 
             "suggestions": ["Yes, diarrhea", "Yes, constipation", "Yes, both", "No"]},
            {"id": "appetite", "text": "Have you experienced changes in appetite?", 
             "suggestions": ["Significant decrease", "Slight decrease", "Increased", "No change"]},
            {"id": "duration", "text": "How long have you had these symptoms?", 
             "suggestions": ["Less than 24 hours", "1-3 days", "4-7 days", "More than a week"]}
        ]
    },
    "neurological": {
        "title": "Neurological Assessment",
        "questions": [
            {"id": "headache", "text": "Are you experiencing headaches?", 
             "suggestions": ["Yes, severe", "Yes, moderate", "Yes, mild", "No"]},
            {"id": "dizziness", "text": "Do you feel dizzy or lightheaded?", 
             "suggestions": ["Yes, constantly", "Yes, frequently", "Occasionally", "No"]},
            {"id": "vision_changes", "text": "Have you noticed any changes in vision?", 
             "suggestions": ["Yes, significant", "Yes, moderate", "Slightly", "No"]},
            {"id": "numbness", "text": "Do you have numbness or tingling in any part of your body?", 
             "suggestions": ["Yes, severe", "Yes, moderate", "Occasionally", "No"]},
            {"id": "confusion", "text": "Have you experienced confusion or memory problems?", 
             "suggestions": ["Yes, frequently", "Yes, occasionally", "Rarely", "No"]}
        ]
    },
    "dermatological": {
        "title": "Skin Condition Assessment",
        "questions": [
            {"id": "rash", "text": "Do you have a rash or unusual skin changes?", 
             "suggestions": ["Yes, widespread", "Yes, localized", "Yes, mild", "No"]},
            {"id": "itching", "text": "Are you experiencing itching?", 
             "suggestions": ["Yes, severe", "Yes, moderate", "Occasionally", "No"]},
            {"id": "skin_color", "text": "Have you noticed any changes in skin color?", 
             "suggestions": ["Yes, redness", "Yes, paleness", "Yes, yellowing", "No"]},
            {"id": "skin_texture", "text": "Have you noticed changes in skin texture?", 
             "suggestions": ["Yes, dryness", "Yes, oiliness", "Yes, thickening", "No"]},
            {"id": "duration", "text": "How long have you had these symptoms?", 
             "suggestions": ["Less than a day", "Several days", "1-2 weeks", "More than 2 weeks"]}
        ]
    },
    "mental_health": {
        "title": "Mental Health Assessment",
        "questions": [
            {"id": "mood", "text": "Have you experienced changes in your mood?", 
             "suggestions": ["Yes, depression", "Yes, anxiety", "Yes, mood swings", "No"]},
            {"id": "sleep", "text": "Are you having trouble sleeping?", 
             "suggestions": ["Yes, can't fall asleep", "Yes, wake up frequently", "Yes, oversleeping", "No"]},
            {"id": "interest", "text": "Have you lost interest in activities you used to enjoy?", 
             "suggestions": ["Yes, completely", "Yes, partially", "Occasionally", "No"]},
            {"id": "concentration", "text": "Are you having trouble concentrating?", 
             "suggestions": ["Yes, significantly", "Yes, moderately", "Occasionally", "No"]},
            {"id": "duration", "text": "How long have you felt this way?", 
             "suggestions": ["Less than a week", "1-2 weeks", "Several weeks", "Months or longer"]}
        ]
    },
    "musculoskeletal": {
        "title": "Joint and Muscle Assessment",
        "questions": [
            {"id": "joint_pain", "text": "Are you experiencing joint pain?", 
             "suggestions": ["Yes, severe", "Yes, moderate", "Yes, mild", "No"]},
            {"id": "muscle_pain", "text": "Do you have muscle pain or weakness?", 
             "suggestions": ["Yes, severe", "Yes, moderate", "Yes, mild", "No"]},
            {"id": "swelling", "text": "Is there swelling in the affected area?", 
             "suggestions": ["Yes, significant", "Yes, moderate", "Yes, mild", "No"]},
            {"id": "mobility", "text": "Do you have difficulty moving the affected area?", 
             "suggestions": ["Yes, severe limitation", "Yes, moderate limitation", "Slightly limited", "No"]},
            {"id": "duration", "text": "How long have you had these symptoms?", 
             "suggestions": ["Less than a day", "Several days", "1-2 weeks", "More than 2 weeks"]}
        ]
    }
}

# Demo queries for each category
DEMO_QUERIES = {
    "general": [
        "What are the warning signs of a serious health condition?",
        "How can I maintain a healthy lifestyle?",
        "What vaccinations are recommended for adults?",
        "How often should I have routine check-ups?",
        "What are general preventive health measures?"
    ],
    "heart_failure": [
        "What is ejection fraction and why is it important?",
        "What medications are used to treat heart failure?",
        "What lifestyle changes can help manage heart disease?",
        "What are the NYHA classifications for heart failure?",
        "What are the warning signs of a heart attack?"
    ],
    "diabetes": [
        "What is the difference between Type 1 and Type 2 diabetes?",
        "What are normal blood glucose levels?",
        "What complications can arise from untreated diabetes?",
        "How is HbA1c used in diabetes diagnosis and monitoring?",
        "What dietary guidelines are recommended for diabetic patients?"
    ],
    "respiratory": [
        "What is the difference between COVID-19, flu, and common cold?",
        "How is pneumonia diagnosed and treated?",
        "What are effective treatments for asthma?",
        "When should I seek emergency care for breathing problems?",
        "How can I improve my lung capacity and respiratory health?"
    ],
    "gastrointestinal": [
        "What causes acid reflux and how can it be treated?",
        "How are inflammatory bowel diseases diagnosed?",
        "What diet is recommended for irritable bowel syndrome?",
        "What are the warning signs of appendicitis?",
        "How do I know if I have a food intolerance?"
    ],
    "neurological": [
        "What are the early warning signs of stroke?",
        "How are migraines different from regular headaches?",
        "What causes seizures and how are they treated?",
        "What are the symptoms of multiple sclerosis?",
        "How is Parkinson's disease diagnosed and managed?"
    ],
    "dermatological": [
        "How can I identify different types of skin rashes?",
        "What treatments are effective for eczema?",
        "How do I know if a mole might be cancerous?",
        "What causes psoriasis and how is it treated?",
        "What are effective treatments for acne?"
    ],
    "mental_health": [
        "How is clinical depression diagnosed?",
        "What are effective treatments for anxiety disorders?",
        "How can I improve my sleep hygiene?",
        "What are the symptoms of bipolar disorder?",
        "When should I seek professional help for mental health?"
    ],
    "musculoskeletal": [
        "What causes arthritis and how is it treated?",
        "How can I prevent repetitive strain injuries?",
        "What's the difference between a sprain and a strain?",
        "How is fibromyalgia diagnosed and managed?",
        "What are effective exercises for back pain?"
    ]
}

def initialize_pipeline():
    """Initialize the RAG pipeline."""
    try:
        if "pipeline" not in st.session_state:
            # Set loading flag
            st.session_state.pipeline_loading = True
            
            # Create a simple demo pipeline instead of importing the heavyweight one
            st.session_state.pipeline = create_demo_pipeline()
            
            # Set initialized flag
            st.session_state.system_initialized = True
            st.session_state.pipeline_loading = False
            
            # Log successful initialization
            logging.info("Pipeline initialized successfully in demo mode")
            return True
        return True
    except Exception as e:
        # Log error
        logging.error(f"Error initializing pipeline: {str(e)}")
        
        # Create a fallback demo pipeline
        st.session_state.pipeline = create_demo_pipeline()
        st.session_state.system_initialized = True
        st.session_state.pipeline_loading = False
        st.session_state.demo_mode = True
        
        # Log fallback
        logging.info("Using demo pipeline as fallback")
        return True

def create_demo_pipeline():
    """Create a simple demo pipeline for medical response generation."""
    import re
    import random
    import logging
    
    class DemoPipeline:
        def __init__(self):
            self.retriever = None
            self.generator = None
            self.logger = logging.getLogger(__name__)
        
        def process_query(self, query, top_k=5, timeout=30):
            """Process a query and generate a response based on keywords and symptom patterns."""
            query_lower = query.lower()
            self.logger.info(f"Processing query: {query[:100]}...")
            
            # Determine if this is a respiratory condition
            is_respiratory = any(term in query_lower for term in ["respir", "breath", "cough", "wheez", "lung"])
            is_cardiovascular = any(term in query_lower for term in ["heart", "chest pain", "cardio", "blood pressure"])
            is_diabetes = any(term in query_lower for term in ["diabet", "blood sugar", "insulin", "glucose"])
            
            # Get structured data if available
            patient_info = {}
            if "user profile:" in query_lower:
                profile_section = query.split("User Profile:")[1].split("\n")[0]
                if "age" in profile_section.lower():
                    age_match = re.search(r"Age (\d+)", profile_section)
                    if age_match:
                        patient_info["age"] = age_match.group(1)
                if "gender" in profile_section.lower():
                    gender_match = re.search(r"Gender ([A-Za-z]+)", profile_section)
                    if gender_match:
                        patient_info["gender"] = gender_match.group(1)
                        
            # Extract symptoms for respiratory conditions
            symptoms = {}
            if "respiratory assessment:" in query_lower:
                section = query.split("Respiratory Assessment:")[1]
                section = section.split("\n\n")[0] if "\n\n" in section else section
                
                for line in section.split("\n"):
                    if line.startswith("- ") and ":" in line:
                        key, value = line.replace("- ", "").split(":", 1)
                        symptoms[key.strip()] = value.strip()
                
                # Check for common respiratory symptoms
                has_cough = any(s in query_lower for s in ["cough", "phlegm"])
                has_shortness_of_breath = "breath" in query_lower or "difficult" in query_lower and "breath" in query_lower
                has_wheezing = "wheez" in query_lower
                has_chest_pain = "chest" in query_lower and "pain" in query_lower
            
            # Generate response based on condition type
            if is_respiratory:
                answer = self._generate_respiratory_response(symptoms, patient_info, query_lower)
            elif is_cardiovascular:
                answer = self._generate_cardiovascular_response(query_lower, patient_info)
            elif is_diabetes:
                answer = self._generate_diabetes_response(query_lower, patient_info)
            else:
                answer = self._generate_simple_response(query_lower)
            
            # Add medical disclaimer
            answer += "\n\n*DISCLAIMER: This information is for educational purposes only and should not replace professional medical advice. Please consult with a healthcare professional for proper diagnosis and treatment.*"
            
            # Return structured response
            return {
                "query": query,
                "answer": answer,
                "query_time": random.uniform(0.5, 1.5),
                "retrieved_documents": self._get_mock_documents(is_respiratory, is_cardiovascular, is_diabetes)
            }
        
        def prepare_data(self, cache_data=True):
            """Dummy prepare_data method to satisfy interface requirements."""
            self.logger.info("Demo pipeline doesn't need to prepare data. Using mock data.")
            return True
        
        def _generate_respiratory_response(self, symptoms, patient_info, query_text):
            """Generate detailed response for respiratory symptoms."""
            # Check for specific symptoms in query text
            has_cough = "cough" in query_text
            has_phlegm = "phlegm" in query_text or "productive" in query_text
            has_shortness_of_breath = "breath" in query_text and ("short" in query_text or "difficult" in query_text)
            has_wheezing = "wheez" in query_text
            has_chest_pain = "chest" in query_text and "pain" in query_text
            
            response = ["# Respiratory Assessment"]
            
            # Add personalized intro
            age = patient_info.get("age", "")
            gender = patient_info.get("gender", "")
            if age and gender:
                response.append(f"\nBased on your profile as a {age}-year-old {gender}, I've analyzed your respiratory symptoms.")
            else:
                response.append("\nBased on the information you've provided about your respiratory symptoms, I've prepared the following assessment.")
            
            # Symptom summary
            response.append("\n## Symptom Summary")
            symptom_list = []
            
            if has_cough:
                if has_phlegm:
                    symptom_list.append("productive cough with phlegm")
                else:
                    symptom_list.append("dry cough")
            
            if has_shortness_of_breath:
                if "rest" in query_text:
                    symptom_list.append("shortness of breath at rest")
                elif "exertion" in query_text or "activity" in query_text or "exercise" in query_text:
                    symptom_list.append("shortness of breath with exertion")
                else:
                    symptom_list.append("shortness of breath")
            
            if has_wheezing:
                symptom_list.append("wheezing")
            
            if has_chest_pain:
                symptom_list.append("chest pain during breathing")
            
            if "fever" in query_text:
                symptom_list.append("fever")
            
            # Format the symptom list nicely
            if symptom_list:
                if len(symptom_list) == 1:
                    response.append(f"You're experiencing {symptom_list[0]}.")
                elif len(symptom_list) == 2:
                    response.append(f"You're experiencing {symptom_list[0]} and {symptom_list[1]}.")
                else:
                    response.append(f"You're experiencing {', '.join(symptom_list[:-1])}, and {symptom_list[-1]}.")
            else:
                response.append("You're experiencing respiratory symptoms.")
            
            # Duration if available
            duration = ""
            for key, value in symptoms.items():
                if "duration" in key.lower() and value:
                    duration = value
                    break
            
            if duration:
                response.append(f"These symptoms have been present for approximately {duration} days.")
            
            # Possible diagnoses
            response.append("\n## Possible Diagnoses")
            
            if has_cough:
                if has_phlegm:
                    response.append("- **Acute Bronchitis**: Inflammation of the bronchial tubes, often following a cold.")
                    if "fever" in query_text:
                        response.append("- **Pneumonia**: Infection of the lung tissue that can cause productive cough and fever.")
                else:
                    response.append("- **Upper Respiratory Infection**: Viral infection affecting the nose, throat, and sinuses.")
                    if "throat" in query_text:
                        response.append("- **Pharyngitis/Laryngitis**: Inflammation of the throat or voice box.")
            
            if has_shortness_of_breath:
                if has_wheezing:
                    response.append("- **Asthma**: Inflammatory condition causing airway constriction and wheezing.")
                if "rest" in query_text:
                    response.append("- **COVID-19/Pneumonia**: Infections that can cause significant breathing difficulty.")
                if "chronic" in query_text or (age and int(age) > 50):
                    response.append("- **COPD**: Chronic condition including emphysema and chronic bronchitis, more common in older adults.")
            
            if has_chest_pain:
                response.append("- **Pleurisy**: Inflammation of the tissues lining the lungs and chest cavity.")
                if has_shortness_of_breath:
                    response.append("- **Pulmonary Embolism**: Blood clot in the lungs (a medical emergency if severe).")
            
            # Recommended tests
            response.append("\n## Recommended Assessments")
            response.append("- Physical examination including lung auscultation")
            response.append("- Pulse oximetry to measure blood oxygen levels")
            
            if has_shortness_of_breath or has_wheezing:
                response.append("- Pulmonary function tests to assess lung capacity and airflow")
                response.append("- Chest X-ray to examine lung fields")
            
            if "fever" in query_text:
                response.append("- Complete blood count to check for infection")
                response.append("- COVID-19 and influenza testing")
            
            if has_chest_pain and has_shortness_of_breath:
                response.append("- D-dimer blood test to help rule out blood clots")
                response.append("- Possibly chest CT scan for more detailed imaging")
            
            # Treatment recommendations
            response.append("\n## Treatment Considerations")
            
            if has_cough:
                if has_phlegm:
                    response.append("- Increased fluid intake to thin mucus")
                    response.append("- Humidifier to moisten air and ease breathing")
                else:
                    response.append("- Cough suppressants for nonproductive cough (if needed for comfort)")
            
            if has_shortness_of_breath:
                if has_wheezing:
                    response.append("- Bronchodilators to relax airway muscles and improve airflow")
                    response.append("- Inhaled corticosteroids to reduce inflammation (for conditions like asthma)")
                response.append("- Proper positioning to optimize breathing (semi-upright position)")
            
            response.append("- Rest and adequate hydration")
            response.append("- Avoiding respiratory irritants like smoke and pollution")
            
            # Urgency guidance
            response.append("\n## When to Seek Immediate Care")
            response.append("**Seek emergency medical attention if you experience:**")
            response.append("- Severe shortness of breath or inability to catch your breath")
            response.append("- Blue discoloration of lips or face")
            response.append("- Confusion or altered mental state")
            response.append("- Severe, sudden chest pain")
            response.append("- High fever with severe symptoms")
            
            return "\n".join(response)
        
        def _generate_cardiovascular_response(self, query_text, patient_info):
            """Generate response for cardiovascular queries."""
            has_chest_pain = "chest" in query_text and "pain" in query_text
            has_pressure = "pressure" in query_text
            has_palpitations = "palpitation" in query_text or "racing" in query_text or "heart racing" in query_text
            
            response = ["# Cardiovascular Assessment"]
            
            # Add personalized intro
            age = patient_info.get("age", "")
            gender = patient_info.get("gender", "")
            if age and gender:
                response.append(f"\nBased on your profile as a {age}-year-old {gender}, I've analyzed your cardiovascular symptoms.")
            else:
                response.append("\nBased on the information you've provided about your heart-related symptoms, I've prepared the following assessment.")
            
            # Generate appropriate cardiovascular guidance based on the symptoms
            response.append("\n## Important Guidance on Heart Health")
            
            if has_chest_pain:
                response.append("Chest pain or discomfort can have many causes, ranging from heart problems to digestive or musculoskeletal issues. Heart-related chest pain often feels like pressure, squeezing, or fullness rather than sharp pain.")
                
                if has_pressure or "left arm" in query_text or "jaw" in query_text:
                    response.append("\n**IMPORTANT: If you're experiencing chest pressure/pain that radiates to your jaw, arm, or back, especially with shortness of breath, sweating, or nausea, this could indicate a heart attack. Seek emergency medical attention immediately.**")
            
            if has_palpitations:
                response.append("\nHeart palpitations (awareness of your heartbeat) can be caused by anxiety, caffeine, certain medications, thyroid problems, or various heart rhythm disorders.")
            
            # Common heart condition information
            response.append("\n## Common Cardiovascular Conditions")
            response.append("- **Coronary Artery Disease**: Narrowing of heart arteries that can lead to chest pain (angina) and heart attacks")
            response.append("- **Hypertension**: High blood pressure that increases risk of heart attack, stroke, and other complications")
            response.append("- **Arrhythmias**: Irregular heartbeats that may feel like palpitations, racing, or skipping beats")
            response.append("- **Heart Failure**: When the heart can't pump efficiently, causing fatigue and fluid buildup")
            
            # Prevention tips
            response.append("\n## Heart Health Recommendations")
            response.append("- Maintain healthy blood pressure and cholesterol levels")
            response.append("- Eat a heart-healthy diet low in saturated fat and sodium")
            response.append("- Exercise regularly (aim for 150 minutes of moderate activity weekly)")
            response.append("- Avoid smoking and limit alcohol consumption")
            response.append("- Manage stress through relaxation techniques")
            response.append("- Take medications as prescribed by your doctor")
            
            # When to seek help
            response.append("\n## When to Seek Medical Attention")
            response.append("**Emergency (call 911/emergency services):**")
            response.append("- Chest pain/pressure lasting more than a few minutes")
            response.append("- Pain radiating to jaw, arm, or back")
            response.append("- Shortness of breath with chest discomfort")
            response.append("- Nausea, lightheadedness with chest symptoms")
            
            response.append("\n**Schedule a doctor's appointment for:**")
            response.append("- Recurrent palpitations")
            response.append("- Unusual fatigue or weakness")
            response.append("- Shortness of breath with mild exertion")
            response.append("- Swelling in legs or abdomen")
            
            return "\n".join(response)
        
        def _generate_diabetes_response(self, query_text, patient_info):
            """Generate response for diabetes-related queries."""
            response = ["# Diabetes Assessment"]
            
            # Add personalized intro
            age = patient_info.get("age", "")
            gender = patient_info.get("gender", "")
            if age and gender:
                response.append(f"\nBased on your profile as a {age}-year-old {gender}, I've analyzed your symptoms related to diabetes.")
            else:
                response.append("\nBased on the information you've provided regarding diabetes concerns, I've prepared the following assessment.")
            
            # General diabetes information
            response.append("\n## About Diabetes")
            response.append("Diabetes is a condition characterized by high blood sugar levels resulting from either insufficient insulin production (Type 1) or ineffective use of insulin (Type 2).")
            
            # Common symptoms
            response.append("\n## Common Diabetes Symptoms")
            response.append("- Frequent urination")
            response.append("- Excessive thirst")
            response.append("- Unexplained weight loss")
            response.append("- Increased hunger")
            response.append("- Fatigue")
            response.append("- Blurred vision")
            response.append("- Slow-healing wounds")
            response.append("- Tingling or numbness in hands/feet")
            
            # Risk factors
            response.append("\n## Risk Factors for Type 2 Diabetes")
            response.append("- Family history of diabetes")
            response.append("- Overweight or obesity")
            response.append("- Physical inactivity")
            response.append("- Age over 45")
            response.append("- History of gestational diabetes")
            response.append("- Prediabetes")
            response.append("- Certain ethnic backgrounds (higher risk in Black, Hispanic, Native American, and Asian American populations)")
            
            # Management
            response.append("\n## Diabetes Management")
            response.append("- Regular blood sugar monitoring")
            response.append("- Balanced diet focusing on consistent carbohydrate intake")
            response.append("- Regular physical activity")
            response.append("- Medication (oral medications and/or insulin as prescribed)")
            response.append("- Regular medical check-ups to monitor for complications")
            response.append("- Proper foot care and regular eye exams")
            
            # When to seek help
            response.append("\n## When to Contact a Healthcare Provider")
            response.append("- If you're experiencing classic diabetes symptoms")
            response.append("- Blood sugar readings consistently above target range")
            response.append("- Signs of low blood sugar (confusion, dizziness, shakiness)")
            response.append("- Signs of diabetic ketoacidosis (fruity breath, nausea, deep breathing)")
            
            return "\n".join(response)
        
        def _generate_simple_response(self, query):
            """Generate a simple response based on keywords in the query."""
            if "headache" in query or "migraine" in query:
                return ("# Headache Assessment\n\nHeadaches can range from tension-type (mild to moderate, band-like pressure) to migraines (moderate to severe, often with nausea and light sensitivity).\n\n"
                        "## Common Headache Types\n- **Tension headaches**: Often related to stress, poor posture, or eye strain\n- **Migraines**: May have triggers like certain foods, stress, hormonal changes, or environmental factors\n"
                        "- **Cluster headaches**: Severe pain typically around one eye\n- **Sinus headaches**: Associated with sinus congestion and infection\n\n"
                        "## Treatment Approaches\n- Over-the-counter pain relievers (acetaminophen, ibuprofen)\n- Staying hydrated\n- Rest in a quiet, dark room for migraines\n"
                        "- Stress management techniques\n- Identifying and avoiding personal triggers\n- Prescription medications for severe or frequent headaches\n\n"
                        "## When to Seek Medical Attention\n- Sudden, severe headache (\"thunderclap\")\n- Headache with fever, stiff neck, confusion\n- Headache after head injury\n"
                        "- New or different headache pattern after age 50\n- Headache with weakness, vision changes, or trouble speaking")
            
            elif "sleep" in query or "insomnia" in query:
                return ("# Sleep Issues Assessment\n\nSleep problems can significantly impact overall health and quality of life.\n\n"
                        "## Common Sleep Disorders\n- **Insomnia**: Difficulty falling or staying asleep\n- **Sleep apnea**: Breathing interruptions during sleep\n"
                        "- **Restless leg syndrome**: Uncomfortable sensations causing an urge to move legs\n- **Circadian rhythm disorders**: When your body's clock is out of sync\n\n"
                        "## Sleep Hygiene Recommendations\n- Maintain a consistent sleep schedule\n- Create a relaxing bedtime routine\n- Make your bedroom dark, quiet, and comfortable\n"
                        "- Limit screen time before bed\n- Avoid caffeine, large meals, and alcohol close to bedtime\n- Regular physical activity (but not too close to bedtime)\n\n"
                        "## When to Seek Medical Help\n- Persistent insomnia despite good sleep habits\n- Excessive daytime sleepiness\n- Loud snoring with gasping or choking\n"
                        "- Significant sleep disruption affecting daily functioning\n- Sleep problems with other health concerns")
            
            elif "anxiety" in query or "stress" in query or "depress" in query:
                return ("# Mental Health Assessment\n\nMental health is an essential component of overall wellness.\n\n"
                        "## Common Mental Health Concerns\n- **Anxiety**: Excessive worry, fear, or nervousness\n- **Depression**: Persistent sadness, loss of interest, low energy\n"
                        "- **Stress**: Physical and emotional tension in response to demands\n\n"
                        "## Coping Strategies\n- Regular physical activity\n- Mindfulness and meditation\n- Deep breathing exercises\n"
                        "- Maintaining social connections\n- Establishing healthy boundaries\n- Adequate sleep and nutrition\n"
                        "- Limiting alcohol and avoiding recreational drugs\n\n"
                        "## Professional Support Options\n- Talk therapy (cognitive behavioral therapy, etc.)\n- Medication when appropriate\n- Support groups\n"
                        "- Mental health apps and online resources\n\n"
                        "## When to Seek Immediate Help\n- Thoughts of harming yourself or others\n- Inability to perform daily functions\n- Severe mood changes\n"
                        "- Significant changes in eating or sleeping patterns\n- Excessive use of alcohol or drugs to cope")
            
            else:
                return ("# General Health Assessment\n\nBased on the information provided, here are some general health recommendations:\n\n"
                        "## Preventive Health Measures\n- Regular check-ups with healthcare providers\n- Age-appropriate health screenings\n- Vaccinations as recommended by health authorities\n"
                        "- Balanced nutrition with plenty of fruits, vegetables, and whole grains\n- Regular physical activity (aim for 150+ minutes per week)\n"
                        "- Adequate sleep (7-9 hours for most adults)\n- Stress management techniques\n- Avoiding tobacco and limiting alcohol\n\n"
                        "## When to Consult a Healthcare Provider\n- Persistent symptoms lasting more than a few days\n- Symptoms that interfere with daily activities\n"
                        "- Worsening of chronic conditions\n- Unusual changes in bodily functions\n- New or concerning physical changes\n\n"
                        "For specific health concerns, please provide more details about your symptoms for a more targeted assessment.")
        
        def _get_mock_documents(self, is_respiratory, is_cardiovascular, is_diabetes):
            """Return mock retrieved documents based on the condition type."""
            if is_respiratory:
                return [
                    {"title": "Respiratory Conditions Overview", "source": "Medical Encyclopedia", "content": "Respiratory conditions affect the lungs and other parts of the respiratory system. Common respiratory problems include asthma, bronchitis, COPD, pneumonia, and upper respiratory infections. Symptoms often include coughing, shortness of breath, wheezing, chest congestion, and chest pain."},
                    {"title": "When to Seek Emergency Care for Breathing Problems", "source": "Health Guidelines", "content": "Seek immediate medical attention if you experience severe shortness of breath, chest pain, blue discoloration of lips or face, rapid breathing, or confusion. These may indicate a serious condition requiring urgent care."}
                ]
            elif is_cardiovascular:
                return [
                    {"title": "Understanding Chest Pain", "source": "Cardiology Journal", "content": "Chest pain can originate from the heart, lungs, digestive system, or musculoskeletal structures. Cardiac chest pain (angina) typically feels like pressure, squeezing, or fullness and may radiate to the arm, jaw, or back. Risk factors include high blood pressure, high cholesterol, smoking, diabetes, and family history."},
                    {"title": "Heart Attack Warning Signs", "source": "American Heart Association", "content": "Warning signs of a heart attack include chest discomfort (pressure, squeezing, fullness), discomfort in other upper body areas (arm, back, neck, jaw), shortness of breath, and sometimes nausea, lightheadedness, or cold sweat. Women may experience less obvious symptoms like fatigue and shortness of breath."}
                ]
            elif is_diabetes:
                return [
                    {"title": "Diabetes Symptoms and Diagnosis", "source": "Endocrine Foundation", "content": "Common diabetes symptoms include frequent urination, excessive thirst, unexplained weight loss, extreme hunger, sudden vision changes, tingling in hands/feet, fatigue, dry skin, and slow-healing sores. Diagnosis typically involves blood tests including fasting glucose, A1C, and glucose tolerance tests."},
                    {"title": "Managing Diabetes", "source": "Diabetes Care", "content": "Diabetes management includes monitoring blood glucose, healthy eating, regular physical activity, and medication when necessary. Regular check-ups with healthcare providers are essential to monitor for complications affecting the eyes, kidneys, nerves, and cardiovascular system."}
                ]
            else:
                return [
                    {"title": "General Health Guidelines", "source": "Health Encyclopedia", "content": "Maintaining good health involves balanced nutrition, regular physical activity, adequate sleep, stress management, and routine preventive care. Regular check-ups with healthcare providers help identify potential health issues before they become serious."},
                    {"title": "When to See a Doctor", "source": "Medical Guidelines", "content": "Persistent symptoms lasting more than a few days, severe symptoms, symptoms interfering with daily activities, or worsening chronic conditions all warrant medical evaluation. Early intervention often leads to better outcomes."}
                ]
    
    return DemoPipeline()

def prepare_data():
    """Prepare data for the RAG system."""
    if not st.session_state.system_initialized:
        st.error("Pipeline not initialized. Please initialize first.")
        return False
    
    try:
        # Check if we're using the demo pipeline
        if hasattr(st.session_state.pipeline, 'prepare_data'):
            # Pre-process the data without waiting for user queries
            cache_file = Path("indexes") / "processed_data.cache"
            index_dir = Path("indexes")
            index_files = list(index_dir.glob("*.bin")) + list(index_dir.glob("*.pkl"))
            
            if cache_file.exists() and index_files:
                # Data is already cached and indexed
                st.session_state.data_prepared = True
                logger.info("Using cached data and existing indexes.")
                return True
                
            # Process data in stages with actual dataset
            st.session_state.pipeline.prepare_data(cache_data=True)
            st.session_state.data_prepared = True
            return True
        else:
            # Using demo pipeline without prepare_data method, just mark as prepared
            logger.info("Using demo pipeline without data preparation.")
            st.session_state.data_prepared = True
            return True
    except Exception as e:
        logger.error(f"Error preparing data: {str(e)}")
        # Still mark as prepared in demo mode
        st.session_state.data_prepared = True
        st.session_state.demo_mode = True
        return True

def process_query(query):
    """Process user query through the RAG pipeline."""
    start_time = time.time()  # Set a starting time for timeouts
    
    if not st.session_state.system_initialized or not st.session_state.data_prepared:
        st.error("System not initialized or data not prepared. Please complete setup first.")
        return None
    
    try:
        # Get top_k from session state or default to 5
        top_k = st.session_state.get("top_k", 5)
        
        # Process the query with a 30-second timeout
        result = st.session_state.pipeline.process_query(query, top_k=top_k, timeout=30)
        
        # Add query time if missing
        if "query_time" not in result:
            result["query_time"] = time.time() - start_time
        
        # Fix for response field name
        if "response" in result and "answer" not in result:
            result["answer"] = result["response"]
        
        # Clean up the response if needed
        if "answer" in result:
            # Remove any repeating "User Profile:" lines
            answer = result["answer"]
            if isinstance(answer, str):
                # Check for repetitive content patterns and fix them
                if answer.count("User Profile:") > 1 or answer.count("User:") > 2:
                    answer = clean_response_text(answer)
                
                # Replace answer with cleaned version
                result["answer"] = answer
        
        # Handle empty or None responses
        if not result.get("answer"):
            # Create a fallback response if the answer is empty
            result["answer"] = "I'm sorry, I couldn't generate a specific response for your query. This might be due to limited medical information on this topic. Please try rephrasing your question or providing more details."
        
        # Add to query history if successful
        if "answer" in result and result["answer"]:
            if "query_history" not in st.session_state:
                st.session_state.query_history = []
            st.session_state.query_history.append(result)
        
        return result
    except Exception as e:
        logger.error(f"Error processing query: {str(e)}")
        elapsed_time = time.time() - start_time
        
        # Create a fallback response
        fallback = {
            "query": query,
            "answer": f"I'm sorry, I encountered an error processing your query. This may be due to a timeout (elapsed time: {elapsed_time:.1f}s) or an internal error. Please try a simpler question or different wording.",
            "error": str(e),
            "query_time": elapsed_time,
            "retrieved_documents": []
        }
        
        # Still add to history for user reference
        if "query_history" not in st.session_state:
            st.session_state.query_history = []
        st.session_state.query_history.append(fallback)
        return fallback

def clean_response_text(text):
    """Clean up response text to remove repetitions and formatting issues."""
    if not text:
        return "No response was generated."
    
    # Split into lines and filter out repetitions
    lines = text.split("\n")
    cleaned_lines = []
    seen_headers = set()
    
    # Track identical consecutive lines to avoid repetition
    prev_line = None
    
    for line in lines:
        line_stripped = line.strip()
        
        # Skip empty lines
        if not line_stripped:
            # If we already have content, add a single empty line
            if cleaned_lines and prev_line != "":
                cleaned_lines.append("")
                prev_line = ""
            continue
        
        # Skip if identical to previous line
        if line_stripped == prev_line:
            continue
        
        # Handle repetitive headers like "User:" or "User Profile:"
        if any(header in line_stripped for header in ["User:", "User Profile:", "Patient:"]):
            header_key = line_stripped.lower()
            if header_key in seen_headers:
                continue
            seen_headers.add(header_key)
        
        # Add the line to cleaned output
        cleaned_lines.append(line_stripped)
        prev_line = line_stripped
    
    # Join the cleaned lines with proper spacing
    cleaned_text = "\n".join(cleaned_lines)
    
    # Check for and remove repetitive paragraphs
    paragraphs = cleaned_text.split("\n\n")
    unique_paragraphs = []
    seen_paragraphs = set()
    
    for para in paragraphs:
        para_key = para.lower().strip()
        if para_key and para_key not in seen_paragraphs:
            unique_paragraphs.append(para)
            seen_paragraphs.add(para_key)
    
    # Format medical information with consistent styling
    final_text = "\n\n".join(unique_paragraphs)
    
    # Add appropriate formatting for medical terms and advice
    final_text = re.sub(r'\*\*Medical advice:\*\*', '<div style="background-color: #e8f5e9; padding: 0.8rem; border-radius: 5px; margin: 1rem 0; border-left: 4px solid #4CAF50;"><strong>Medical Advice:</strong>', final_text)
    final_text = re.sub(r'\*\*Disclaimer:\*\*', '</div><div style="background-color: #fff8e1; padding: 0.8rem; border-radius: 5px; margin: 1rem 0; border-left: 4px solid #FFC107;"><strong>Disclaimer:</strong>', final_text)
    
    # Close any unclosed div tags
    if '<div' in final_text and '</div>' not in final_text:
        final_text += '</div>'
    
    return final_text

def generate_structured_query():
    """Generate a structured query from the structured answers and patient info."""
    question_type = st.session_state.current_question_type
    if question_type == "general":
        return None
    
    answers = st.session_state.structured_answers.get(question_type, {})
    if not answers:
        return None
    
    # Get patient info
    patient_age = st.session_state.patient_info.get("age", "Unknown")
    patient_gender = st.session_state.patient_info.get("gender", "Unknown")
    symptom_duration = st.session_state.patient_info.get("symptom_duration", "Unknown")
    pain_level = st.session_state.patient_info.get("pain_level", "Unknown")
    medications = st.session_state.patient_info.get("current_medications", "None")
    family_history = st.session_state.patient_info.get("family_history", "None")
    previous_treatment = st.session_state.patient_info.get("previous_treatment", "None")
    
    # Get the question data
    questions_data = STRUCTURED_QUESTIONS[question_type]
    
    # Build a query based on the answers
    query_parts = [
        f"Patient is a {patient_age} year old {patient_gender} with the following symptoms related to {question_type.replace('_', ' ')}:"
    ]
    
    # Add main symptom
    main_symptom = st.session_state.patient_info.get("main_symptom", "Unknown symptoms")
    query_parts.append(f"- Primary complaint: {main_symptom}")
    
    # Add symptom duration and pain level
    query_parts.append(f"- Duration of symptoms: {symptom_duration}")
    if pain_level > 0:
        query_parts.append(f"- Pain level reported as {pain_level}/10")
    
    # Add structured answers
    for question in questions_data["questions"]:
        q_id = question["id"]
        q_text = question["text"]
        if q_id in answers:
            query_parts.append(f"- {q_text} {answers[q_id]}")
    
    # Add medical history
    if medications and medications.lower() != "none":
        query_parts.append(f"- Current medications: {medications}")
    
    if family_history and family_history.lower() != "none":
        query_parts.append(f"- Family history: {family_history}")
    
    if previous_treatment and previous_treatment.lower() != "none":
        query_parts.append(f"- Previous treatments: {previous_treatment}")
    
    # Add appropriate closing question based on condition type
    if question_type == "heart_failure":
        query_parts.append("Based on this information, what is the likely cardiac condition and recommended next steps? Please provide possible diagnoses, recommended tests, and treatment options. Also indicate if urgent medical attention is needed.")
    
    elif question_type == "respiratory":
        query_parts.append("Based on this information, what is the likely respiratory condition and recommended next steps? Please provide possible diagnoses, recommended tests, and treatment options. Also indicate if urgent medical attention is needed.")
    
    elif question_type == "diabetes":
        query_parts.append("Based on this information, what is the likelihood this represents diabetes or another endocrine condition? What tests should be ordered to confirm the diagnosis and what initial management would you recommend?")
    
    elif question_type == "gastrointestinal":
        query_parts.append("Based on this information, what gastrointestinal conditions should be considered? What diagnostic tests would be appropriate and what treatments might help? Please indicate if any symptoms suggest a need for urgent care.")
    
    elif question_type == "neurological":
        query_parts.append("Based on this information, what neurological conditions should be considered? What diagnostic approach would you recommend and what treatments might be appropriate? Please indicate if any findings suggest a need for immediate medical attention.")
    
    elif question_type == "dermatological":
        query_parts.append("Based on this information, what skin conditions should be considered? What treatments might be appropriate and what self-care measures could help? Please also note if any findings suggest a need for in-person dermatological evaluation.")
    
    elif question_type == "mental_health":
        query_parts.append("Based on this information, what mental health conditions should be considered? What support strategies, therapies, or treatments might be helpful? Please also indicate when professional mental health care would be recommended.")
    
    elif question_type == "musculoskeletal":
        query_parts.append("Based on this information, what joint or muscle conditions should be considered? What treatments, physical therapy approaches, or self-care measures might help? Please also indicate if any findings suggest a need for imaging or specialist evaluation.")
    
    else:
        query_parts.append("Based on this information, what conditions should be considered and what would be the recommended next steps? Please provide possible diagnoses, appropriate tests, and potential treatments or self-care measures.")
    
    # Add disclaimer
    query_parts.append("Note: Please also mention when the patient should seek professional medical care based on these symptoms.")
    
    return "\n".join(query_parts)

def render_structured_questionnaire():
    """Render the structured questionnaire based on the selected type."""
    question_type = st.session_state.current_question_type
    
    if question_type == "general":
        st.info("Select a specific condition from the dropdown to use structured questions.")
        return
    
    # Initialize answers dict for this question type if not exists
    if question_type not in st.session_state.structured_answers:
        st.session_state.structured_answers[question_type] = {}
    
    # Get the questions for this type
    questions_data = STRUCTURED_QUESTIONS[question_type]
    
    # Display the questionnaire
    st.markdown(f"<div class='sub-header'>{questions_data['title']}</div>", unsafe_allow_html=True)
    
    for question in questions_data["questions"]:
        q_id = question["id"]
        q_text = question["text"]
        q_suggestions = question["suggestions"]
        
        # Display the question
        st.write(q_text)
        
        # Get the current answer
        current_answer = st.session_state.structured_answers[question_type].get(q_id, "")
        
        # Display suggestion buttons
        cols = st.columns(len(q_suggestions))
        for i, suggestion in enumerate(q_suggestions):
            if cols[i].button(suggestion, key=f"{q_id}_{suggestion}_btn", help=f"Select '{suggestion}' for {q_text}"):
                st.session_state.structured_answers[question_type][q_id] = suggestion
    
    # Submit button with improved visibility
    st.write("")
    col1, col2 = st.columns([3, 1])
    with col1:
        st.markdown("### Submit Your Assessment")
        st.markdown("Click the button below to generate a detailed analysis based on your answers.")
    with col2:
        if st.button("Submit Analysis", key="generate_structured_query_btn", type="primary", use_container_width=True):
            query = generate_structured_query()
            if query:
                st.session_state.query = query
                st.rerun()

def reset_system():
    """Reset the system state."""
    # Keep only the page state
    keep_keys = ["page"]
    
    # Reset all session state variables
    for key in list(st.session_state.keys()):
        if key not in keep_keys:
            del st.session_state[key]
    
    # Reinitialize session state variables
    st.session_state.initialized = False
    st.session_state.system_initialized = False
    st.session_state.data_prepared = False
    st.session_state.query_history = []
    st.session_state.current_question_type = "general"
    st.session_state.structured_answers = {}
    st.session_state.patient_info = {
        "age": None,
        "gender": None,
        "main_symptom": None,
        "symptom_duration": None,
        "pain_level": None,
        "current_medications": None,
        "family_history": None,
        "previous_treatment": None
    }
    st.session_state.assessment_stage = "main_symptom"
    st.session_state.processing = False
    st.session_state.pipeline_loading = False
    st.session_state.suggestions_visible = False
    st.session_state.query_input = ""
    st.session_state.demo_mode = False
    
    # Display reset confirmation
    st.success("System has been reset. Initializing new session...")
    time.sleep(1)  # Brief pause
    st.rerun()

def show_suggestions_dropdown(query_input, query_type):
    """Show suggestion dropdown for the query input."""
    if not query_input or len(query_input) < 2:
        return []
    
    # Get suggestions for the current category
    all_suggestions = DEMO_QUERIES.get(query_type, DEMO_QUERIES["general"])
    
    # Filter suggestions based on input
    query_lower = query_input.lower()
    matching_suggestions = [s for s in all_suggestions if query_lower in s.lower()]
    
    # Return the top 5 matching suggestions
    return matching_suggestions[:5]

def render_sidebar():
    """Render the app sidebar with logo and system status."""
    
    # Add logo and title to sidebar with dark theme
    st.sidebar.markdown("""
    <div style="text-align: center; padding: 1rem; 
                background: linear-gradient(135deg, rgba(18,18,18,0.8) 0%, rgba(13,71,161,0.8) 100%); 
                border-radius: 10px; margin-bottom: 1rem; 
                border: 1px solid #4CAF50;
                box-shadow: 0 4px 6px rgba(0,0,0,0.2);">
        <div style="display: flex; justify-content: center; align-items: center; margin-bottom: 0.5rem;">
            <span style="font-size: 2.2rem; color: #4CAF50; margin-right: 0.5rem; text-shadow: 0 2px 4px rgba(0,0,0,0.3);">🧪</span>
            <h2 style="margin: 0; color: #4CAF50; font-weight: 600; text-shadow: 0 2px 4px rgba(0,0,0,0.3);">Medik</h2>
        </div>
        <p style="margin: 0; font-style: italic; color: #A5D6A7;">Your Personal AI Doctor</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Detailed System status indicators with expanded information
    st.sidebar.markdown("""
    <h3 style="color: #4CAF50; margin-bottom: 0.75rem; border-bottom: 1px solid #4CAF50; padding-bottom: 0.5rem;">
        System Status <span style="font-size: 1rem;">📊</span>
    </h3>
    """, unsafe_allow_html=True)
    
    # Display system initialization status
    init_status = "✅ Ready" if st.session_state.get("system_initialized", False) else "⏳ Initializing..."
    init_color = "#4CAF50" if st.session_state.get("system_initialized", False) else "#FFC107"
    
    # Display data preparation status
    data_status = "✅ Loaded" if st.session_state.get("data_prepared", False) else "⏳ Loading..."
    data_color = "#4CAF50" if st.session_state.get("data_prepared", False) else "#FFC107"
    
    # Show whether in demo mode
    mode_status = "⚠️ Demo Mode" if st.session_state.get("demo_mode", False) else "✅ Full Mode"
    mode_color = "#FFC107" if st.session_state.get("demo_mode", False) else "#4CAF50"
    
    # Display status with colored text and detailed information
    st.sidebar.markdown(f"""
    <div style="margin-bottom: 1rem; padding: 1rem; border-radius: 8px; 
               background-color: rgba(76, 175, 80, 0.05); 
               border: 1px solid rgba(76, 175, 80, 0.2);">
        <div style="display: flex; justify-content: space-between; margin-bottom: 0.75rem;">
            <span style="font-weight: bold; color: #FFFFFF;">System:</span>
            <span style="color: {init_color}; font-weight: 500;">{init_status}</span>
        </div>
        <div style="display: flex; justify-content: space-between; margin-bottom: 0.75rem;">
            <span style="font-weight: bold; color: #FFFFFF;">Medical Data:</span>
            <span style="color: {data_color}; font-weight: 500;">{data_status}</span>
        </div>
        <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
            <span style="font-weight: bold; color: #FFFFFF;">Operation Mode:</span>
            <span style="color: {mode_color}; font-weight: 500;">{mode_status}</span>
        </div>
        <div style="font-size: 0.8rem; color: #A5D6A7; margin-top: 0.5rem; padding-top: 0.5rem; border-top: 1px solid rgba(76, 175, 80, 0.2);">
            Last Updated: {time.strftime('%H:%M:%S')}
        </div>
    </div>
    """, unsafe_allow_html=True)
    
    # Show system configuration only if we're initialized
    if st.session_state.get("system_initialized", False):
        # Configuration options with enhanced styling
        st.sidebar.markdown("""
        <h3 style="color: #4CAF50; margin-bottom: 0.75rem; border-bottom: 1px solid #4CAF50; padding-bottom: 0.5rem;">
            Advanced Settings <span style="font-size: 1rem;">⚙️</span>
        </h3>
        """, unsafe_allow_html=True)
        
        # Data settings
        with st.sidebar.expander("Data Settings", expanded=False):
            # Number of documents to retrieve for each query
            st.markdown("<p style='color: #A5D6A7; font-size: 0.9rem;'>Control how many medical reference documents are retrieved per query</p>", unsafe_allow_html=True)
            k_docs = st.slider("Documents per query", min_value=1, max_value=10, value=3, step=1, help="Higher values may provide more comprehensive answers but take longer to process")
            st.session_state.k_docs = k_docs
            
            # Whether to use cached data
            st.markdown("<p style='color: #A5D6A7; font-size: 0.9rem; margin-top: 1rem;'>Optimize performance by using cached medical data</p>", unsafe_allow_html=True)
            use_cache = st.checkbox("Use cached data", value=True, help="Faster startup but may not include the most recent medical information")
            st.session_state.use_cache = use_cache
            
            # Add additional data settings
            st.markdown("<p style='color: #A5D6A7; font-size: 0.9rem; margin-top: 1rem;'>Set data processing depth</p>", unsafe_allow_html=True)
            proc_depth = st.select_slider("Processing Depth", options=["Basic", "Standard", "Detailed"], value="Standard", help="Higher depth provides more detailed analysis but takes longer")
            st.session_state.proc_depth = proc_depth
    
        # Retriever settings
        with st.sidebar.expander("Retriever Settings", expanded=False):
            # Select retriever type with more detail
            st.markdown("<p style='color: #A5D6A7; font-size: 0.9rem;'>Select the algorithm used to retrieve relevant medical information</p>", unsafe_allow_html=True)
            retriever_options = ["BM25", "Embedding", "Hybrid"]
            retriever_descriptions = {
                "BM25": "Fast keyword-based search",
                "Embedding": "Semantic understanding",
                "Hybrid": "Combines keyword and semantic"
            }
            
            # Display retriever options with descriptions
            retriever_type = st.selectbox(
                "Retriever type", 
                options=retriever_options, 
                index=0,
                format_func=lambda x: f"{x} - {retriever_descriptions[x]}",
                help="Different retrievers excel at different types of queries"
            )
            st.session_state.retriever_type = retriever_type.lower()
            
            # Add sensitivity setting
            st.markdown("<p style='color: #A5D6A7; font-size: 0.9rem; margin-top: 1rem;'>Adjust retrieval sensitivity</p>", unsafe_allow_html=True)
            sensitivity = st.slider("Sensitivity", min_value=0.0, max_value=1.0, value=0.7, step=0.1, help="Higher values return more relevant but potentially fewer documents")
            st.session_state.sensitivity = sensitivity
        
        # Model settings
        with st.sidebar.expander("Model Settings", expanded=False):
            st.markdown("<p style='color: #A5D6A7; font-size: 0.9rem;'>Configure the AI model behavior</p>", unsafe_allow_html=True)
            
            # Response length
            response_length = st.select_slider(
                "Response Detail", 
                options=["Concise", "Balanced", "Detailed"], 
                value="Balanced",
                help="Controls how comprehensive the AI responses will be"
            )
            st.session_state.response_length = response_length
            
            # Medical terminology level
            term_level = st.select_slider(
                "Medical Terminology", 
                options=["Simple", "Moderate", "Technical"], 
                value="Moderate",
                help="Controls the complexity of medical terms used in responses"
            )
            st.session_state.term_level = term_level
    
    # Medical disclaimer in sidebar with enhanced styling
    st.sidebar.markdown("""
    <div style="margin-top: 1.5rem; padding: 1rem; 
               background-color: rgba(33,150,243,0.1); 
               border-radius: 8px; 
               border-left: 3px solid #2196F3;
               box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
        <h4 style="margin-top: 0; color: #2196F3; font-weight: 600;">Medical Disclaimer</h4>
        <p style="font-size: 0.85rem; margin-bottom: 0.5rem; color: #FFFFFF;">This app provides information only and is not a substitute for professional medical advice.</p>
        <p style="font-size: 0.85rem; margin-bottom: 0; color: #90CAF9;">Always consult a qualified healthcare provider for medical concerns.</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Add reset button at the bottom with enhanced styling
    st.sidebar.markdown("<div style='margin-top: 2rem;'></div>", unsafe_allow_html=True)
    col1, col2 = st.sidebar.columns(2)
    with col1:
        if st.button("Reset System", type="primary", use_container_width=True):
            reset_system()
    with col2:
        if st.button("Help", use_container_width=True, help="Show help information"):
            st.session_state.show_help = True

def render_main():
    """Render the main content of the app."""
    
    # Custom header with black-blue background and green accent
    st.markdown("""
    <div style="background: linear-gradient(135deg, #121212 0%, #0D47A1 100%); 
                color: white; 
                padding: 1.8rem; 
                border-radius: 0 0 10px 10px;
                margin-bottom: 1.5rem;
                box-shadow: 0 4px 8px rgba(0,0,0,0.4);
                text-align: center;
                border-top: 3px solid #4CAF50;">
        <div style="display: flex; justify-content: center; align-items: center; margin-bottom: 0.8rem;">
            <span style="font-size: 3rem; margin-right: 0.8rem; color: #4CAF50;">🧪</span>
            <h1 style="font-size: 3rem; margin: 0; font-weight: 600; color: #4CAF50; text-shadow: 0 2px 4px rgba(0,0,0,0.5);">Medik</h1>
        </div>
        <p style="font-size: 1.3rem; font-style: italic; margin: 0.5rem 0; color: #A5D6A7;">Your Personal AI Doctor</p>
        <div style="display: flex; justify-content: center; gap: 2rem; margin-top: 1rem;">
            <div style="background-color: rgba(76, 175, 80, 0.15); padding: 0.5rem 1rem; border-radius: 20px; border: 1px solid #4CAF50;">
                <span style="font-weight: bold; color: #4CAF50;">System: </span>
                <span id="system-status">Active</span>
            </div>
            <div style="background-color: rgba(33, 150, 243, 0.15); padding: 0.5rem 1rem; border-radius: 20px; border: 1px solid #2196F3;">
                <span style="font-weight: bold; color: #2196F3;">Model: </span>
                <span id="model-status">AI Diagnosis</span>
            </div>
            <div style="background-color: rgba(156, 39, 176, 0.15); padding: 0.5rem 1rem; border-radius: 20px; border: 1px solid #9C27B0;">
                <span style="font-weight: bold; color: #9C27B0;">Database: </span>
                <span id="db-status">Medical Knowledge</span>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)
    
    # Check if system is initialized
    if not st.session_state.get("system_initialized", False):
        st.info("⚙️ System initializing... Please wait.")
        
        # Initialize the system
        with st.spinner("Loading medical knowledge..."):
            try:
                initialize_pipeline()
                st.session_state.system_initialized = True
                st.success("✅ System initialized successfully!")
                st.rerun()
            except Exception as e:
                st.error(f"❌ Error initializing system: {str(e)}")
                st.warning("The system will run in demo mode with limited functionality.")
                st.session_state.system_initialized = True
                st.session_state.demo_mode = True
    
    # Check if data is prepared
    if st.session_state.get("system_initialized", False) and not st.session_state.get("data_prepared", False):
        st.info("📚 Preparing medical data... This may take a moment.")
        
        # Prepare data
        with st.spinner("Processing medical knowledge base..."):
            try:
                prepare_data()
                st.session_state.data_prepared = True
                st.success("✅ Medical data prepared successfully!")
                time.sleep(1)  # Brief pause to show the success message
                st.rerun()
            except Exception as e:
                st.error(f"❌ Error preparing data: {str(e)}")
                st.warning("The system will run with demo data only.")
                st.session_state.data_prepared = True
                st.session_state.demo_mode = True
    
    # Only proceed if system is initialized and data is prepared
    if st.session_state.get("system_initialized", False) and st.session_state.get("data_prepared", False):
        # Directly render the medical assessment
        render_symptom_assessment()
    else:
        # Welcome message if system is not initialized yet
        st.markdown("""
        <div class="info-box">
            <h2>Welcome to Medik!</h2>
            <p>Your AI-powered medical assistant that offers expert medical insights through structured symptom analysis.</p>
            <p>The system is initializing and loading medical knowledge. This should only take a moment.</p>
        </div>
        """, unsafe_allow_html=True)
        
        # Medical disclaimer
        st.markdown("""
        <div class="warning-box">
            <h3>Medical Disclaimer</h3>
            <p>This application provides information for educational purposes only and is not a substitute for professional medical advice, diagnosis, or treatment.</p>
            <p>Always seek the advice of your physician or other qualified health provider with any questions you may have regarding a medical condition.</p>
        </div>
        """, unsafe_allow_html=True)

def render_symptom_assessment():
    st.markdown("<h2>Medical Symptom Assessment</h2>", unsafe_allow_html=True)
    st.markdown("Please provide detailed information about your symptoms to get a comprehensive assessment.")
    
    # Define health categories
    health_categories = [
        "Respiratory", "Cardiovascular", "Digestive", 
        "Neurological", "Musculoskeletal", "Dermatological",
        "Mental Health", "Endocrine"
    ]
    
    col1, col2, col3, col4 = st.columns(4)
    category_selection = {}
    
    # Display checkboxes in columns
    with col1:
        category_selection["Respiratory"] = st.checkbox("Respiratory", key="resp_check")
        category_selection["Neurological"] = st.checkbox("Neurological", key="neuro_check")
    
    with col2:
        category_selection["Cardiovascular"] = st.checkbox("Cardiovascular", key="cardio_check")
        category_selection["Musculoskeletal"] = st.checkbox("Musculoskeletal", key="musculo_check")
    
    with col3:
        category_selection["Digestive"] = st.checkbox("Digestive", key="digest_check")
        category_selection["Dermatological"] = st.checkbox("Dermatological", key="derm_check")
    
    with col4:
        category_selection["Mental Health"] = st.checkbox("Mental Health", key="mental_check")
        category_selection["Endocrine"] = st.checkbox("Endocrine", key="endo_check")
    
    # Basic patient info
    st.subheader("Patient Information")
    c1, c2 = st.columns(2)
    
    with c1:
        age = st.number_input("Age", min_value=0, max_value=120, value=35)
    with c2:
        gender = st.selectbox("Gender", ["Male", "Female", "Other"])
    
    # Questionnaire section
    structured_answers = {}
    selected_categories = [cat for cat, selected in category_selection.items() if selected]
    
    # Define submit_button outside conditionals to avoid UnboundLocalError
    submit_button = False
    
    if selected_categories:
        st.subheader("Symptom Questionnaire")
        st.markdown("Please answer the following questions based on your selected health categories:")
        
        for category in selected_categories:
            st.markdown(f"### {category} Assessment")
            
            if category == "Respiratory":
                structured_answers["main_symptom"] = st.text_area("What is your main respiratory symptom?", placeholder="e.g., shortness of breath, cough, chest pain, wheezing", key=f"{category}_main")
                structured_answers["symptom_duration"] = st.slider("How long have you had these symptoms? (days)", 1, 180, 7, key=f"{category}_duration")
                structured_answers["cough_present"] = st.selectbox("Do you have a cough?", ["No", "Yes - Dry", "Yes - Productive (with phlegm)"], key=f"{category}_cough")
                structured_answers["shortness_of_breath"] = st.selectbox("Do you experience shortness of breath?", ["No", "Only with exertion", "At rest", "Both at rest and with exertion"], key=f"{category}_sob")
                structured_answers["wheezing"] = st.checkbox("Do you experience wheezing?", key=f"{category}_wheeze")
                structured_answers["chest_pain"] = st.checkbox("Do you have chest pain when breathing?", key=f"{category}_pain")
                structured_answers["resp_additional"] = st.text_area("Any additional respiratory symptoms or information?", placeholder="e.g., fever, night sweats, recent travel", key=f"{category}_add")
            
            elif category == "Cardiovascular":
                structured_answers["chest_pain_type"] = st.selectbox("Do you experience chest pain/discomfort?", ["No", "Yes - Sharp", "Yes - Pressure/Squeezing", "Yes - Burning", "Yes - Other"], key=f"{category}_pain")
                structured_answers["pain_radiation"] = st.multiselect("Does the pain radiate to other areas?", ["No", "Left arm", "Jaw", "Back", "Shoulder"], key=f"{category}_rad")
                structured_answers["heart_palpitations"] = st.checkbox("Do you experience heart palpitations (racing, pounding, or skipping beats)?", key=f"{category}_palp")
                structured_answers["cardiovascular_additional"] = st.text_area("Any additional cardiovascular symptoms?", placeholder="e.g., swelling in legs, shortness of breath, dizziness", key=f"{category}_add")
            
            elif category == "Digestive":
                structured_answers["abdominal_pain"] = st.selectbox("Do you have abdominal pain?", ["No", "Mild", "Moderate", "Severe"], key=f"{category}_pain")
                structured_answers["pain_location"] = st.multiselect("Where is the pain located?", ["Upper right", "Upper left", "Lower right", "Lower left", "Middle", "Diffuse"], key=f"{category}_loc")
                structured_answers["nausea_vomiting"] = st.checkbox("Do you experience nausea or vomiting?", key=f"{category}_nv")
                structured_answers["bowel_changes"] = st.multiselect("Any changes in bowel habits?", ["None", "Diarrhea", "Constipation", "Alternating", "Blood in stool"], key=f"{category}_bowel")
                structured_answers["digestive_additional"] = st.text_area("Any additional digestive symptoms?", placeholder="e.g., bloating, heartburn, weight loss", key=f"{category}_add")
            
            elif category == "Neurological":
                structured_answers["headache"] = st.selectbox("Do you experience headaches?", ["No", "Mild", "Moderate", "Severe"], key=f"{category}_head")
                structured_answers["headache_location"] = st.multiselect("Where is the headache located?", ["Forehead", "Back of head", "One side", "Both sides", "Behind eyes"], key=f"{category}_loc")
                structured_answers["dizziness"] = st.checkbox("Do you experience dizziness or vertigo?", key=f"{category}_dizzy")
                structured_answers["vision_changes"] = st.checkbox("Any vision changes or disturbances?", key=f"{category}_vision")
                structured_answers["neurological_additional"] = st.text_area("Any additional neurological symptoms?", placeholder="e.g., numbness, tingling, weakness, memory issues", key=f"{category}_add")
            
            # Add similar sections for other categories
            elif category == "Musculoskeletal":
                structured_answers["joint_pain"] = st.multiselect("Which joints are painful?", ["None", "Knees", "Hips", "Shoulders", "Wrists", "Ankles", "Fingers", "Other"], key=f"{category}_pain")
                structured_answers["pain_quality"] = st.selectbox("How would you describe the pain?", ["Aching", "Sharp", "Burning", "Throbbing", "Stiffness"], key=f"{category}_quality")
                structured_answers["pain_timing"] = st.selectbox("When is the pain worst?", ["Morning", "Evening", "After activity", "Constant", "Random"], key=f"{category}_timing")
                structured_answers["musculoskeletal_additional"] = st.text_area("Any additional musculoskeletal symptoms?", placeholder="e.g., swelling, redness, limited range of motion", key=f"{category}_add")
            
            elif category == "Dermatological":
                structured_answers["skin_issue"] = st.selectbox("What type of skin issue are you experiencing?", ["Rash", "Itching", "Dryness", "Lesion/Growth", "Color change", "Other"], key=f"{category}_issue")
                structured_answers["skin_location"] = st.text_area("Where on your body is the issue located?", key=f"{category}_loc")
                structured_answers["skin_duration"] = st.slider("How long have you had this issue? (days)", 1, 365, 7, key=f"{category}_duration")
                structured_answers["skin_additional"] = st.text_area("Any additional skin symptoms?", placeholder="e.g., pain, discharge, changes in appearance", key=f"{category}_add")
            
            elif category == "Mental Health":
                structured_answers["mood_changes"] = st.multiselect("Are you experiencing any mood changes?", ["No", "Depression", "Anxiety", "Irritability", "Mood swings"], key=f"{category}_mood")
                structured_answers["sleep_issues"] = st.checkbox("Are you having trouble sleeping?", key=f"{category}_sleep")
                structured_answers["stress_level"] = st.slider("On a scale of 1-10, what is your current stress level?", 1, 10, 5, key=f"{category}_stress")
                structured_answers["mental_additional"] = st.text_area("Any additional mental health concerns?", placeholder="e.g., concentration issues, changes in appetite, social withdrawal", key=f"{category}_add")
            
            elif category == "Endocrine":
                structured_answers["thirst_changes"] = st.checkbox("Are you experiencing increased thirst?", key=f"{category}_thirst")
                structured_answers["weight_changes"] = st.selectbox("Have you noticed changes in your weight?", ["No", "Weight loss", "Weight gain"], key=f"{category}_weight")
                structured_answers["fatigue"] = st.checkbox("Are you experiencing unusual fatigue?", key=f"{category}_fatigue")
                structured_answers["temperature_sensitivity"] = st.selectbox("Do you have sensitivity to temperature?", ["No", "Heat intolerance", "Cold intolerance"], key=f"{category}_temp")
                structured_answers["endocrine_additional"] = st.text_area("Any additional endocrine symptoms?", placeholder="e.g., hair loss, irregular periods, excessive sweating", key=f"{category}_add")
        
        # Add a single submit button with clear processing indicator
        submit_col1, submit_col2 = st.columns([1, 3])
        with submit_col1:
            submit_button = st.button("Process Assessment", type="primary", key="submit_assessment", use_container_width=True)
        
        # Processing indicator placeholder
        processing_placeholder = st.empty()
        
        if submit_button:
            # Show immediate processing feedback
            processing_placeholder.warning("🔄 Processing your medical assessment... Please wait...")
            
            # Prepare a structured query based on the filled questionnaire
            patient_info = f"User Profile: Age {age}, Gender {gender}"
            
            query_parts = [
                patient_info,
                "Medical Assessment:"
            ]
            
            # Add structured answers to the query
            for category in selected_categories:
                query_parts.append(f"\n{category} Assessment:")
                category_answers = {k: v for k, v in structured_answers.items() if k.startswith(category.lower()) or k in ["main_symptom", "symptom_duration"]}
                for key, value in category_answers.items():
                    if value and value not in ["No", "None", []]:
                        # Clean up the key name for better readability
                        display_key = key.replace("_", " ").title()
                        query_parts.append(f"- {display_key}: {value}")
            
            query = "\n".join(query_parts)
            
            # Set the query in the session state and mark as processing
            st.session_state.query = query
            st.session_state.processing = True
            
            # Process the query
            try:
                result = process_query(query)
                if result:
                    st.session_state.last_result = result
                    
                    # Clear the processing indicator
                    processing_placeholder.empty()
                    
                    # Show the formatted assessment
                    st.markdown("### Your Assessment Results")
                    st.markdown("<div class='doctor-advice'>", unsafe_allow_html=True)
                    st.markdown("### Medik's Analysis")
                    if "answer" in result and result["answer"]:
                        st.markdown(result["answer"])
                    else:
                        st.markdown("I'm sorry, I couldn't generate a specific response. Please try providing more details.")
                    st.markdown("</div>", unsafe_allow_html=True)
                    
                    # Auto-scroll to the results using JavaScript
                    st.markdown("""
                    <script>
                        document.querySelector('.doctor-advice').scrollIntoView({
                            behavior: 'smooth',
                            block: 'start'
                        });
                    </script>
                    """, unsafe_allow_html=True)
                    
                    # Display retrieved documents if available
                    if "retrieved_documents" in result and result["retrieved_documents"]:
                        with st.expander("Reference Medical Information", expanded=False):
                            for i, doc in enumerate(result["retrieved_documents"]):
                                st.markdown(f"**{i+1}. {doc.get('title', 'Document ' + str(i+1))}** - {doc.get('source', 'Unknown Source')}")
                                content = doc.get('content', 'No content available')
                                st.markdown(f"{content[:500]}...")
                                st.markdown("---")
                else:
                    # Clear the processing indicator and show error
                    processing_placeholder.error("❌ Failed to process your assessment. Please try again.")
                
                # Reset processing state
                st.session_state.processing = False
                
            except Exception as e:
                # Clear the processing indicator and show error
                processing_placeholder.error(f"❌ Error: {str(e)}")
                st.session_state.processing = False
    
    else:
        st.info("Please select at least one health category to begin your assessment.")
    
    # Show previously processed result if available
    if not submit_button and "last_result" in st.session_state and st.session_state.last_result:
        result = st.session_state.last_result
        
        st.markdown("### Your Previous Assessment Results")
        st.markdown("<div class='doctor-advice'>", unsafe_allow_html=True)
        st.markdown("### Medik's Analysis")
        if "answer" in result and result["answer"]:
            st.markdown(result["answer"])
        st.markdown("</div>", unsafe_allow_html=True)
        
        # Display retrieved documents if available
        if "retrieved_documents" in result and result["retrieved_documents"]:
            with st.expander("Reference Medical Information", expanded=False):
                for i, doc in enumerate(result["retrieved_documents"]):
                    st.markdown(f"**{i+1}. {doc.get('title', 'Document ' + str(i+1))}** - {doc.get('source', 'Unknown Source')}")
                    content = doc.get('content', 'No content available')
                    st.markdown(f"{content[:500]}...")
                    st.markdown("---")

def main():
    """Main function for the Streamlit app."""
    # Check if running on Hugging Face Spaces or local
    running_on_hf = os.environ.get("SPACE_ID") is not None
    
    # Set default auto-initialization
    default_auto_init = "true" if running_on_hf else "true"  # Changed to always true
    default_auto_prepare = "true" if running_on_hf else "true"  # Changed to always true
    
    # Auto-initialize if needed
    if not st.session_state.system_initialized:
        auto_init = os.environ.get("AUTO_INITIALIZE", default_auto_init).lower() == "true"
        if auto_init:
            with st.spinner("Initializing Medik... This may take a few minutes on first run..."):
                try:
                    # Set a longer timeout for model loading
                    success = initialize_pipeline()
                    if success:
                        st.session_state.system_initialized = True
                        st.success("System initialized successfully!")
                    else:
                        st.error("Failed to initialize system. Please check logs for details.")
                except Exception as e:
                    st.error(f"Error during initialization: {str(e)}")
                    logger.error(f"Initialization error: {str(e)}")
    
    # Auto-prepare data if needed
    if st.session_state.system_initialized and not st.session_state.data_prepared:
        auto_prepare = os.environ.get("AUTO_PREPARE_DATA", default_auto_prepare).lower() == "true"
        if auto_prepare:
            with st.spinner("Preparing medical data... This may take a few minutes on first run but will be faster next time..."):
                try:
                    success = prepare_data()
                    if success:
                        st.session_state.data_prepared = True
                        st.success("Medical data prepared successfully!")
                    else:
                        st.error("Failed to prepare data. Check logs for details.")
                except Exception as e:
                    st.error(f"Error during data preparation: {str(e)}")
                    logger.error(f"Data preparation error: {str(e)}")
    
    # Render the sidebar and main content
    render_sidebar()
    render_main()

if __name__ == "__main__":
    main() 