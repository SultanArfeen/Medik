# Deploying Medik AI Doctor

This guide explains how to deploy the Medik application to GitHub and Hugging Face Spaces.

## Prerequisites

- Python 3.9+
- Git
- A GitHub account
- A Hugging Face account
- Hugging Face CLI (`pip install huggingface_hub`)

## Deployment Options

Medik can be deployed in multiple ways:

1. **GitHub Repository**: Host the code for collaboration and version control
2. **Hugging Face Spaces**: Deploy the interactive application for public use
3. **Local Deployment**: Run the application on your own machine

## GitHub Deployment

### Manual Deployment

1. Create a new repository on GitHub
2. Initialize Git in your local project (if not already done):
   ```bash
   git init
   ```
3. Add your files:
   ```bash
   git add .
   ```
4. Commit the changes:
   ```bash
   git commit -m "Initial commit"
   ```
5. Add the remote repository:
   ```bash
   git remote add origin https://github.com/yourusername/medik.git
   ```
6. Push to GitHub:
   ```bash
   git push -u origin main
   ```

### Using the Deployment Script

We provide a helper script to simplify deployment:

```bash
python deploy.py --github --github-repo https://github.com/yourusername/medik.git --push --message "Your commit message"
```

## Hugging Face Spaces Deployment

### Manual Deployment

1. Create a new Space on Hugging Face:
   - Go to [Hugging Face Spaces](https://huggingface.co/spaces)
   - Click "Create new Space"
   - Choose "Docker" as the Space SDK
   - Enter a name and set visibility settings

2. Upload the necessary files:
   - Clone the Space repository:
     ```bash
     git clone https://huggingface.co/spaces/yourusername/medik
     ```
   - Copy the necessary files to the cloned repository
   - Commit and push to Hugging Face

### Using the Deployment Script

```bash
python deploy.py --huggingface --hf-space yourusername/medik --hf-token your_token_here
```

## Deployment Configuration

### Hugging Face Spaces Configuration

The application is configured for Hugging Face Spaces through:

1. **Dockerfile**: Defines the container environment
2. **requirements.txt**: Lists the Python dependencies
3. **app.py**: The entry point for the Streamlit application

### Environment Variables

The application can be configured using environment variables:

- `AUTO_INITIALIZE`: Set to `true` to automatically initialize the application
- `AUTO_PREPARE_DATA`: Set to `true` to automatically prepare data on startup
- `DEBUG`: Set to `true` for debug logging

## Troubleshooting

### Common Issues

1. **GitHub Push Errors**:
   - Ensure you have the correct permissions to the repository
   - Verify that you're using the correct repository URL

2. **Hugging Face Deployment Errors**:
   - Check that your Hugging Face token has the correct permissions
   - Verify that the space name follows the format `username/space-name`

3. **Application Not Starting**:
   - Check the Hugging Face Space logs for error messages
   - Verify that all required dependencies are in the requirements.txt file

### Getting Help

If you encounter issues:

1. Check the GitHub Issues page for similar problems
2. Consult the Hugging Face Spaces documentation
3. Contact the maintainers through GitHub issues

## Updating Your Deployment

To update an existing deployment:

1. Make your changes to the codebase
2. For GitHub: Commit and push the changes
3. For Hugging Face: Use the deployment script with the `--huggingface` flag

## Continuous Integration

The repository includes GitHub Actions workflows for continuous integration:

- Code linting and security scanning
- (Future) Automated tests
- (Future) Automatic deployment to Hugging Face on successful builds

## License

Remember that all deployments should maintain the original license and attribution information. 