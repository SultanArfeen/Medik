"""
Deployment script for GitHub.

This script prepares and pushes the model to GitHub.
"""

import os
import sys
import logging
import shutil
import subprocess
from pathlib import Path

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("deploy")

# GitHub username and repository name
USERNAME = "SultanArfeen"
REPO_NAME = "direct-rag"
FULL_REPO_NAME = f"{USERNAME}/{REPO_NAME}"

# Files/directories to exclude from deployment
EXCLUDE_FILES = [
    "medium_article.md",
    "linkedin_post.md",
    "deploy_huggingface.py",
    "deploy_github.py",
    "huggingface_readme.md",
    "huggingface_repo",
    "github_repo",
    "huggingface-space",
    "__pycache__",
    ".spaces"
]

def setup_repo_directory():
    """Set up the directory for the GitHub repository."""
    # Create a temp directory for the repo
    repo_dir = Path("github_repo")
    
    if repo_dir.exists():
        logger.info(f"Cleaning existing repository directory: {repo_dir}")
        shutil.rmtree(repo_dir)
    
    logger.info(f"Creating repository directory: {repo_dir}")
    repo_dir.mkdir(parents=True)
    
    # Copy all files except exclusions
    logger.info("Copying files to repository directory")
    
    # Get the current directory
    current_dir = Path(".")
    
    # Copy all files and directories except those in EXCLUDE_FILES
    for item in current_dir.iterdir():
        # Skip excluded files and directories
        if item.name in EXCLUDE_FILES or item.name == repo_dir.name:
            logger.info(f"Skipping excluded item: {item.name}")
            continue
            
        # Copy the item
        if item.is_dir():
            if item.name == "__pycache__":
                continue
            
            # Special handling for certain directories
            if item.name == "frontend":
                # Make sure the .streamlit directory is included
                target_dir = repo_dir / item.name
                shutil.copytree(item, target_dir, ignore=shutil.ignore_patterns("__pycache__"))
                
                # Create .streamlit directory if it doesn't exist
                streamlit_config_dir = target_dir / ".streamlit"
                os.makedirs(streamlit_config_dir, exist_ok=True)
                
                # Copy the config.toml file if it exists
                if (item / ".streamlit" / "config.toml").exists():
                    shutil.copy(item / ".streamlit" / "config.toml", streamlit_config_dir / "config.toml")
            else:
                shutil.copytree(item, repo_dir / item.name, ignore=shutil.ignore_patterns("__pycache__"))
        else:
            shutil.copy(item, repo_dir / item.name)
    
    # Copy data directory structure without actual data files
    data_dir = Path("data")
    if data_dir.exists():
        target_data_dir = repo_dir / "data"
        os.makedirs(target_data_dir, exist_ok=True)
        
        # Only copy directory structure and sample files
        for subdir in ["kg", "samples"]:
            if (data_dir / subdir).exists():
                os.makedirs(target_data_dir / subdir, exist_ok=True)
                
                # Copy a single example file from each directory if available
                example_files = list((data_dir / subdir).glob("*.json"))
                if example_files:
                    shutil.copy(example_files[0], target_data_dir / subdir / example_files[0].name)
    
    # Make sure README.md exists
    if not (repo_dir / "README.md").exists() and Path("README.md").exists():
        shutil.copy("README.md", repo_dir / "README.md")
    
    # Make sure .env file is in the repo with appropriate content
    with open(repo_dir / ".env", "w") as f:
        f.write("""# Auto-initialization settings
AUTO_INITIALIZE=true
AUTO_PREPARE_DATA=true

# Default paths
DATA_DIR=data
INDEX_DIR=indexes
RESULTS_DIR=results

# Default retriever settings
RETRIEVER_TYPE=bm25
EMBEDDING_MODEL=sentence-transformers/all-mpnet-base-v2

# Default generator settings
GENERATOR_TYPE=direct
GENERATOR_MODEL=mistralai/Mistral-7B-Instruct-v0.2

# Logging level
LOG_LEVEL=INFO
""")
    
    return repo_dir

def initialize_git_repo(repo_dir):
    """Initialize a git repository in the specified directory."""
    logger.info(f"Initializing git repository in {repo_dir}")
    
    try:
        # Change to repo directory
        os.chdir(repo_dir)
        
        # Initialize git
        subprocess.run(["git", "init"], check=True)
        
        # Add all files
        subprocess.run(["git", "add", "."], check=True)
        
        # Initial commit
        subprocess.run(["git", "commit", "-m", "Initial commit: DiReCT RAG System"], check=True)
        
        # Return to original directory
        os.chdir("..")
        
        return True
    except subprocess.CalledProcessError as e:
        logger.error(f"Git command failed: {e}")
        return False
    except Exception as e:
        logger.error(f"Error initializing git repository: {e}")
        return False

def setup_github_remote(repo_dir):
    """Set up the GitHub remote repository."""
    logger.info(f"Setting up GitHub remote for {FULL_REPO_NAME}")
    
    try:
        os.chdir(repo_dir)
        
        # Check if GitHub CLI is installed
        gh_installed = True
        try:
            subprocess.run(["gh", "--version"], check=True, capture_output=True)
        except (subprocess.CalledProcessError, FileNotFoundError):
            gh_installed = False
            
        if gh_installed:
            # Use GitHub CLI to create the repository (if it doesn't exist)
            try:
                subprocess.run(["gh", "repo", "view", f"{USERNAME}/{REPO_NAME}"], 
                              check=True, capture_output=True)
                logger.info(f"Repository {FULL_REPO_NAME} already exists")
            except subprocess.CalledProcessError:
                logger.info(f"Creating repository {FULL_REPO_NAME}")
                subprocess.run([
                    "gh", "repo", "create", REPO_NAME,
                    "--public",
                    "--description", "A Retrieval-Augmented Generation (RAG) system for medical diagnostic reasoning",
                    "--source", "."
                ], check=True)
        else:
            # Manual instructions for creating the repository
            logger.info("GitHub CLI not found. Please create the repository manually:")
            logger.info(f"1. Go to https://github.com/new")
            logger.info(f"2. Create a repository named '{REPO_NAME}'")
            logger.info(f"3. Make it public")
            logger.info(f"4. Do not initialize with README, .gitignore, or license")
            
            input("Press Enter after you've created the repository...")
        
        # Add GitHub remote
        subprocess.run(["git", "remote", "add", "origin", f"https://github.com/{FULL_REPO_NAME}.git"], check=True)
        
        os.chdir("..")
        
        return True
    except subprocess.CalledProcessError as e:
        logger.error(f"Git command failed: {e}")
        return False
    except Exception as e:
        logger.error(f"Error setting up GitHub remote: {e}")
        return False

def push_to_github(repo_dir):
    """Push the repository to GitHub."""
    logger.info(f"Pushing to GitHub repository: {FULL_REPO_NAME}")
    
    try:
        os.chdir(repo_dir)
        
        # Push to GitHub
        subprocess.run(["git", "push", "-u", "origin", "main"], check=True)
        
        os.chdir("..")
        
        logger.info(f"Successfully pushed to {FULL_REPO_NAME}")
        return True
    except subprocess.CalledProcessError as e:
        logger.error(f"Git command failed: {e}")
        return False
    except Exception as e:
        logger.error(f"Error pushing to GitHub: {e}")
        return False

def main():
    """Main deployment function."""
    logger.info("Starting deployment to GitHub")
    
    # Step 1: Set up repository directory
    repo_dir = setup_repo_directory()
    
    # Step 2: Initialize git repository
    if not initialize_git_repo(repo_dir):
        logger.error("Failed to initialize git repository. Aborting deployment.")
        return False
    
    # Step 3: Set up GitHub remote
    if not setup_github_remote(repo_dir):
        logger.error("Failed to set up GitHub remote. Aborting deployment.")
        return False
    
    # Step 4: Push to GitHub
    if not push_to_github(repo_dir):
        logger.error("Failed to push to GitHub. Aborting deployment.")
        return False
    
    logger.info(f"Deployment successful! Your repository is now available at: https://github.com/{FULL_REPO_NAME}")
    logger.info(f"To use the system, clone the repository and install requirements:")
    logger.info(f"git clone https://github.com/{FULL_REPO_NAME}.git")
    logger.info(f"cd {REPO_NAME}")
    logger.info(f"pip install -r requirements.txt")
    logger.info(f"streamlit run frontend/app.py")
    
    return True

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1) 