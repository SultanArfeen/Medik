"""
Deployment script for Hugging Face Hub.

This script prepares and pushes the model to the Hugging Face Hub.
"""

import os
import sys
import logging
import shutil
import subprocess
from pathlib import Path

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("deploy")

# Hugging Face username
USERNAME = "ArfeenSKD"
REPO_NAME = "direct-rag"
FULL_REPO_NAME = f"{USERNAME}/{REPO_NAME}"

# Files/directories to exclude from deployment
EXCLUDE_FILES = [
    "medium_article.md",
    "linkedin_post.md",
    "deploy_huggingface.py",
    "deploy_github.py",
    "huggingface_readme.md",
    "huggingface_repo",
    "__pycache__",
    "github_repo"
]

def setup_repo_directory():
    """Set up the directory for the Hugging Face repository."""
    # Create a temp directory for the repo
    repo_dir = Path("huggingface_repo")
    
    if repo_dir.exists():
        logger.info(f"Cleaning existing repository directory: {repo_dir}")
        shutil.rmtree(repo_dir)
    
    logger.info(f"Creating repository directory: {repo_dir}")
    repo_dir.mkdir(parents=True)
    
    # Get the current directory
    current_dir = Path(".")
    
    # Copy all files and directories except those in EXCLUDE_FILES
    for item in current_dir.iterdir():
        # Skip excluded files and directories
        if item.name in EXCLUDE_FILES or item.name == repo_dir.name:
            logger.info(f"Skipping excluded item: {item.name}")
            continue
            
        # Copy the item
        if item.is_dir():
            if item.name == "__pycache__":
                continue
            
            # Special handling for certain directories
            if item.name == "frontend":
                # Make sure the .streamlit directory is included
                target_dir = repo_dir / item.name
                shutil.copytree(item, target_dir, ignore=shutil.ignore_patterns("__pycache__"))
                
                # Create .streamlit directory if it doesn't exist
                streamlit_config_dir = target_dir / ".streamlit"
                os.makedirs(streamlit_config_dir, exist_ok=True)
                
                # Copy the config.toml file if it exists
                if (item / ".streamlit" / "config.toml").exists():
                    shutil.copy(item / ".streamlit" / "config.toml", streamlit_config_dir / "config.toml")
            else:
                shutil.copytree(item, repo_dir / item.name, ignore=shutil.ignore_patterns("__pycache__"))
        else:
            shutil.copy(item, repo_dir / item.name)
    
    # Copy data directory structure without actual data files
    data_dir = Path("data")
    if data_dir.exists():
        target_data_dir = repo_dir / "data"
        os.makedirs(target_data_dir, exist_ok=True)
        
        # Only copy directory structure and sample files
        for subdir in ["kg", "samples"]:
            if (data_dir / subdir).exists():
                os.makedirs(target_data_dir / subdir, exist_ok=True)
                
                # Copy a single example file from each directory if available
                example_files = list((data_dir / subdir).glob("*.json"))
                if example_files:
                    shutil.copy(example_files[0], target_data_dir / subdir / example_files[0].name)
    
    # Create a model card if it doesn't exist
    create_model_card(repo_dir)
    
    # Copy Hugging Face Space files
    huggingface_space_dir = Path("huggingface-space")
    if huggingface_space_dir.exists():
        # Create spaces directory
        spaces_dir = repo_dir / ".spaces"
        os.makedirs(spaces_dir, exist_ok=True)
        
        # Create spaces configuration file
        with open(spaces_dir / "config.json", "w") as f:
            f.write('''{
  "title": "Medik - Your Personal AI Doctor",
  "emoji": "🩺",
  "colorFrom": "green",
  "colorTo": "blue",
  "sdk": "streamlit",
  "sdk_version": "1.22.0",
  "app_file": "app.py",
  "pinned": true,
  "license": "mit"
}''')
        
        # Copy space files
        for file in huggingface_space_dir.glob("*"):
            if file.is_file():
                shutil.copy(file, repo_dir / file.name)
    
    # Make sure .env file is in the repo
    if not (repo_dir / ".env").exists() and Path(".env").exists():
        shutil.copy(".env", repo_dir / ".env")
    
    return repo_dir

def create_model_card(repo_dir):
    """Create a model card if it doesn't exist."""
    if not (repo_dir / "README.md").exists():
        logger.info("Creating default model card")
        model_card_content = f"""# DiReCT RAG System

A Retrieval-Augmented Generation (RAG) system for medical diagnostic reasoning based on the MIMIC-IV-Ext-DiReCT dataset.

## Model Description

This system combines advanced retrieval methods with state-of-the-art language models to provide accurate and relevant medical information.

## Features

- Multiple retrieval methods (BM25, Embedding-based, and Hybrid)
- Flexible generation options
- Knowledge integration from clinical notes and diagnostic knowledge graphs
- Interactive user interface
- Structured medical questionnaires

## Usage

### Web Interface

The system includes a Streamlit web interface that can be run with:

```bash
streamlit run frontend/app.py
```

### Programmatic API

```python
from direct_rag import RAGPipeline

# Initialize the pipeline
pipeline = RAGPipeline(
    data_dir="data",
    retriever_type="bm25",
    generator_type="direct",
    generator_model_name="mistralai/Mistral-7B-Instruct-v0.2"
)

# Process a query
result = pipeline.process_query(
    query="What are the diagnostic criteria for heart failure?",
    top_k=5
)

print(result["response"])
```

## Demo

A live demo of this system is available at: https://huggingface.co/spaces/{USERNAME}/direct-rag-demo

## Installation

```bash
pip install git+https://huggingface.co/{FULL_REPO_NAME}
```

## Citation

```bibtex
@misc{{direct-rag-2024,
  author = {{Sultan Ul Arfeen}},
  title = {{DiReCT RAG: A Medical Diagnostic Reasoning System}},
  year = {{2024}},
  publisher = {{Hugging Face}},
  url = {{https://huggingface.co/{FULL_REPO_NAME}}}
}}
```
"""
        with open(repo_dir / "README.md", "w") as f:
            f.write(model_card_content)

def initialize_git_repo(repo_dir):
    """Initialize a git repository in the specified directory."""
    logger.info(f"Initializing git repository in {repo_dir}")
    
    try:
        # Change to repo directory
        os.chdir(repo_dir)
        
        # Initialize git
        subprocess.run(["git", "init"], check=True)
        
        # Add all files
        subprocess.run(["git", "add", "."], check=True)
        
        # Initial commit
        subprocess.run(["git", "commit", "-m", "Initial commit: DiReCT RAG System"], check=True)
        
        # Return to original directory
        os.chdir("..")
        
        return True
    except subprocess.CalledProcessError as e:
        logger.error(f"Git command failed: {e}")
        return False
    except Exception as e:
        logger.error(f"Error initializing git repository: {e}")
        return False

def login_to_huggingface():
    """Log in to Hugging Face Hub using the token."""
    logger.info("Logging in to Hugging Face Hub")
    
    try:
        # Check if huggingface_hub is installed
        import importlib
        if importlib.util.find_spec("huggingface_hub") is None:
            logger.info("Installing huggingface_hub")
            subprocess.run([sys.executable, "-m", "pip", "install", "huggingface_hub"], check=True)
        
        # Check if user is logged in
        from huggingface_hub import HfApi
        api = HfApi()
        
        try:
            # Check if already logged in
            current_user = api.whoami()
            logger.info(f"Already logged in as: {current_user['name']}")
            return True
        except Exception:
            logger.info("Not logged in. Please log in using huggingface-cli login")
            subprocess.run(["huggingface-cli", "login"], check=True)
            return True
    except Exception as e:
        logger.error(f"Error logging in to Hugging Face Hub: {e}")
        return False

def create_repo_on_hub():
    """Create a new repository on Hugging Face Hub."""
    logger.info(f"Creating repository {FULL_REPO_NAME} on Hugging Face Hub")
    
    try:
        from huggingface_hub import HfApi
        api = HfApi()
        
        # Check if repo exists
        try:
            api.repo_info(repo_id=FULL_REPO_NAME, repo_type="model")
            logger.info(f"Repository {FULL_REPO_NAME} already exists")
        except Exception:
            # Create repo
            api.create_repo(repo_id=REPO_NAME, repo_type="model")
            logger.info(f"Repository {FULL_REPO_NAME} created")
        
        return True
    except Exception as e:
        logger.error(f"Error creating repository on Hugging Face Hub: {e}")
        return False

def push_to_hub(repo_dir):
    """Push the repository to Hugging Face Hub."""
    logger.info(f"Pushing to Hugging Face Hub repository: {FULL_REPO_NAME}")
    
    try:
        os.chdir(repo_dir)
        
        # Add Hugging Face remote
        subprocess.run(["git", "remote", "add", "huggingface", f"https://huggingface.co/{FULL_REPO_NAME}"], check=True)
        
        # Push to Hugging Face
        subprocess.run(["git", "push", "-u", "huggingface", "main"], check=True)
        
        os.chdir("..")
        
        logger.info(f"Successfully pushed to {FULL_REPO_NAME}")
        return True
    except subprocess.CalledProcessError as e:
        logger.error(f"Git command failed: {e}")
        return False
    except Exception as e:
        logger.error(f"Error pushing to Hugging Face Hub: {e}")
        return False

def main():
    """Main deployment function."""
    logger.info("Starting deployment to Hugging Face Hub")
    
    # Step 1: Set up repository directory
    repo_dir = setup_repo_directory()
    
    # Step 2: Initialize git repository
    if not initialize_git_repo(repo_dir):
        logger.error("Failed to initialize git repository. Aborting deployment.")
        return False
    
    # Step 3: Log in to Hugging Face Hub
    if not login_to_huggingface():
        logger.error("Failed to log in to Hugging Face Hub. Aborting deployment.")
        return False
    
    # Step 4: Create repository on Hugging Face Hub
    if not create_repo_on_hub():
        logger.error("Failed to create repository on Hugging Face Hub. Aborting deployment.")
        return False
    
    # Step 5: Push to Hugging Face Hub
    if not push_to_hub(repo_dir):
        logger.error("Failed to push to Hugging Face Hub. Aborting deployment.")
        return False
    
    logger.info(f"Deployment successful! Your model is now available at: https://huggingface.co/{FULL_REPO_NAME}")
    logger.info(f"To use the model in your projects: pip install git+https://huggingface.co/{FULL_REPO_NAME}")
    logger.info("To create a Hugging Face Space with this model:")
    logger.info("1. Go to https://huggingface.co/spaces/new")
    logger.info("2. Select Streamlit as the SDK")
    logger.info("3. Link to this model repository")
    
    return True

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1) 