"""
Data Processing Module for MIMIC-IV-Ext-DiReCT Dataset

This module handles the preprocessing and loading of the DiReCT dataset
for use in the RAG system.
"""

import os
import json
import logging
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple
import pandas as pd

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("data_processor")

class DiReCTDataProcessor:
    """
    Processor for the MIMIC-IV-Ext-DiReCT dataset.
    Handles loading, preprocessing and organizing the dataset for the RAG system.
    """
    
    def __init__(self, data_dir: str = "data"):
        """
        Initialize the data processor.
        
        Args:
            data_dir: Path to the data directory
        """
        self.data_dir = Path(data_dir)
        self.kg_dir = self.data_dir / "kg"
        self.samples_dir = self.data_dir / "samples"
        
        # Initialize data structures
        self.knowledge_graphs = {}
        self.clinical_notes = []
        self.clinical_notes_df = None
        
        # Verify data directory exists
        if not self.data_dir.exists():
            logger.warning(f"Data directory not found: {self.data_dir}")
            os.makedirs(self.data_dir, exist_ok=True)
            
        # Create subdirectories if they don't exist
        os.makedirs(self.kg_dir, exist_ok=True)
        os.makedirs(self.samples_dir, exist_ok=True)
    
    def load_knowledge_graphs(self) -> Dict[str, Dict]:
        """
        Load all knowledge graph files.
        
        Returns:
            Dictionary mapping disease categories to their knowledge graphs
        """
        logger.info("Loading knowledge graphs")
        
        if not self.kg_dir.exists():
            logger.warning(f"Knowledge graph directory not found: {self.kg_dir}")
            return {}
        
        for kg_file in self.kg_dir.glob("*.json"):
            try:
                with open(kg_file, "r") as f:
                    kg_data = json.load(f)
                    # Use the disease name from the file or default to filename
                    disease_name = kg_data.get("disease", kg_file.stem)
                    self.knowledge_graphs[kg_file.stem] = kg_data
                logger.debug(f"Loaded knowledge graph: {kg_file.name}")
            except Exception as e:
                logger.error(f"Error loading knowledge graph {kg_file.name}: {str(e)}")
        
        logger.info(f"Loaded {len(self.knowledge_graphs)} knowledge graphs")
        return self.knowledge_graphs
    
    def load_clinical_notes(self) -> List[Dict]:
        """
        Load all clinical note samples.
        
        Returns:
            List of clinical note dictionaries
        """
        logger.info("Loading clinical notes")
        
        if not self.samples_dir.exists():
            logger.warning(f"Samples directory not found: {self.samples_dir}")
            return []
        
        self.clinical_notes = []
        
        # Load directly from samples directory
        for sample_file in self.samples_dir.glob("*.json"):
            try:
                with open(sample_file, "r") as f:
                    note_data = json.load(f)
                
                # Extract the clinical note information based on our sample structure
                clinical_note = {
                    "id": note_data.get("patient_id", sample_file.stem),
                    "disease_category": self._determine_disease_category(note_data),
                    "filepath": str(sample_file),
                    "chief_complaint": note_data.get("chief_complaint", ""),
                    "history_present_illness": note_data.get("history_of_present_illness", ""),
                    "past_medical_history": self._format_list_field(note_data.get("past_medical_history", [])),
                    "physical_exam": self._format_dict_field(note_data.get("physical_exam", {})),
                    "diagnosis": note_data.get("diagnosis", ""),
                    "raw_data": note_data
                }
                
                self.clinical_notes.append(clinical_note)
                logger.debug(f"Loaded clinical note: {sample_file.name}")
                
            except Exception as e:
                logger.error(f"Error loading clinical note {sample_file.name}: {str(e)}")
        
        logger.info(f"Loaded {len(self.clinical_notes)} clinical notes")
        return self.clinical_notes
    
    def _determine_disease_category(self, note_data: Dict) -> str:
        """
        Determine the disease category from the note data.
        
        Args:
            note_data: The clinical note data dictionary
            
        Returns:
            The disease category
        """
        # Try to extract from diagnosis
        diagnosis = note_data.get("diagnosis", "")
        if "heart failure" in diagnosis.lower():
            return "heart_failure"
        
        # Default to unknown if we can't determine
        return "unknown"
    
    def _format_list_field(self, field_data) -> str:
        """
        Format a list field as a string.
        
        Args:
            field_data: List of items
            
        Returns:
            Formatted string
        """
        if isinstance(field_data, list):
            return "\n".join([f"- {item}" for item in field_data])
        return str(field_data)
    
    def _format_dict_field(self, field_data) -> str:
        """
        Format a dictionary field as a string.
        
        Args:
            field_data: Dictionary of items
            
        Returns:
            Formatted string
        """
        if isinstance(field_data, dict):
            return "\n".join([f"{key}: {value}" for key, value in field_data.items()])
        return str(field_data)
    
    def create_dataframe(self) -> pd.DataFrame:
        """
        Convert the clinical notes to a pandas DataFrame.
        
        Returns:
            DataFrame with clinical note data
        """
        if not self.clinical_notes:
            self.load_clinical_notes()
            
        self.clinical_notes_df = pd.DataFrame(self.clinical_notes)
        return self.clinical_notes_df
    
    def get_combined_text(self, note: Dict) -> str:
        """
        Combine all text fields from a clinical note into a single string.
        
        Args:
            note: Clinical note dictionary
            
        Returns:
            Combined text from all fields
        """
        text_fields = [
            f"Chief Complaint: {note.get('chief_complaint', '')}",
            f"History of Present Illness: {note.get('history_present_illness', '')}",
            f"Past Medical History: {note.get('past_medical_history', '')}",
            f"Physical Exam: {note.get('physical_exam', '')}",
            f"Diagnosis: {note.get('diagnosis', '')}"
        ]
        
        return "\n\n".join([field for field in text_fields if field.split(": ")[1]])
    
    def process_for_retrieval(self) -> List[Dict]:
        """
        Process the clinical notes for the retrieval system.
        
        Returns:
            List of documents for indexing
        """
        if not self.clinical_notes:
            self.load_clinical_notes()
            
        # Add knowledge graphs to the documents
        if not self.knowledge_graphs:
            self.load_knowledge_graphs()
        
        documents = []
        
        # Process clinical notes
        for note in self.clinical_notes:
            # Create a document for each clinical note
            document = {
                "id": f"note-{note['id']}",
                "content": self.get_combined_text(note),
                "metadata": {
                    "type": "clinical_note",
                    "disease_category": note.get("disease_category", ""),
                    "diagnosis": note.get("diagnosis", ""),
                    "chief_complaint": note.get("chief_complaint", ""),
                }
            }
            
            documents.append(document)
        
        # Process knowledge graphs
        for kg_name, kg_data in self.knowledge_graphs.items():
            # Create a document for each knowledge graph
            document = {
                "id": f"kg-{kg_name}",
                "content": self.get_knowledge_graph_text(kg_name),
                "metadata": {
                    "type": "knowledge_graph",
                    "disease_category": kg_name,
                }
            }
            
            documents.append(document)
            
        logger.info(f"Processed {len(documents)} documents for retrieval")
        
        # Ensure we have at least one document
        if not documents:
            logger.warning("No documents processed, creating a dummy document")
            documents.append({
                "id": "dummy-doc",
                "content": "This is a placeholder document for testing.",
                "metadata": {"type": "dummy"}
            })
            
        return documents
    
    def get_knowledge_graph_text(self, disease_category: str) -> str:
        """
        Get the text representation of a knowledge graph for a disease category.
        
        Args:
            disease_category: Name of the disease category
            
        Returns:
            Text representation of the knowledge graph
        """
        if not self.knowledge_graphs:
            self.load_knowledge_graphs()
            
        kg = self.knowledge_graphs.get(disease_category)
        if not kg:
            return ""
            
        # Convert knowledge graph to text format
        lines = []
        
        # Add disease name
        disease_name = kg.get("disease", disease_category.replace("_", " ").title())
        lines.append(f"# {disease_name}")
        
        # Add symptoms
        if "symptoms" in kg:
            lines.append("\n## Symptoms")
            for symptom in kg["symptoms"]:
                lines.append(f"- {symptom}")
                
        # Add risk factors
        if "risk_factors" in kg:
            lines.append("\n## Risk Factors")
            for factor in kg["risk_factors"]:
                lines.append(f"- {factor}")
                
        # Add diagnostic criteria
        if "diagnostic_criteria" in kg:
            lines.append("\n## Diagnostic Criteria")
            for criterion in kg["diagnostic_criteria"]:
                lines.append(f"- {criterion}")
                
        # Add treatment options
        if "treatment_options" in kg:
            lines.append("\n## Treatment Options")
            for treatment in kg["treatment_options"]:
                lines.append(f"- {treatment}")
                
        return "\n".join(lines) 