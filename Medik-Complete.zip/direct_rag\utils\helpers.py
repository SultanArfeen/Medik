"""
Helper utilities for the DiReCT RAG system.

This module provides common utility functions used across the system.
"""

import os
import json
import logging
from typing import Dict, List, Any, Optional
from pathlib import Path

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("helpers")

def ensure_dir(directory: str) -> Path:
    """
    Ensure a directory exists, creating it if necessary.
    
    Args:
        directory: Directory path to ensure exists
        
    Returns:
        Path object for the directory
    """
    path = Path(directory)
    os.makedirs(path, exist_ok=True)
    return path

def save_json(data: Dict, filepath: str) -> None:
    """
    Save data to a JSON file.
    
    Args:
        data: Data to save
        filepath: Path to save the file
    """
    try:
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        logger.debug(f"Saved data to {filepath}")
    except Exception as e:
        logger.error(f"Error saving data to {filepath}: {str(e)}")

def load_json(filepath: str) -> Optional[Dict]:
    """
    Load data from a JSON file.
    
    Args:
        filepath: Path to the JSON file
        
    Returns:
        Loaded data or None if an error occurred
    """
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)
        logger.debug(f"Loaded data from {filepath}")
        return data
    except Exception as e:
        logger.error(f"Error loading data from {filepath}: {str(e)}")
        return None

def format_clinical_note(note: Dict) -> str:
    """
    Format a clinical note into a readable text format.
    
    Args:
        note: Clinical note dictionary
        
    Returns:
        Formatted note text
    """
    sections = [
        ("Chief Complaint", note.get("chief_complaint", "")),
        ("History of Present Illness", note.get("history_present_illness", "")),
        ("Past Medical History", note.get("past_medical_history", "")),
        ("Family History", note.get("family_history", "")),
        ("Physical Examination", note.get("physical_exam", "")),
        ("Pertinent Results", note.get("pertinent_results", ""))
    ]
    
    formatted_text = []
    
    for section_name, section_content in sections:
        if section_content:
            formatted_text.append(f"## {section_name}")
            formatted_text.append(section_content)
    
    return "\n\n".join(formatted_text)

def truncate_text(text: str, max_length: int = 200) -> str:
    """
    Truncate text to a maximum length, adding an ellipsis if truncated.
    
    Args:
        text: Text to truncate
        max_length: Maximum length
        
    Returns:
        Truncated text
    """
    if len(text) <= max_length:
        return text
    
    return text[:max_length] + "..."

def format_metadata(metadata: Dict) -> str:
    """
    Format metadata into a readable text format.
    
    Args:
        metadata: Metadata dictionary
        
    Returns:
        Formatted metadata text
    """
    lines = []
    
    for key, value in metadata.items():
        if isinstance(value, dict):
            # For nested dictionaries, format recursively
            nested_lines = format_metadata(value).split("\n")
            lines.append(f"{key}:")
            lines.extend([f"  {line}" for line in nested_lines])
        else:
            # For simple values
            lines.append(f"{key}: {value}")
    
    return "\n".join(lines) 