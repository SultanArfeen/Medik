"""
Retriever Component for DiReCT RAG System

This module implements the retrieval component of the RAG system,
providing both embedding-based dense retrieval and BM25 sparse retrieval.
"""

import os
import pickle
import logging
from typing import List, Dict, Any, Union, Optional
import numpy as np
from pathlib import Path
import faiss
from rank_bm25 import BM25Okapi
from sentence_transformers import SentenceTransformer
import nltk
import re

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("retriever")

# Try to download NLTK resources, but provide fallbacks if it fails
try:
    nltk.download('punkt')
    nltk.download('stopwords')
    from nltk.tokenize import word_tokenize
    from nltk.corpus import stopwords
    NLTK_AVAILABLE = True
except Exception as e:
    logger.warning(f"Could not set up NLTK: {str(e)}. Using basic tokenization instead.")
    NLTK_AVAILABLE = False

class BM25Retriever:
    """BM25 sparse retrieval for clinical notes and knowledge graphs."""
    
    def __init__(self, index_dir: str = "indexes"):
        """
        Initialize the BM25 retriever.
        
        Args:
            index_dir: Directory to store the index
        """
        self.index_dir = Path(index_dir)
        self.index_path = self.index_dir / "bm25_index.pkl"
        self.documents_path = self.index_dir / "bm25_documents.pkl"
        
        self.bm25 = None
        self.documents = []
        self.tokenized_documents = []
        
        # Set up stop words if NLTK is available, otherwise use a basic set
        if NLTK_AVAILABLE:
            self.stop_words = set(stopwords.words('english'))
        else:
            # Simple list of common English stop words
            self.stop_words = {"a", "an", "the", "and", "or", "but", "is", "are", "was", "were", 
                               "in", "on", "at", "to", "for", "with", "by", "about", "of"}
        
        # Create index directory if it doesn't exist
        os.makedirs(self.index_dir, exist_ok=True)
    
    def preprocess_text(self, text: str) -> List[str]:
        """
        Preprocess text for BM25 indexing.
        
        Args:
            text: The text to preprocess
            
        Returns:
            List of preprocessed tokens
        """
        # Convert to lowercase
        text = text.lower()
        
        # Use NLTK tokenization if available, otherwise use simple regex tokenization
        if NLTK_AVAILABLE:
            try:
                tokens = word_tokenize(text)
            except Exception as e:
                logger.warning(f"NLTK tokenization failed: {str(e)}. Using simple tokenization.")
                tokens = re.findall(r'\b\w+\b', text)
        else:
            tokens = re.findall(r'\b\w+\b', text)
            
        # Filter tokens: remove stop words and ensure they are alphanumeric
        tokens = [token for token in tokens if token.isalnum() and token not in self.stop_words]
        
        # Ensure there's at least one token
        if not tokens:
            tokens = ["placeholder"]
            
        return tokens
    
    def build_index(self, documents: List[Dict[str, Any]]) -> None:
        """
        Build the BM25 index.
        
        Args:
            documents: List of documents to index
        """
        logger.info("Building BM25 index")
        
        # Check if documents list is empty
        if not documents:
            logger.warning("Empty document list provided for indexing. Creating dummy document.")
            # Add a dummy document to prevent errors
            documents = [{
                "id": "dummy-doc",
                "content": "This is a placeholder document for testing.",
                "metadata": {"type": "dummy"}
            }]
        
        self.documents = documents
        self.tokenized_documents = []
        
        # Tokenize documents
        for doc in documents:
            tokenized_doc = self.preprocess_text(doc["content"])
            # Ensure document has at least one token
            if not tokenized_doc:
                tokenized_doc = ["placeholder"]
            self.tokenized_documents.append(tokenized_doc)
        
        # Create BM25 index
        try:
            self.bm25 = BM25Okapi(self.tokenized_documents)
            # Save index and documents
            self._save_index()
            logger.info(f"BM25 index built with {len(documents)} documents")
        except Exception as e:
            logger.error(f"Error building BM25 index: {str(e)}")
            # Create a fallback retriever
            self.documents = [{
                "id": "dummy-doc",
                "content": "This is a placeholder document for testing.",
                "metadata": {"type": "dummy"}
            }]
            self.tokenized_documents = [[
                "placeholder"
            ]]
            try:
                # Try to create a minimal index
                self.bm25 = BM25Okapi(self.tokenized_documents)
            except Exception as e2:
                logger.error(f"Failed to create even a minimal BM25 index: {str(e2)}")
                # We'll handle this in retrieve() by returning fallback results
    
    def _save_index(self) -> None:
        """Save the BM25 index and documents to disk."""
        try:
            with open(self.index_path, "wb") as f:
                pickle.dump(self.bm25, f)
                
            with open(self.documents_path, "wb") as f:
                pickle.dump(self.documents, f)
                
            logger.info(f"BM25 index saved to {self.index_path}")
        except Exception as e:
            logger.error(f"Error saving BM25 index: {str(e)}")
    
    def load_index(self) -> bool:
        """
        Load the BM25 index from disk.
        
        Returns:
            True if loading was successful, False otherwise
        """
        if not self.index_path.exists() or not self.documents_path.exists():
            logger.warning("BM25 index files not found. Please build the index first.")
            return False
        
        try:
            with open(self.index_path, "rb") as f:
                self.bm25 = pickle.load(f)
                
            with open(self.documents_path, "rb") as f:
                self.documents = pickle.load(f)
                
            logger.info(f"BM25 index loaded with {len(self.documents)} documents")
            return True
        except Exception as e:
            logger.error(f"Error loading BM25 index: {str(e)}")
            return False
    
    def retrieve(self, query: str, top_k: int = 5) -> List[Dict[str, Any]]:
        """
        Retrieve documents relevant to the query.
        
        Args:
            query: The query string
            top_k: Number of top documents to retrieve
            
        Returns:
            List of retrieved documents with scores
        """
        # Check if we have an index, if not try to build a minimal one
        if self.bm25 is None:
            success = self.load_index()
            if not success:
                logger.warning("No BM25 index available for retrieval. Building a dummy index.")
                dummy_doc = [{
                    "id": "dummy-doc", 
                    "content": "This is a placeholder document for testing.",
                    "metadata": {"type": "dummy"}
                }]
                self.build_index(dummy_doc)
                
        # If we still don't have an index, return fallback results
        if self.bm25 is None:
            logger.error("Failed to create or load BM25 index. Returning fallback results.")
            return [{
                "id": "fallback-doc",
                "content": "No retrieval index available. This is a fallback document.",
                "score": 0.0,
                "metadata": {"type": "fallback"}
            }]
        
        # Preprocess query
        tokenized_query = self.preprocess_text(query)
        
        # Ensure query has at least one token
        if not tokenized_query:
            tokenized_query = ["placeholder"]
            logger.warning("Empty query after preprocessing. Using placeholder token.")
        
        # Get document scores
        try:
            scores = self.bm25.get_scores(tokenized_query)
        except Exception as e:
            logger.error(f"Error during BM25 scoring: {str(e)}")
            # Return dummy results
            return [{
                "id": "error-doc",
                "content": "Error during retrieval process.",
                "score": 0.0,
                "metadata": {"type": "error"}
            }]
        
        # Get top_k documents
        try:
            top_indices = np.argsort(scores)[::-1][:top_k]
        
            # Prepare results
            results = []
            for idx in top_indices:
                if idx < len(self.documents):
                    doc = self.documents[idx].copy()
                    doc["score"] = float(scores[idx])
                    results.append(doc)
        except Exception as e:
            logger.error(f"Error during ranking: {str(e)}")
            return [{
                "id": "error-doc",
                "content": "Error during document ranking.",
                "score": 0.0,
                "metadata": {"type": "error"}
            }]
        
        logger.info(f"Retrieved {len(results)} documents using BM25")
        
        # If no results, add a fallback document
        if not results:
            logger.warning("No results found. Adding fallback document.")
            results.append({
                "id": "fallback-doc",
                "content": "No relevant documents found for this query.",
                "score": 0.0,
                "metadata": {"type": "fallback"}
            })
        
        return results


class EmbeddingRetriever:
    """Dense embedding-based retrieval using sentence transformers."""
    
    def __init__(self, 
                 model_name: str = "sentence-transformers/all-mpnet-base-v2",
                 index_dir: str = "indexes"):
        """
        Initialize the embedding retriever.
        
        Args:
            model_name: Name of the sentence transformer model
            index_dir: Directory to store the index
        """
        self.model_name = model_name
        self.index_dir = Path(index_dir)
        self.index_path = self.index_dir / f"{model_name.split('/')[-1]}_index.faiss"
        self.documents_path = self.index_dir / f"{model_name.split('/')[-1]}_documents.pkl"
        self.model = None
        self.index = None
        self.documents = []
        
        # Create index directory if it doesn't exist
        os.makedirs(self.index_dir, exist_ok=True)
    
    def _load_model(self) -> None:
        """Load the sentence transformer model."""
        if self.model is None:
            logger.info(f"Loading model: {self.model_name}")
            self.model = SentenceTransformer(self.model_name)
    
    def build_index(self, documents: List[Dict[str, Any]]) -> None:
        """
        Build the embedding index.
        
        Args:
            documents: List of documents to index
        """
        logger.info("Building embedding index")
        
        self._load_model()
        self.documents = documents
        
        # Extract document contents
        texts = [doc["content"] for doc in documents]
        
        # Generate embeddings
        embeddings = self.model.encode(texts, show_progress_bar=True)
        
        # Create FAISS index
        dimension = embeddings.shape[1]
        self.index = faiss.IndexFlatL2(dimension)
        self.index.add(np.array(embeddings).astype('float32'))
        
        # Save index and documents
        self._save_index()
        
        logger.info(f"Embedding index built with {len(documents)} documents")
    
    def _save_index(self) -> None:
        """Save the embedding index and documents to disk."""
        faiss.write_index(self.index, str(self.index_path))
            
        with open(self.documents_path, "wb") as f:
            pickle.dump(self.documents, f)
            
        logger.info(f"Embedding index saved to {self.index_path}")
    
    def load_index(self) -> bool:
        """
        Load the embedding index from disk.
        
        Returns:
            True if loading was successful, False otherwise
        """
        if not self.index_path.exists() or not self.documents_path.exists():
            logger.warning("Embedding index files not found. Please build the index first.")
            return False
        
        try:
            self._load_model()
            self.index = faiss.read_index(str(self.index_path))
                
            with open(self.documents_path, "rb") as f:
                self.documents = pickle.load(f)
                
            logger.info(f"Embedding index loaded with {len(self.documents)} documents")
            return True
        except Exception as e:
            logger.error(f"Error loading embedding index: {str(e)}")
            return False
    
    def retrieve(self, query: str, top_k: int = 5) -> List[Dict[str, Any]]:
        """
        Retrieve documents relevant to the query.
        
        Args:
            query: The query string
            top_k: Number of top documents to retrieve
            
        Returns:
            List of retrieved documents with scores
        """
        if self.model is None or self.index is None:
            success = self.load_index()
            if not success:
                logger.error("No embedding index available for retrieval")
                return []
        
        # Generate query embedding
        query_embedding = self.model.encode([query])[0].reshape(1, -1).astype('float32')
        
        # Search the index
        distances, indices = self.index.search(query_embedding, top_k)
        
        # Prepare results
        results = []
        for i, idx in enumerate(indices[0]):
            if idx < len(self.documents):
                doc = self.documents[idx].copy()
                # Convert distance to similarity score (lower distance = higher similarity)
                doc["score"] = float(1.0 / (1.0 + distances[0][i]))
                results.append(doc)
        
        logger.info(f"Retrieved {len(results)} documents using embeddings")
        return results


class HybridRetriever:
    """
    Hybrid retrieval combining BM25 and embedding-based approaches.
    """
    
    def __init__(self, 
                 embedding_model_name: str = "sentence-transformers/all-mpnet-base-v2",
                 index_dir: str = "indexes",
                 embedding_weight: float = 0.5):
        """
        Initialize the hybrid retriever.
        
        Args:
            embedding_model_name: Name of the sentence transformer model
            index_dir: Directory to store the index
            embedding_weight: Weight for embedding scores (0-1)
        """
        self.bm25_retriever = BM25Retriever(index_dir=index_dir)
        self.embedding_retriever = EmbeddingRetriever(
            model_name=embedding_model_name,
            index_dir=index_dir
        )
        self.embedding_weight = embedding_weight
    
    def build_index(self, documents: List[Dict[str, Any]]) -> None:
        """
        Build both BM25 and embedding indexes.
        
        Args:
            documents: List of documents to index
        """
        logger.info("Building hybrid index")
        
        self.bm25_retriever.build_index(documents)
        self.embedding_retriever.build_index(documents)
        
        logger.info(f"Hybrid index built with {len(documents)} documents")
    
    def load_index(self) -> bool:
        """
        Load both BM25 and embedding indexes from disk.
        
        Returns:
            True if loading both indexes was successful, False otherwise
        """
        bm25_success = self.bm25_retriever.load_index()
        embedding_success = self.embedding_retriever.load_index()
        
        return bm25_success and embedding_success
    
    def retrieve(self, query: str, top_k: int = 5) -> List[Dict[str, Any]]:
        """
        Retrieve documents using both BM25 and embeddings, combining results.
        
        Args:
            query: The query string
            top_k: Number of top documents to retrieve
            
        Returns:
            List of retrieved documents with combined scores
        """
        # Get more results than needed from each retriever to ensure diversity
        bm25_results = self.bm25_retriever.retrieve(query, top_k=top_k*2)
        embedding_results = self.embedding_retriever.retrieve(query, top_k=top_k*2)
        
        # Create a map of document IDs to documents with scores
        doc_map = {}
        
        # Add BM25 results with weight
        for doc in bm25_results:
            doc_id = doc["id"]
            doc_map[doc_id] = {
                **doc,
                "bm25_score": doc["score"],
                "combined_score": (1 - self.embedding_weight) * doc["score"]
            }
        
        # Add embedding results with weight
        for doc in embedding_results:
            doc_id = doc["id"]
            if doc_id in doc_map:
                # Document already in map, add embedding score
                doc_map[doc_id]["embedding_score"] = doc["score"]
                doc_map[doc_id]["combined_score"] += self.embedding_weight * doc["score"]
            else:
                # New document
                doc_map[doc_id] = {
                    **doc,
                    "embedding_score": doc["score"],
                    "combined_score": self.embedding_weight * doc["score"]
                }
        
        # Convert map back to list and sort by combined score
        results = list(doc_map.values())
        results.sort(key=lambda x: x.get("combined_score", 0), reverse=True)
        
        # Return top_k results
        top_results = results[:top_k]
        
        logger.info(f"Retrieved {len(top_results)} documents using hybrid approach")
        return top_results 