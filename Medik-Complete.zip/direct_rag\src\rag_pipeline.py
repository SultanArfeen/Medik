"""
RAG Pipeline for DiReCT System

This module integrates the retriever and generator components
to create a complete Retrieval-Augmented Generation pipeline.
"""

import os
import logging
import json
import pickle
import time
import threading
from typing import List, Dict, Any, Optional, Union
from pathlib import Path
from transformers import TextIteratorStreamer

from .data_processor import DiReCTDataProcessor
from .retriever import BM25Retriever, EmbeddingRetriever, HybridRetriever
from .generator import DirectGenerator, OpenAIGenerator

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("rag_pipeline")

class RAGPipeline:
    """
    Retrieval-Augmented Generation pipeline for the DiReCT system.
    Integrates the retriever and generator components.
    """
    
    def __init__(self,
                 data_dir: str = "data",
                 retriever_type: str = "hybrid",
                 generator_type: str = "direct",
                 generator_model_name: str = None,
                 index_dir: str = "indexes",
                 save_results: bool = True,
                 results_dir: str = "results",
                 use_cached_data: bool = False,
                 model_timeout: int = 30,
                 use_simple_generator: bool = False):
        """
        Initialize the RAG pipeline.
        
        Args:
            data_dir: Directory containing the data files
            retriever_type: Type of retriever to use (bm25, embedding, hybrid)
            generator_type: Type of generator to use (direct, openai)
            generator_model_name: Name of the generator model to use
            index_dir: Directory for saving indexes
            save_results: Whether to save results to disk
            results_dir: Directory for saving results
            use_cached_data: Whether to attempt loading from cache
            model_timeout: Timeout for model loading and inference
            use_simple_generator: Use a simple rule-based generator instead of ML model
        """
        self.data_dir = Path(data_dir)
        self.retriever_type = retriever_type
        self.generator_type = generator_type
        self.generator_model_name = generator_model_name
        self.index_dir = Path(index_dir)
        self.save_results = save_results
        self.results_dir = Path(results_dir)
        self.use_cached_data = use_cached_data
        self.cache_file = Path(index_dir) / "processed_data.cache"
        self.model_timeout = model_timeout
        self.use_simple_generator = use_simple_generator
        
        # Create directories if they don't exist
        os.makedirs(self.index_dir, exist_ok=True)
        if self.save_results:
            os.makedirs(self.results_dir, exist_ok=True)
        
        # Load data if available, otherwise will be loaded on demand
        self.kg_data = None
        self.clinical_notes = None
        self.all_documents = None
        
        # Try to load cached data
        if self.use_cached_data and self.cache_file.exists():
            try:
                logger.info(f"Loading cached data from {self.cache_file}")
                with open(self.cache_file, "rb") as f:
                    cached_data = pickle.load(f)
                    self.kg_data = cached_data.get("kg_data")
                    self.clinical_notes = cached_data.get("clinical_notes")
                    self.all_documents = cached_data.get("all_documents")
                    logger.info(f"Loaded cached data: {len(self.all_documents or [])} documents")
            except Exception as e:
                logger.error(f"Error loading cached data: {str(e)}")
        
        # Initialize retriever
        logger.info(f"Initializing retriever of type: {retriever_type}")
        self.retriever = self._initialize_retriever()
        
        # Initialize generator only if not using simple generator
        if not self.use_simple_generator:
            logger.info(f"Initializing generator of type: {generator_type}")
            self.generator = self._initialize_generator()
        else:
            logger.info("Using simple generator mode - no ML model will be loaded")
            self.generator = None
    
    def load_cached_data(self) -> bool:
        """
        Load data from cache if available.
        
        Returns:
            Boolean indicating success
        """
        if self.cache_file.exists():
            try:
                logger.info(f"Loading cached data from {self.cache_file}")
                
                # Load cached documents
                with open(self.cache_file, 'rb') as f:
                    cached_data = pickle.load(f)
                
                # Load KG and clinical notes from cache
                if 'knowledge_graphs' in cached_data:
                    self.data_processor.knowledge_graphs = cached_data['knowledge_graphs']
                if 'clinical_notes' in cached_data:
                    self.data_processor.clinical_notes = cached_data['clinical_notes']
                
                # Load processed documents
                if 'documents' in cached_data:
                    documents = cached_data['documents']
                    
                    # Check if indexes already exist
                    index_files = list(self.index_dir.glob("*.bin")) + list(self.index_dir.glob("*.pkl"))
                    
                    if not index_files:
                        # Rebuild the index if it doesn't exist
                        logger.info("Indexes not found. Rebuilding from cached documents.")
                        self.retriever.build_index(documents)
                
                logger.info("Successfully loaded data from cache")
                return True
                
            except Exception as e:
                logger.error(f"Error loading cached data: {str(e)}")
                logger.info("Will proceed with fresh data preparation")
                return False
        else:
            logger.info("No cache file found. Will proceed with fresh data preparation")
            return False
    
    def prepare_data(self, cache_data: bool = False) -> None:
        """
        Prepare data for the RAG pipeline.
        
        Args:
            cache_data: Whether to cache the processed data
        """
        logger.info("Preparing data for RAG pipeline")
        
        try:
            # Load knowledge graphs and clinical notes
            self.data_processor.load_knowledge_graphs()
            self.data_processor.load_clinical_notes()
            
            # Process documents for retrieval
            documents = self.data_processor.process_for_retrieval()
            
            # Check if we have documents
            if not documents:
                logger.warning("No documents found for indexing. Creating a dummy document.")
                documents = [{
                    "id": "dummy-doc",
                    "content": "This is a placeholder document for testing.",
                    "metadata": {"type": "dummy"}
                }]
            
            # Build retriever index
            self.retriever.build_index(documents)
            
            # Cache the data if requested
            if cache_data:
                self._cache_data(documents)
            
            logger.info("Data preparation completed")
        except Exception as e:
            logger.error(f"Error during data preparation: {str(e)}")
            raise
    
    def _cache_data(self, documents: List[Dict[str, Any]]) -> None:
        """
        Cache processed data to disk.
        
        Args:
            documents: Processed documents
        """
        try:
            logger.info(f"Caching processed data to {self.cache_file}")
            
            # Create a cache dictionary with all necessary data
            cache_data = {
                'knowledge_graphs': self.data_processor.knowledge_graphs,
                'clinical_notes': self.data_processor.clinical_notes,
                'documents': documents
            }
            
            # Save to cache file
            with open(self.cache_file, 'wb') as f:
                pickle.dump(cache_data, f)
            
            logger.info("Data successfully cached")
        except Exception as e:
            logger.error(f"Error caching data: {str(e)}")
    
    def process_query(self, 
                     query: str, 
                     top_k: int = 5,
                     stream: bool = False,
                     timeout: int = None) -> Dict[str, Any]:
        """
        Process a query through the RAG pipeline.
        
        Args:
            query: User query
            top_k: Number of documents to retrieve
            stream: Whether to stream the response
            timeout: Maximum time (in seconds) to wait for response generation
            
        Returns:
            Dictionary containing query results
        """
        start_time = time.time()
        logger.info(f"Processing query: {query}")
        
        if not query or not isinstance(query, str):
            logger.warning("Invalid query provided. Using a default query.")
            query = "What are the diagnostic criteria for heart failure?"
        
        try:
            # For simple generator mode, just retrieve documents and generate basic response
            if self.use_simple_generator:
                retrieved_docs = self.retriever.retrieve(query, top_k)
                self.logger.info(f"Retrieved {len(retrieved_docs)} documents")
                
                # Generate a simple response based on keyword matching
                response = self._generate_simple_response(query, retrieved_docs)
                
                # Return the results
                return {
                    "query": query,
                    "answer": response,
                    "retrieved_documents": retrieved_docs,
                    "query_time": time.time() - start_time
                }
            
            # Step 1: Retrieve relevant documents
            retrieved_docs = self.retriever.retrieve(query, top_k=top_k)
            
            # Verify we have documents
            if not retrieved_docs:
                logger.warning("No documents retrieved. Adding a fallback document.")
                retrieved_docs = [{
                    "id": "fallback-doc",
                    "content": "No relevant documents found for this query.",
                    "score": 0.0,
                    "metadata": {"type": "fallback"}
                }]
            
            # Step 2: Generate response
            try:
                if stream:
                    response_streamer = self.generator.generate(
                        query=query,
                        retrieved_docs=retrieved_docs,
                        stream=True
                    )
                    
                    # Return the streamer and results for later completion
                    result = {
                        "query": query,
                        "retrieved_docs": retrieved_docs,
                        "response_streamer": response_streamer,
                        "complete": False
                    }
                    result["query_time"] = time.time() - start_time
                    return result
                else:
                    # Use threading.Timer for timeout instead of signal.SIGALRM (Windows compatible)
                    response = None
                    generation_error = None
                    generation_completed = False
                    
                    # Function to call when timeout occurs
                    def timeout_handler():
                        nonlocal generation_completed
                        if not generation_completed:
                            logger.error(f"Response generation timed out after {self.model_timeout} seconds")
                    
                    # Set up timeout timer
                    timer = threading.Timer(self.model_timeout, timeout_handler)
                    timer.start()
                    
                    try:
                        # Get response from generator
                        response = self.generator.generate(
                            query=query,
                            retrieved_docs=retrieved_docs
                        )
                        
                        # Mark generation as completed
                        generation_completed = True
                        
                        # Clean up response if needed
                        if response and isinstance(response, str):
                            response = self._clean_response(response)
                    except Exception as e:
                        generation_error = e
                        logger.error(f"Error during response generation: {str(e)}")
                    finally:
                        # Cancel the timer if it's still running
                        timer.cancel()
                    
                    # Handle timeout or error
                    if not generation_completed:
                        response = "I'm sorry, generating a response took too long. Please try a simpler question or different wording."
                    elif generation_error:
                        response = f"I'm sorry, I encountered an error while generating a response. Please try again or refine your query."
                    elif not response:
                        response = "I'm sorry, no response was generated. Please try again with a different query."
                    
                    # Calculate total processing time
                    query_time = time.time() - start_time
                    
                    # Create the result
                    result = {
                        "query": query,
                        "retrieved_docs": retrieved_docs,
                        "response": response,
                        "complete": True,
                        "query_time": query_time
                    }
                    
                    # Add error if any
                    if generation_error:
                        result["error"] = str(generation_error)
                    
                    # Save the result if enabled
                    if self.save_results:
                        self._save_result(result)
                    
                    return result
            except Exception as e:
                logger.error(f"Error during response generation: {str(e)}")
                fallback_response = f"I'm sorry, I encountered an error while generating a response. Please try again or refine your query."
                
                result = {
                    "query": query,
                    "retrieved_docs": retrieved_docs,
                    "response": fallback_response,
                    "complete": True,
                    "error": str(e),
                    "query_time": time.time() - start_time
                }
                
                return result
                
        except Exception as e:
            logger.error(f"Error processing query: {str(e)}")
            fallback_response = "I'm sorry, I encountered an error while processing your query. Please try again or refine your query."
            
            result = {
                "query": query,
                "retrieved_docs": [],
                "response": fallback_response,
                "complete": True,
                "error": str(e),
                "query_time": time.time() - start_time
            }
            
            return result
    
    def _clean_response(self, response: str) -> str:
        """
        Clean the model's response to remove repetitions and other issues.
        
        Args:
            response: The raw response from the model
            
        Returns:
            Cleaned response
        """
        # Skip if None or empty
        if not response:
            return "No response was generated."
            
        # Check for repeating "User Profile:" lines or other repetitions
        if response.count("User Profile:") > 1 or response.count("User:") > 2:
            lines = response.split("\n")
            unique_lines = []
            seen_lines = set()
            
            for line in lines:
                # Skip empty lines and repetitive headers
                if not line.strip():
                    continue
                    
                # Skip if identical to previous line
                if unique_lines and line.strip() == unique_lines[-1].strip():
                    continue
                    
                # Skip line if it contains "User Profile:" and we've seen similar lines
                if "User Profile:" in line or "User:" in line:
                    normalized_line = line.lower().strip()
                    if normalized_line in seen_lines:
                        continue
                    seen_lines.add(normalized_line)
                
                unique_lines.append(line)
            
            # Join the cleaned lines
            response = "\n".join(unique_lines)
        
        # Check for repetitive content within the response
        paragraphs = response.split("\n\n")
        if len(paragraphs) > 1:
            unique_paragraphs = []
            seen_paragraphs = set()
            
            for paragraph in paragraphs:
                if not paragraph.strip():
                    continue
                
                # Skip identical paragraphs
                normalized_para = paragraph.lower().strip()
                if normalized_para in seen_paragraphs:
                    continue
                
                seen_paragraphs.add(normalized_para)
                unique_paragraphs.append(paragraph)
            
            response = "\n\n".join(unique_paragraphs)
            
        return response
    
    def _save_result(self, result: Dict[str, Any]) -> None:
        """
        Save query result to disk.
        
        Args:
            result: Query result dictionary
        """
        try:
            # Copy the result and remove non-serializable fields
            result_copy = result.copy()
            result_copy.pop("response_streamer", None)
            
            # Create a filename based on the query
            query_id = hash(result["query"]) % 10000
            filename = self.results_dir / f"query_{query_id}.json"
            
            # Save to file
            with open(filename, "w") as f:
                json.dump(result_copy, f, indent=2)
                
            logger.info(f"Result saved to {filename}")
        except Exception as e:
            logger.error(f"Error saving result: {str(e)}")
    
    def get_demo_queries(self) -> List[str]:
        """
        Get a list of demo queries for the system.
        
        Returns:
            List of demo queries
        """
        return [
            "What are the diagnostic criteria for heart failure?",
            "Can you provide a differential diagnosis for a patient with chest pain?",
            "What tests should be ordered for a patient with suspected pneumonia?",
            "What are the common symptoms of diabetes?",
            "How do you diagnose COPD?",
            "What findings would suggest a diagnosis of hypertension?",
            "What is the diagnostic pathway for stroke?",
            "What are the key features in the physical exam for heart failure?",
            "How would you interpret elevated troponin levels?",
            "What are the risk factors for Alzheimer's disease?"
        ]

    def _generate_simple_response(self, query, retrieved_docs):
        """Generate a simple response based on keyword matching and retrieved documents.
        
        Args:
            query: The user's query
            retrieved_docs: Retrieved documents
            
        Returns:
            A simple response
        """
        query_lower = query.lower()
        
        # Very simple keyword matching for common medical topics
        if "covid" in query_lower or "coronavirus" in query_lower:
            base_response = "COVID-19 is a respiratory illness caused by the SARS-CoV-2 virus. Common symptoms include fever, cough, and shortness of breath."
        elif "diabetes" in query_lower:
            base_response = "Diabetes is a condition where your body has trouble regulating blood sugar. Common symptoms include increased thirst, frequent urination, and fatigue."
        elif "heart" in query_lower:
            base_response = "Heart health is critical. Common heart disease symptoms include chest pain, shortness of breath, and fatigue."
        elif "headache" in query_lower or "migraine" in query_lower:
            base_response = "Headaches can be caused by stress, dehydration, or more serious conditions. Migraines often include symptoms like sensitivity to light and sound."
        elif "pain" in query_lower:
            base_response = "Pain can be a symptom of many conditions. The location, intensity, and duration of pain are important factors in diagnosis."
        else:
            base_response = "Based on your query, I can provide some general medical information."
        
        # Add information from retrieved documents if available
        doc_info = ""
        if retrieved_docs:
            doc_info = "\n\nBased on medical literature:"
            for i, doc in enumerate(retrieved_docs[:3]):  # Use up to 3 documents
                if 'content' in doc and doc['content']:
                    # Extract a relevant snippet from the document
                    content = doc['content']
                    snippet = content[:250] + "..." if len(content) > 250 else content
                    doc_info += f"\n- {snippet}"
        
        # Reminder to consult healthcare professional
        reminder = "\n\nRemember that this information is general in nature. For specific medical concerns, please consult with a healthcare professional."
        
        return base_response + doc_info + reminder

    def _initialize_retriever(self):
        """Initialize the appropriate retriever based on configuration."""
        try:
            if self.retriever_type == "bm25":
                try:
                    from .retrievers.bm25_retriever import BM25Retriever
                    return BM25Retriever(index_dir=self.index_dir)
                except Exception as e:
"""
RAG Pipeline for DiReCT System

This module integrates the retriever and generator components
to create a complete Retrieval-Augmented Generation pipeline.
"""

import os
import logging
import json
import pickle
import time
import threading
from typing import List, Dict, Any, Optional, Union
from pathlib import Path
from transformers import TextIteratorStreamer

from .data_processor import DiReCTDataProcessor
from .retriever import BM25Retriever, EmbeddingRetriever, HybridRetriever
from .generator import DirectGenerator, OpenAIGenerator

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("rag_pipeline")

class RAGPipeline:
    """
    Retrieval-Augmented Generation pipeline for the DiReCT system.
    Integrates the retriever and generator components.
    """
    
    def __init__(self,
                 data_dir: str = "data",
                 retriever_type: str = "hybrid",
                 generator_type: str = "direct",
                 generator_model_name: str = None,
                 index_dir: str = "indexes",
                 save_results: bool = True,
                 results_dir: str = "results",
                 use_cached_data: bool = False,
                 model_timeout: int = 30,
                 use_simple_generator: bool = False):
        """
        Initialize the RAG pipeline.
        
        Args:
            data_dir: Directory containing the data files
            retriever_type: Type of retriever to use (bm25, embedding, hybrid)
            generator_type: Type of generator to use (direct, openai)
            generator_model_name: Name of the generator model to use
            index_dir: Directory for saving indexes
            save_results: Whether to save results to disk
            results_dir: Directory for saving results
            use_cached_data: Whether to attempt loading from cache
            model_timeout: Timeout for model loading and inference
            use_simple_generator: Use a simple rule-based generator instead of ML model
        """
        self.data_dir = Path(data_dir)
        self.retriever_type = retriever_type
        self.generator_type = generator_type
        self.generator_model_name = generator_model_name
        self.index_dir = Path(index_dir)
        self.save_results = save_results
        self.results_dir = Path(results_dir)
        self.use_cached_data = use_cached_data
        self.cache_file = Path(index_dir) / "processed_data.cache"
        self.model_timeout = model_timeout
        self.use_simple_generator = use_simple_generator
        
        # Create directories if they don't exist
        os.makedirs(self.index_dir, exist_ok=True)
        if self.save_results:
            os.makedirs(self.results_dir, exist_ok=True)
        
        # Load data if available, otherwise will be loaded on demand
        self.kg_data = None
        self.clinical_notes = None
        self.all_documents = None
        
        # Try to load cached data
        if self.use_cached_data and self.cache_file.exists():
            try:
                logger.info(f"Loading cached data from {self.cache_file}")
                with open(self.cache_file, "rb") as f:
                    cached_data = pickle.load(f)
                    self.kg_data = cached_data.get("kg_data")
                    self.clinical_notes = cached_data.get("clinical_notes")
                    self.all_documents = cached_data.get("all_documents")
                    logger.info(f"Loaded cached data: {len(self.all_documents or [])} documents")
            except Exception as e:
                logger.error(f"Error loading cached data: {str(e)}")
        
        # Initialize retriever
        logger.info(f"Initializing retriever of type: {retriever_type}")
        self.retriever = self._initialize_retriever()
        
        # Initialize generator only if not using simple generator
        if not self.use_simple_generator:
            logger.info(f"Initializing generator of type: {generator_type}")
            self.generator = self._initialize_generator()
        else:
            logger.info("Using simple generator mode - no ML model will be loaded")
            self.generator = None
    
    def load_cached_data(self) -> bool:
        """
        Load data from cache if available.
        
        Returns:
            Boolean indicating success
        """
        if self.cache_file.exists():
            try:
                logger.info(f"Loading cached data from {self.cache_file}")
                
                # Load cached documents
                with open(self.cache_file, 'rb') as f:
                    cached_data = pickle.load(f)
                
                # Load KG and clinical notes from cache
                if 'knowledge_graphs' in cached_data:
                    self.data_processor.knowledge_graphs = cached_data['knowledge_graphs']
                if 'clinical_notes' in cached_data:
                    self.data_processor.clinical_notes = cached_data['clinical_notes']
                
                # Load processed documents
                if 'documents' in cached_data:
                    documents = cached_data['documents']
                    
                    # Check if indexes already exist
                    index_files = list(self.index_dir.glob("*.bin")) + list(self.index_dir.glob("*.pkl"))
                    
                    if not index_files:
                        # Rebuild the index if it doesn't exist
                        logger.info("Indexes not found. Rebuilding from cached documents.")
                        self.retriever.build_index(documents)
                
                logger.info("Successfully loaded data from cache")
                return True
                
            except Exception as e:
                logger.error(f"Error loading cached data: {str(e)}")
                logger.info("Will proceed with fresh data preparation")
                return False
        else:
            logger.info("No cache file found. Will proceed with fresh data preparation")
            return False
    
    def prepare_data(self, cache_data: bool = False) -> None:
        """
        Prepare data for the RAG pipeline.
        
        Args:
            cache_data: Whether to cache the processed data
        """
        logger.info("Preparing data for RAG pipeline")
        
        try:
            # Load knowledge graphs and clinical notes
            self.data_processor.load_knowledge_graphs()
            self.data_processor.load_clinical_notes()
            
            # Process documents for retrieval
            documents = self.data_processor.process_for_retrieval()
            
            # Check if we have documents
            if not documents:
                logger.warning("No documents found for indexing. Creating a dummy document.")
                documents = [{
                    "id": "dummy-doc",
                    "content": "This is a placeholder document for testing.",
                    "metadata": {"type": "dummy"}
                }]
            
            # Build retriever index
            self.retriever.build_index(documents)
            
            # Cache the data if requested
            if cache_data:
                self._cache_data(documents)
            
            logger.info("Data preparation completed")
        except Exception as e:
            logger.error(f"Error during data preparation: {str(e)}")
            raise
    
    def _cache_data(self, documents: List[Dict[str, Any]]) -> None:
        """
        Cache processed data to disk.
        
        Args:
            documents: Processed documents
        """
        try:
            logger.info(f"Caching processed data to {self.cache_file}")
            
            # Create a cache dictionary with all necessary data
            cache_data = {
                'knowledge_graphs': self.data_processor.knowledge_graphs,
                'clinical_notes': self.data_processor.clinical_notes,
                'documents': documents
            }
            
            # Save to cache file
            with open(self.cache_file, 'wb') as f:
                pickle.dump(cache_data, f)
            
            logger.info("Data successfully cached")
        except Exception as e:
            logger.error(f"Error caching data: {str(e)}")
    
    def process_query(self, 
                     query: str, 
                     top_k: int = 5,
                     stream: bool = False,
                     timeout: int = None) -> Dict[str, Any]:
        """
        Process a query through the RAG pipeline.
        
        Args:
            query: User query
            top_k: Number of documents to retrieve
            stream: Whether to stream the response
            timeout: Maximum time (in seconds) to wait for response generation
            
        Returns:
            Dictionary containing query results
        """
        start_time = time.time()
        logger.info(f"Processing query: {query}")
        
        if not query or not isinstance(query, str):
            logger.warning("Invalid query provided. Using a default query.")
            query = "What are the diagnostic criteria for heart failure?"
        
        try:
            # For simple generator mode, just retrieve documents and generate basic response
            if self.use_simple_generator:
                retrieved_docs = self.retriever.retrieve(query, top_k)
                self.logger.info(f"Retrieved {len(retrieved_docs)} documents")
                
                # Generate a simple response based on keyword matching
                response = self._generate_simple_response(query, retrieved_docs)
                
                # Return the results
                return {
                    "query": query,
                    "answer": response,
                    "retrieved_documents": retrieved_docs,
                    "query_time": time.time() - start_time
                }
            
            # Step 1: Retrieve relevant documents
            retrieved_docs = self.retriever.retrieve(query, top_k=top_k)
            
            # Verify we have documents
            if not retrieved_docs:
                logger.warning("No documents retrieved. Adding a fallback document.")
                retrieved_docs = [{
                    "id": "fallback-doc",
                    "content": "No relevant documents found for this query.",
                    "score": 0.0,
                    "metadata": {"type": "fallback"}
                }]
            
            # Step 2: Generate response
            try:
                if stream:
                    response_streamer = self.generator.generate(
                        query=query,
                        retrieved_docs=retrieved_docs,
                        stream=True
                    )
                    
                    # Return the streamer and results for later completion
                    result = {
                        "query": query,
                        "retrieved_docs": retrieved_docs,
                        "response_streamer": response_streamer,
                        "complete": False
                    }
                    result["query_time"] = time.time() - start_time
                    return result
                else:
                    # Use threading.Timer for timeout instead of signal.SIGALRM (Windows compatible)
                    response = None
                    generation_error = None
                    generation_completed = False
                    
                    # Function to call when timeout occurs
                    def timeout_handler():
                        nonlocal generation_completed
                        if not generation_completed:
                            logger.error(f"Response generation timed out after {self.model_timeout} seconds")
                    
                    # Set up timeout timer
                    timer = threading.Timer(self.model_timeout, timeout_handler)
                    timer.start()
                    
                    try:
                        # Get response from generator
                        response = self.generator.generate(
                            query=query,
                            retrieved_docs=retrieved_docs
                        )
                        
                        # Mark generation as completed
                        generation_completed = True
                        
                        # Clean up response if needed
                        if response and isinstance(response, str):
                            response = self._clean_response(response)
                    except Exception as e:
                        generation_error = e
                        logger.error(f"Error during response generation: {str(e)}")
                    finally:
                        # Cancel the timer if it's still running
                        timer.cancel()
                    
                    # Handle timeout or error
                    if not generation_completed:
                        response = "I'm sorry, generating a response took too long. Please try a simpler question or different wording."
                    elif generation_error:
                        response = f"I'm sorry, I encountered an error while generating a response. Please try again or refine your query."
                    elif not response:
                        response = "I'm sorry, no response was generated. Please try again with a different query."
                    
                    # Calculate total processing time
                    query_time = time.time() - start_time
                    
                    # Create the result
                    result = {
                        "query": query,
                        "retrieved_docs": retrieved_docs,
                        "response": response,
                        "complete": True,
                        "query_time": query_time
                    }
                    
                    # Add error if any
                    if generation_error:
                        result["error"] = str(generation_error)
                    
                    # Save the result if enabled
                    if self.save_results:
                        self._save_result(result)
                    
                    return result
            except Exception as e:
                logger.error(f"Error during response generation: {str(e)}")
                fallback_response = f"I'm sorry, I encountered an error while generating a response. Please try again or refine your query."
                
                result = {
                    "query": query,
                    "retrieved_docs": retrieved_docs,
                    "response": fallback_response,
                    "complete": True,
                    "error": str(e),
                    "query_time": time.time() - start_time
                }
                
                return result
                
        except Exception as e:
            logger.error(f"Error processing query: {str(e)}")
            fallback_response = "I'm sorry, I encountered an error while processing your query. Please try again or refine your query."
            
            result = {
                "query": query,
                "retrieved_docs": [],
                "response": fallback_response,
                "complete": True,
                "error": str(e),
                "query_time": time.time() - start_time
            }
            
            return result
    
    def _clean_response(self, response: str) -> str:
        """
        Clean the model's response to remove repetitions and other issues.
        
        Args:
            response: The raw response from the model
            
        Returns:
            Cleaned response
        """
        # Skip if None or empty
        if not response:
            return "No response was generated."
            
        # Check for repeating "User Profile:" lines or other repetitions
        if response.count("User Profile:") > 1 or response.count("User:") > 2:
            lines = response.split("\n")
            unique_lines = []
            seen_lines = set()
            
            for line in lines:
                # Skip empty lines and repetitive headers
                if not line.strip():
                    continue
                    
                # Skip if identical to previous line
                if unique_lines and line.strip() == unique_lines[-1].strip():
                    continue
                    
                # Skip line if it contains "User Profile:" and we've seen similar lines
                if "User Profile:" in line or "User:" in line:
                    normalized_line = line.lower().strip()
                    if normalized_line in seen_lines:
                        continue
                    seen_lines.add(normalized_line)
                
                unique_lines.append(line)
            
            # Join the cleaned lines
            response = "\n".join(unique_lines)
        
        # Check for repetitive content within the response
        paragraphs = response.split("\n\n")
        if len(paragraphs) > 1:
            unique_paragraphs = []
            seen_paragraphs = set()
            
            for paragraph in paragraphs:
                if not paragraph.strip():
                    continue
                
                # Skip identical paragraphs
                normalized_para = paragraph.lower().strip()
                if normalized_para in seen_paragraphs:
                    continue
                
                seen_paragraphs.add(normalized_para)
                unique_paragraphs.append(paragraph)
            
            response = "\n\n".join(unique_paragraphs)
            
        return response
    
    def _save_result(self, result: Dict[str, Any]) -> None:
        """
        Save query result to disk.
        
        Args:
            result: Query result dictionary
        """
        try:
            # Copy the result and remove non-serializable fields
            result_copy = result.copy()
            result_copy.pop("response_streamer", None)
            
            # Create a filename based on the query
            query_id = hash(result["query"]) % 10000
            filename = self.results_dir / f"query_{query_id}.json"
            
            # Save to file
            with open(filename, "w") as f:
                json.dump(result_copy, f, indent=2)
                
            logger.info(f"Result saved to {filename}")
        except Exception as e:
            logger.error(f"Error saving result: {str(e)}")
    
    def get_demo_queries(self) -> List[str]:
        """
        Get a list of demo queries for the system.
        
        Returns:
            List of demo queries
        """
        return [
            "What are the diagnostic criteria for heart failure?",
            "Can you provide a differential diagnosis for a patient with chest pain?",
            "What tests should be ordered for a patient with suspected pneumonia?",
            "What are the common symptoms of diabetes?",
            "How do you diagnose COPD?",
            "What findings would suggest a diagnosis of hypertension?",
            "What is the diagnostic pathway for stroke?",
            "What are the key features in the physical exam for heart failure?",
            "How would you interpret elevated troponin levels?",
            "What are the risk factors for Alzheimer's disease?"
        ]

    def _generate_simple_response(self, query, retrieved_docs):
        """Generate a simple response based on keyword matching and retrieved documents.
        
        Args:
            query: The user's query
            retrieved_docs: Retrieved documents
            
        Returns:
            A simple response
        """
        query_lower = query.lower()
        
        # Very simple keyword matching for common medical topics
        if "covid" in query_lower or "coronavirus" in query_lower:
            base_response = "COVID-19 is a respiratory illness caused by the SARS-CoV-2 virus. Common symptoms include fever, cough, and shortness of breath."
        elif "diabetes" in query_lower:
            base_response = "Diabetes is a condition where your body has trouble regulating blood sugar. Common symptoms include increased thirst, frequent urination, and fatigue."
        elif "heart" in query_lower:
            base_response = "Heart health is critical. Common heart disease symptoms include chest pain, shortness of breath, and fatigue."
        elif "headache" in query_lower or "migraine" in query_lower:
            base_response = "Headaches can be caused by stress, dehydration, or more serious conditions. Migraines often include symptoms like sensitivity to light and sound."
        elif "pain" in query_lower:
            base_response = "Pain can be a symptom of many conditions. The location, intensity, and duration of pain are important factors in diagnosis."
        else:
            base_response = "Based on your query, I can provide some general medical information."
        
        # Add information from retrieved documents if available
        doc_info = ""
        if retrieved_docs:
            doc_info = "\n\nBased on medical literature:"
            for i, doc in enumerate(retrieved_docs[:3]):  # Use up to 3 documents
                if 'content' in doc and doc['content']:
                    # Extract a relevant snippet from the document
                    content = doc['content']
                    snippet = content[:250] + "..." if len(content) > 250 else content
                    doc_info += f"\n- {snippet}"
        
        # Reminder to consult healthcare professional
        reminder = "\n\nRemember that this information is general in nature. For specific medical concerns, please consult with a healthcare professional."
        
        return base_response + doc_info + reminder

    def _initialize_retriever(self):
        """Initialize the appropriate retriever based on configuration."""
        try:
            if self.retriever_type == "bm25":
                from .retrievers.bm25_retriever import BM25Retriever
                return BM25Retriever(index_dir=self.index_dir)
            elif self.retriever_type == "embedding":
                from .retrievers.embedding_retriever import EmbeddingRetriever
                return EmbeddingRetriever(
                    model_name="sentence-transformers/all-mpnet-base-v2",
                    index_dir=self.index_dir
                )
            elif self.retriever_type == "hybrid":
                from .retrievers.hybrid_retriever import HybridRetriever
                return HybridRetriever(
                    embedding_model_name="sentence-transformers/all-mpnet-base-v2",
                    index_dir=self.index_dir
                )
            else:
                logger.warning(f"Unknown retriever type: {self.retriever_type}, defaulting to BM25")
                from .retrievers.bm25_retriever import BM25Retriever
                return BM25Retriever(index_dir=self.index_dir)
        except Exception as e:
            logger.error(f"Error initializing retriever: {str(e)}")
            # Return a simple retriever for fallback
            return self._create_mock_retriever()

    def _initialize_generator(self):
        """Initialize the appropriate generator based on configuration."""
        try:
            if self.generator_type == "direct":
                from .generators.direct_generator import DirectGenerator
                return DirectGenerator(
                    model_name_or_path=self.generator_model_name or "facebook/opt-125m"
                )
            elif self.generator_type == "openai":
                from .generators.openai_generator import OpenAIGenerator
                return OpenAIGenerator(
                    model_name=self.generator_model_name or "gpt-3.5-turbo"
                )
            else:
                logger.warning(f"Unknown generator type: {self.generator_type}, defaulting to mock generator")
                return MockGenerator()
        except Exception as e:
            logger.error(f"Error initializing generator: {str(e)}")
            # Return a mock generator for fallback
            return MockGenerator()

    def _create_mock_retriever(self):
        """Create a mock retriever for fallback situations."""
        class MockRetriever:
            def __init__(self):
                pass
            
            def retrieve(self, query, top_k=5):
                logger.info(f"Mock retriever called with query: {query}")
                return []
            
            def index_documents(self, documents):
                logger.info(f"Mock indexing of {len(documents)} documents")
                return True
        
        return MockRetriever()


class MockGenerator:
    """A mock generator for testing when the real generator fails to initialize."""
    
    def __init__(self):
        """Initialize the mock generator."""
        logger.warning("Using mock generator for testing purposes")
    
    def generate(self, query: str, retrieved_docs: List[Dict[str, Any]], stream: bool = False) -> Union[str, TextIteratorStreamer]:
        """
        Generate a mock response.
        
        Args:
            query: User query
            retrieved_docs: Retrieved documents
            stream: Whether to stream the response
            
        Returns:
            Mock response or streamer
        """
        response = f"This is a mock response to your query: '{query}'. The system is in test mode."
        
        if retrieved_docs:
            response += f"\n\nI found {len(retrieved_docs)} relevant documents, but I'm not able to process them in detail in test mode."
        
        if stream:
            # Create a mock streamer
            streamer = TextIteratorStreamer(None, skip_special_tokens=True, skip_prompt=True)
            # In a real case, we would push to the streamer in a thread
            # For mock, we just return a placeholder
            return streamer
        
        return response 