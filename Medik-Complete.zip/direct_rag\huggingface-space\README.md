# Medik - Your Personal AI Doctor

An advanced medical diagnostic assistant that helps assess symptoms and provides evidence-based health information using AI.

![Medik Banner](https://i.imgur.com/jMRKFfS.png)

## 🌟 Features

This interactive medical assistant offers:

- **Dark Theme UI**: Modern interface with high contrast for readability
- **Comprehensive Symptom Assessment**: Answer questions about your symptoms to receive a personalized health assessment
- **Specialized Medical Categories**: Support for cardiovascular, respiratory, gastrointestinal, neurological, dermatological, and musculoskeletal conditions
- **Personalized Analysis**: Takes into account age, gender, symptom duration, pain level, and medical history
- **Evidence-Based Information**: Retrieves relevant medical knowledge from clinical resources
- **Real-time Feedback**: Processing indicators and automatic scrolling for a seamless user experience

## 🩺 How to Use

1. **Start with Your Symptoms**: Select the relevant category of health concern
2. **Share Your Information**: Enter basic details like age, gender, and symptom duration
3. **Answer Follow-up Questions**: The system will ask specific questions about your condition
4. **Review Your Assessment**: Receive a personalized health assessment with possible conditions and recommendations

## 📋 Medical Categories

Medik can help assess conditions related to:

- 🫀 **Cardiovascular**: Heart conditions, chest pain, palpitations, blood pressure concerns
- 🫁 **Respiratory**: Breathing difficulties, coughing, wheezing, shortness of breath
- 🧠 **Neurological**: Headaches, dizziness, memory issues, tingling sensations
- 🦴 **Musculoskeletal**: Joint pain, muscle aches, mobility issues, injuries
- 🫃 **Gastrointestinal**: Digestive issues, abdominal pain, nausea, eating disorders
- 🩸 **Endocrine**: Hormonal imbalances, diabetes, thyroid conditions
- 🧠 **Mental Health**: Anxiety, depression, stress, sleep disorders
- 🧪 **Urinary**: Bladder issues, kidney concerns, frequent urination

## ⚕️ Example Assessments

Medik provides comprehensive assessments that include:

- **Possible Diagnoses**: Conditions that might explain your symptoms
- **Recommended Tests**: Diagnostic procedures your doctor might consider
- **Treatment Options**: Common approaches to addressing your condition
- **Urgency Assessment**: Whether you should seek immediate care

## ⚠️ Medical Disclaimer

Medik provides medical information for educational purposes only. It should not replace professional medical advice, diagnosis, or treatment. Always consult with a qualified healthcare provider for medical concerns. 