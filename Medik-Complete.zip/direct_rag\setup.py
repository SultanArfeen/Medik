from setuptools import setup, find_packages

setup(
    name="direct-rag",
    version="1.0.0",
    description="A Retrieval-Augmented Generation system for medical diagnostic reasoning",
    author="Sultan Ul Arfeen",
    author_email="SultaanUlArfeen@gmail.com",
    packages=find_packages(),
    install_requires=[
        "transformers>=4.36.0",
        "torch>=2.0.0",
        "sentence-transformers>=2.2.0",
        "faiss-cpu>=1.7.0",
        "numpy>=1.24.0",
        "pandas>=2.0.0",
        "streamlit>=1.30.0",
        "python-dotenv>=1.0.0",
        "openai>=1.0.0",
        "rank_bm25>=0.2.2",
        "aiofiles>=22.0,<24.0",  # Fixed version range for gradio compatibility
        "gradio>=5.16.0",
    ],
    python_requires=">=3.8",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Healthcare Industry",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
) 