"""
DiReCT RAG System

A Retrieval-Augmented Generation system for the MIMIC-IV-Ext-DiReCT dataset.
"""

from .data_processor import DiReCTDataProcessor
from .retriever import BM25Retriever, EmbeddingRetriever, HybridRetriever
from .generator import DirectGenerator, OpenAIGenerator
from .rag_pipeline import RAGPipeline

__version__ = "1.0.0" 