"""
Generator Component for DiReCT RAG System

This module implements the generation component of the RAG system,
using open-source language models to generate responses based on retrieved context.
"""

import os
import logging
from typing import List, Dict, Any, Optional, Union
import torch
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer, 
    StoppingCriteria, 
    StoppingCriteriaList,
    TextIteratorStreamer
)
from threading import Thread

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("generator")

class KeywordsStoppingCriteria(StoppingCriteria):
    """Custom stopping criteria for text generation based on keywords."""
    
    def __init__(self, keywords_ids, tokenizer):
        self.keywords_ids = keywords_ids
        self.tokenizer = tokenizer
        
    def __call__(self, input_ids, scores, **kwargs):
        # Check if the last generated tokens match any of the keywords
        for keyword_ids in self.keywords_ids:
            if input_ids[0][-len(keyword_ids):].tolist() == keyword_ids:
                return True
        return False

class DirectGenerator:
    """
    Generator component for the DiReCT RAG system,
    using a language model to generate responses from retrieved context.
    """
    
    def __init__(self, 
                 model_name_or_path: str = "mistralai/Mistral-7B-Instruct-v0.2",
                 device: str = "cuda" if torch.cuda.is_available() else "cpu",
                 max_new_tokens: int = 512,
                 temperature: float = 0.7,
                 top_p: float = 0.9,
                 top_k: int = 50):
        """
        Initialize the generator.
        
        Args:
            model_name_or_path: Name or path of the language model
            device: Device to run the model on (cuda or cpu)
            max_new_tokens: Maximum number of new tokens to generate
            temperature: Temperature for sampling
            top_p: Top-p for nucleus sampling
            top_k: Top-k for top-k sampling
        """
        self.model_name_or_path = model_name_or_path
        self.device = device
        self.max_new_tokens = max_new_tokens
        self.temperature = temperature
        self.top_p = top_p
        self.top_k = top_k
        
        # Initialize model and tokenizer to None (lazy loading)
        self.model = None
        self.tokenizer = None
        
        logger.info(f"Generator initialized with model: {model_name_or_path} on device: {device}")
    
    def _load_model_and_tokenizer(self) -> None:
        """Load the language model and tokenizer if not already loaded."""
        if self.model is None or self.tokenizer is None:
            logger.info(f"Loading model and tokenizer: {self.model_name_or_path}")
            
            # Load tokenizer
            self.tokenizer = AutoTokenizer.from_pretrained(self.model_name_or_path)
            
            # Load model with lower precision for efficiency
            self.model = AutoModelForCausalLM.from_pretrained(
                self.model_name_or_path,
                torch_dtype=torch.float16 if self.device == "cuda" else torch.float32,
                low_cpu_mem_usage=True,
                device_map=self.device
            )
            
            logger.info(f"Model and tokenizer loaded successfully")
    
    def format_context(self, retrieved_docs: List[Dict[str, Any]]) -> str:
        """
        Format retrieved documents into context for the generator.
        
        Args:
            retrieved_docs: List of retrieved documents
            
        Returns:
            Formatted context string
        """
        context_parts = []
        
        for i, doc in enumerate(retrieved_docs):
            # Determine the document type
            doc_type = doc.get("metadata", {}).get("type", "clinical_note")
            
            if doc_type == "knowledge_graph":
                # Format knowledge graph document
                disease_category = doc.get("metadata", {}).get("disease_category", "Unknown")
                context_parts.append(f"Knowledge Graph for {disease_category}:\n{doc['content']}\n")
            else:
                # Format clinical note document
                disease_category = doc.get("metadata", {}).get("disease_category", "Unknown")
                diagnosis = doc.get("metadata", {}).get("diagnosis", "Unknown")
                context_parts.append(
                    f"Clinical Note {i+1} (Disease Category: {disease_category}, "
                    f"Diagnosis: {diagnosis}):\n{doc['content']}\n"
                )
        
        return "\n".join(context_parts)
    
    def create_prompt(self, query: str, context: str) -> str:
        """
        Create a prompt for the language model.
        
        Args:
            query: User query
            context: Context from retrieved documents
            
        Returns:
            Formatted prompt
        """
        prompt = f"""<s>[INST] You are a medical assistant specialized in diagnostic reasoning. 
Use the provided clinical information to answer the user's question.
Base your answer on the retrieved context only and be specific.
If you can't find the answer in the context, acknowledge that limitation.

USER QUERY: {query}

RETRIEVED CONTEXT:
{context}

Provide a clear and comprehensive answer to the user's query, 
referencing the most relevant parts of the context. [/INST]
"""
        return prompt
    
    def generate(self, 
                query: str, 
                retrieved_docs: List[Dict[str, Any]],
                stream: bool = False) -> Union[str, TextIteratorStreamer]:
        """
        Generate a response based on the query and retrieved documents.
        
        Args:
            query: User query
            retrieved_docs: List of retrieved documents
            stream: Whether to stream the response
            
        Returns:
            Generated response or a streamer object
        """
        self._load_model_and_tokenizer()
        
        # Format the context and create the prompt
        context = self.format_context(retrieved_docs)
        prompt = self.create_prompt(query, context)
        
        # Tokenize the prompt
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.device)
        
        # Define stopping criteria to avoid common hallucination patterns
        stop_words = ["USER QUERY:", "RETRIEVED CONTEXT:"]
        stop_ids = [self.tokenizer.encode(word, add_special_tokens=False) for word in stop_words]
        stopping_criteria = StoppingCriteriaList([KeywordsStoppingCriteria(stop_ids, self.tokenizer)])
        
        if stream:
            # Set up streaming
            streamer = TextIteratorStreamer(self.tokenizer, skip_prompt=True, timeout=10.0)
            generation_kwargs = {
                "input_ids": inputs.input_ids,
                "attention_mask": inputs.attention_mask,
                "max_new_tokens": self.max_new_tokens,
                "temperature": self.temperature,
                "top_p": self.top_p,
                "top_k": self.top_k,
                "streamer": streamer,
                "stopping_criteria": stopping_criteria,
                "do_sample": self.temperature > 0,
            }
            
            # Start generation in a separate thread
            thread = Thread(target=self.model.generate, kwargs=generation_kwargs)
            thread.start()
            
            return streamer
        else:
            # Generate response
            with torch.no_grad():
                output = self.model.generate(
                    input_ids=inputs.input_ids,
                    attention_mask=inputs.attention_mask,
                    max_new_tokens=self.max_new_tokens,
                    temperature=self.temperature,
                    top_p=self.top_p,
                    top_k=self.top_k,
                    stopping_criteria=stopping_criteria,
                    do_sample=self.temperature > 0,
                )
            
            # Decode the output
            response = self.tokenizer.decode(output[0][inputs.input_ids.shape[1]:], skip_special_tokens=True)
            return response


class OpenAIGenerator:
    """
    Generator component using OpenAI's models (optional fallback).
    Requires API key to be set in environment variable OPENAI_API_KEY.
    """
    
    def __init__(self, 
                 model_name: str = "gpt-3.5-turbo",
                 max_tokens: int = 512,
                 temperature: float = 0.7,
                 api_key: Optional[str] = None):
        """
        Initialize the OpenAI generator.
        
        Args:
            model_name: Name of the OpenAI model
            max_tokens: Maximum number of tokens to generate
            temperature: Temperature for sampling
            api_key: OpenAI API key (optional, can be set in env)
        """
        try:
            import openai
            self.openai = openai
        except ImportError:
            logger.error("OpenAI package not installed. Run 'pip install openai'.")
            raise
        
        self.model_name = model_name
        self.max_tokens = max_tokens
        self.temperature = temperature
        
        # Set API key if provided, otherwise use environment variable
        if api_key:
            self.openai.api_key = api_key
        else:
            self.openai.api_key = os.getenv("OPENAI_API_KEY")
            if not self.openai.api_key:
                logger.warning("OpenAI API key not found. Set it using environment variable OPENAI_API_KEY.")
        
        logger.info(f"OpenAI Generator initialized with model: {model_name}")
    
    def format_context(self, retrieved_docs: List[Dict[str, Any]]) -> str:
        """
        Format retrieved documents into context for the generator.
        
        Args:
            retrieved_docs: List of retrieved documents
            
        Returns:
            Formatted context string
        """
        context_parts = []
        
        for i, doc in enumerate(retrieved_docs):
            # Determine the document type
            doc_type = doc.get("metadata", {}).get("type", "clinical_note")
            
            if doc_type == "knowledge_graph":
                # Format knowledge graph document
                disease_category = doc.get("metadata", {}).get("disease_category", "Unknown")
                context_parts.append(f"Knowledge Graph for {disease_category}:\n{doc['content']}\n")
            else:
                # Format clinical note document
                disease_category = doc.get("metadata", {}).get("disease_category", "Unknown")
                diagnosis = doc.get("metadata", {}).get("diagnosis", "Unknown")
                context_parts.append(
                    f"Clinical Note {i+1} (Disease Category: {disease_category}, "
                    f"Diagnosis: {diagnosis}):\n{doc['content']}\n"
                )
        
        return "\n".join(context_parts)
    
    def generate(self, query: str, retrieved_docs: List[Dict[str, Any]]) -> str:
        """
        Generate a response based on the query and retrieved documents.
        
        Args:
            query: User query
            retrieved_docs: List of retrieved documents
            
        Returns:
            Generated response
        """
        context = self.format_context(retrieved_docs)
        
        messages = [
            {"role": "system", "content": (
                "You are a medical assistant specialized in diagnostic reasoning. "
                "Use the provided clinical information to answer the user's question. "
                "Base your answer on the retrieved context only and be specific. "
                "If you can't find the answer in the context, acknowledge that limitation."
            )},
            {"role": "user", "content": f"QUERY: {query}\n\nCONTEXT:\n{context}"}
        ]
        
        try:
            response = self.openai.ChatCompletion.create(
                model=self.model_name,
                messages=messages,
                max_tokens=self.max_tokens,
                temperature=self.temperature,
            )
            return response.choices[0].message.content
        except Exception as e:
            logger.error(f"Error generating response with OpenAI: {str(e)}")
            return f"Error generating response: {str(e)}" 