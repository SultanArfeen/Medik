"""
Launcher for Medik - Personal AI Doctor on Hugging Face Spaces.

This is a simple redirector to the actual Streamlit app.
"""

import os
import sys
import streamlit as st
import logging
import time
import traceback

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("hf_launcher")

# Add parent directory to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Set environment variables for auto-initialization
os.environ["AUTO_INITIALIZE"] = "true"
os.environ["AUTO_PREPARE_DATA"] = "true"
os.environ["DEMO_MODE"] = "true"
os.environ["HUGGINGFACE_SPACE"] = "true"

try:
    logger.info("Starting Medik on Hugging Face Spaces")
    
    # Import and run the actual app
    from frontend.app import main
    
    # Run the application
    if __name__ == "__main__":
        try:
            main()
        except Exception as e:
            st.error("⚠️ An error occurred while starting the application")
            st.error(f"Error details: {str(e)}")
            
            # Display more detailed error information
            st.expander("Technical Details").write(traceback.format_exc())
            
            # Display recovery instructions
            st.info("""
            ### Troubleshooting
            
            Please try:
            1. Refreshing the page
            2. Clearing your browser cache
            3. Contacting the space owner if the issue persists
            """)
            
            logger.error(f"Application error: {str(e)}")
            logger.error(traceback.format_exc())

except ImportError as e:
    def show_import_error():
        st.set_page_config(page_title="Medik - Error", page_icon="⚠️", layout="wide")
        st.markdown("""
        # ⚠️ Initialization Error
        
        Could not initialize the Medik application due to missing dependencies.
        """)
        st.error(f"Error details: {str(e)}")
        st.info("The space owner needs to update the requirements.txt file.")
    
    show_import_error()
    logger.error(f"Import error: {str(e)}")
except Exception as e:
    def show_general_error():
        st.set_page_config(page_title="Medik - Error", page_icon="⚠️", layout="wide")
        st.markdown("""
        # ⚠️ Initialization Error
        
        An unexpected error occurred while starting Medik.
        """)
        st.error(f"Error details: {str(e)}")
        st.expander("Technical Details").write(traceback.format_exc())
    
    show_general_error()
    logger.error(f"General error: {str(e)}")
    logger.error(traceback.format_exc()) 