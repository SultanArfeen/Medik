"""
Dataset Setup Script for MIMIC-IV-Ext-DiReCT RAG System

This script copies and processes the necessary data files from the MIMIC-IV-Ext-DiReCT
dataset into our project structure.
"""

import os
import shutil
import json
from pathlib import Path
import logging

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler()],
)

logger = logging.getLogger("setup_data")

# Define paths
SCRIPT_DIR = Path(__file__).parent
PROJECT_DIR = SCRIPT_DIR
SOURCE_DATASET_DIR = Path("../mimic-iv-ext-direct-1.0.0")
TARGET_DATA_DIR = PROJECT_DIR / "data"

# Create directories if they don't exist
os.makedirs(TARGET_DATA_DIR / "kg", exist_ok=True)
os.makedirs(TARGET_DATA_DIR / "samples", exist_ok=True)

def copy_knowledge_graphs():
    """Copy knowledge graph files from the dataset to our project."""
    source_dir = SOURCE_DATASET_DIR / "Diagnosis_flowchart"
    target_dir = TARGET_DATA_DIR / "kg"
    
    logger.info(f"Copying knowledge graphs from {source_dir} to {target_dir}")
    
    if not source_dir.exists():
        logger.error(f"Source directory does not exist: {source_dir}")
        return
    
    # Copy all JSON files
    for file_path in source_dir.glob("*.json"):
        target_path = target_dir / file_path.name
        shutil.copy2(file_path, target_path)
        logger.info(f"Copied {file_path.name}")

def copy_sample_data():
    """Copy clinical note samples from the dataset to our project."""
    source_dir = SOURCE_DATASET_DIR / "Finished"
    target_dir = TARGET_DATA_DIR / "samples"
    
    logger.info(f"Copying sample data from {source_dir} to {target_dir}")
    
    if not source_dir.exists():
        logger.error(f"Source directory does not exist: {source_dir}")
        return
    
    # First, create the disease category directories
    for disease_dir in source_dir.glob("*"):
        if disease_dir.is_dir():
            os.makedirs(target_dir / disease_dir.name, exist_ok=True)
            
            # Copy all JSON files in the disease directory
            for file_path in disease_dir.glob("*.json"):
                target_path = target_dir / disease_dir.name / file_path.name
                shutil.copy2(file_path, target_path)
                logger.info(f"Copied {disease_dir.name}/{file_path.name}")

def create_metadata():
    """Create a metadata file with information about the dataset structure."""
    metadata = {
        "disease_categories": [],
        "total_samples": 0,
        "knowledge_graphs": []
    }
    
    # Get knowledge graph information
    kg_dir = TARGET_DATA_DIR / "kg"
    if kg_dir.exists():
        for kg_file in kg_dir.glob("*.json"):
            metadata["knowledge_graphs"].append(kg_file.stem)
    
    # Get sample data information
    samples_dir = TARGET_DATA_DIR / "samples"
    if samples_dir.exists():
        for disease_dir in samples_dir.glob("*"):
            if disease_dir.is_dir():
                sample_count = len(list(disease_dir.glob("*.json")))
                metadata["disease_categories"].append({
                    "name": disease_dir.name,
                    "sample_count": sample_count
                })
                metadata["total_samples"] += sample_count
    
    # Write metadata to file
    with open(TARGET_DATA_DIR / "metadata.json", "w") as f:
        json.dump(metadata, f, indent=2)
    
    logger.info(f"Created metadata file with {len(metadata['disease_categories'])} disease categories and {metadata['total_samples']} total samples")

def main():
    """Main function to run the setup process."""
    logger.info("Starting data setup process")
    
    copy_knowledge_graphs()
    copy_sample_data()
    create_metadata()
    
    logger.info("Data setup process completed successfully")

if __name__ == "__main__":
    main() 